package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.FinanceApproval;
import com.renaultdigital.client.employee.service.IFinanceApprovalService;

@CrossOrigin
@RestController
@RequestMapping(path="/rd/ert/rest/v1/financeapprovals/")
public class FinanceApprovalController {
	
	@Autowired
	IFinanceApprovalService financeApprovalService;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<FinanceApproval> getAllFinance(){
		return financeApprovalService.getAllFinanceApprovals();
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public List<FinanceApproval> addFinanceApprovals(@RequestBody List<FinanceApproval> financeApprovals){
		return financeApprovalService.addOrUpdate(financeApprovals);
	}
	
	
	@RequestMapping(path="{rnNum}", method=RequestMethod.GET)
	public FinanceApproval getById(@PathVariable String rnNum){
		return financeApprovalService.getByRnNum(rnNum);
	}
	
	
}
