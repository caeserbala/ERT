package com.renaultdigital.client.employee.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.tomcat.util.http.fileupload.IOUtils;

//import org.apache.commons.io.IOUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LdapUtil {

	private LdapUtil() {
	}

	public static final Logger LOGGER = LoggerFactory.getLogger(LdapUtil.class);

	private static DirContext ldapContext() throws NamingException {
		LOGGER.info("setting up Environment through ldapContext");
		Hashtable<String, String> env = new Hashtable<>();
		return ldapContext(env);
	}

	private static DirContext ldapContext(Hashtable<String, String> env) throws NamingException {
		LOGGER.info("Configuring ldapContext..");
		env.put(Context.INITIAL_CONTEXT_FACTORY, RenoConstants.CONTEXT_FACTORY);
		env.put(Context.PROVIDER_URL, RenoConstants.LDAPURI);
		return new InitialDirContext(env);
	}

	private static Map<String, Object> getUid(String user) throws NamingException {
		LOGGER.info("Get the User info (getUid)");
		DirContext ctx = ldapContext();
		NamingEnumeration<?> answer;
		Map<String, Object> userDetails = new HashMap<>();
		SearchControls ctrl = new SearchControls();
		String filter = "(uid=" + user + ")";
		String dn = null;

		LOGGER.info("Search Filter with user : {}", user);
		ctrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
		answer = ctx.search(RenoConstants.CONTEXT_SEARCH, filter, ctrl);

		if (answer.hasMore()) {
			SearchResult result = (SearchResult) answer.next();
			LOGGER.info("Search Result : {}", result);
			dn = result.getNameInNamespace();
			userDetails.put("name", (String) result.getAttributes().get(RenoConstants.ROLE_PREFIX_STRING).get(0));
			userDetails.put("email", (String) result.getAttributes().get("mail").get(0));
			userDetails.put("uid", (String) result.getAttributes().get("uid").get(0).toString());
			userDetails.put("givenName", (String) result.getAttributes().get("givenName").get(0));
			Attribute attr = result.getAttributes().get("jpegphoto");
			
			byte[] image = attr != null ? (byte[]) attr.get(0) : null;
			
			if (image == null){
				try{
				/*File fnew=new File("/src/main/resources/user.jpg");
				BufferedImage originalImage=ImageIO.read(fnew);
				ByteArrayOutputStream baos=new ByteArrayOutputStream();
				ImageIO.write(originalImage, "jpg", baos );
				image=baos.toByteArray();*/
					InputStream in = LdapUtil.class.getResourceAsStream("/user.jpg");
					BufferedImage originalImage=ImageIO.read(in);
					ByteArrayOutputStream baos=new ByteArrayOutputStream();
					ImageIO.write(originalImage, "jpg", baos );
					image=baos.toByteArray();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			userDetails.put("photo", image);
			userDetails.put("dn", dn);
		}

		answer.close();
		return userDetails;
	}

	public static Map<String, Object> authenticate(String username) throws NamingException, IOException {
		LOGGER.info("Authenticate User in authenticate");
		return getUid(username);
	}
}