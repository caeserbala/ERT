package com.renaultdigital.client.employee.controller;

import java.io.UnsupportedEncodingException;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.renaultdigital.client.employee.entity.MailDetail;
import com.renaultdigital.client.employee.util.RenoConstants;

@RestController
@RequestMapping("/rd/ert/rest/v1/mail")
public class MailController {

	@Autowired
	JavaMailSender mailSender;

	@RequestMapping(path = "/sendMail", method = RequestMethod.POST)
	public String triggerEmail(@RequestBody MailDetail mailDetail) {
		MimeMessagePreparator mailMessage = mimeMessage -> {
			mimeMessage.addHeader("X-Priority", "1");
			MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true, "UTF-8");
			message.setFrom("ESPPortal@rntbci.com", "ESP Application");
			String toMail = mailDetail.getMailTo();
			String name = toMail.split("\\.")[0];
			message.setText("Dear " + name + ", \n\r" + mailDetail.getBody() + " \n\r Thanks, \r\n ESP-TEAM");
			message.setTo(toMail);
			message.setCc(mailDetail.getMailCC());
			message.setSubject(mailDetail.getSubject());

		};
		try {
			mailSender.send(mailMessage);
			return RenoConstants.MAIL_SUCCESS;
		} catch (Exception e) {
			return RenoConstants.MAIL_FAILURE;
		}
	}

	@RequestMapping(path = "/sendMailAttachment", method = RequestMethod.POST)
	public String sendAttachmentsMail(@RequestParam("mailTo") String mailTo, @RequestParam("mailCC") String mailCC,
			@RequestParam("subject") String subject, @RequestParam("body") String body,
			@RequestParam("fileUpload") MultipartFile file) {
		MimeMessage mimeMessage = mailSender.createMimeMessage();
		try {
			mimeMessage.addHeader("X-Priority", "1");
			MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
			helper.setFrom("ESPPortal@rntbci.com", "ESP Application");
			helper.setText("Dear, \r\n Test Mail :" + body + " \n\r Thanks, \r\n ESP-TEAM");
			helper.setTo(mailTo);
			helper.setCc(mailCC);
			helper.setSubject(subject);
			helper.addAttachment(file.getOriginalFilename(), file);
		} catch (MessagingException | UnsupportedEncodingException e) {
			return RenoConstants.MAIL_FAILURE;
		}

		mailSender.send(mimeMessage);
		return RenoConstants.MAIL_SUCCESS;

	}

}
