package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.ItApproval;
import com.renaultdigital.client.employee.repository.IItApprovalRepository;

@Service
public class ItApprovalService implements IItApprovalService {

	@Autowired
	IItApprovalRepository itApprovalRepository;

	@Override
	public List<ItApproval> addOrUpdate(List<ItApproval> itApprovals) {
		return (List<ItApproval>) itApprovalRepository.save((Iterable<ItApproval>) itApprovals);
	}

	@Override
	public ItApproval findByRnNumber(String rnNum) {
		return itApprovalRepository.findByRnNumRnNum(rnNum);
	}

	@Override
	public List<ItApproval> getAllITApprovals() {
		return itApprovalRepository.findAll();
	}

}
