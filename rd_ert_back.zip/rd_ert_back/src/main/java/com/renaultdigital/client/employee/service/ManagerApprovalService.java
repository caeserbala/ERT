package com.renaultdigital.client.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.entity.HrApproval;
import com.renaultdigital.client.employee.entity.ManagerApproval;
import com.renaultdigital.client.employee.entity.Status;
import com.renaultdigital.client.employee.repository.IEmployeeRepository;
import com.renaultdigital.client.employee.repository.IEmployeeResignationRepository;
import com.renaultdigital.client.employee.repository.IHrApprovalRepository;
import com.renaultdigital.client.employee.repository.IManagerApprovalRepository;
import com.renaultdigital.client.employee.repository.IStatusRepository;
import com.renaultdigital.client.employee.util.Constants;
import com.renaultdigital.client.employee.util.Constants.StatusCode;



@Service
public class ManagerApprovalService implements IManagerApprovalService {

	@Autowired
	IManagerApprovalRepository managerApprovalRepository;

	@Autowired
	IEmployeeRepository employeeRepository;

	@Autowired
	IStatusRepository statusCodeRepository;

	@Autowired
	IEmployeeResignationRepository employeeResignationRepository;

	@Autowired
	IHrApprovalRepository hrApprovalRepository;

	@Override
	public List<ManagerApproval> getAllManagerApprovals() {
		return managerApprovalRepository.findAll();
	}

	@Override
	public List<ManagerApproval> addOrUpdate(List<ManagerApproval> managerApprovals) {
		ManagerApproval managerApproval = managerApprovals.get(0);
		EmployeeResignation employeeResignation = employeeResignationRepository
				.findOne(managerApproval.getResignationId().getrId());
		int i = 0;

		if (Constants.APPROVED.equalsIgnoreCase(managerApproval.getStatus())) {
			employeeResignation.setPreviousStatus(employeeResignation.getStatusCode());
			employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()).getStatusName());
			employeeResignation.setHrRMNo(employeeResignation.getHrBPMail());
			employeeResignation.setStatusCode(statusCodeRepository.findOne(StatusCode.TO_FN_MANAGER));	
			EmployeeInfo employeeInfo = employeeRepository.findOne(managerApproval.getRnNum().getRnNum());
			employeeInfo.setStatus(Constants.NOTICEPERIOD);
//			employeeResignation.setPreviousStatus(statusCodeRepository.findOne(managerApproval.getResignationId().getStatusCode().getStatusCode()));
//			employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(managerApproval.getResignationId().getStatusCode().getStatusCode()).getStatusName());	
			managerApproval.setRnNum(employeeInfo);
			i += 1;
		}
		if (Constants.APPROVED.equalsIgnoreCase(managerApproval.getFnMgrStatus())) {
			employeeResignation.setPreviousStatus(employeeResignation.getStatusCode());
			employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()).getStatusName());
			employeeResignation.setHrRMNo(employeeResignation.getHrBPMail());
			employeeResignation.setStatusCode(new Status(StatusCode.TO_HR_BP));
			//employeeResignation.setPreviousStatus(statusCodeRepository.findOne(managerApproval.getResignationId().getStatusCode().getStatusCode()));
			//employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(managerApproval.getResignationId().getStatusCode().getStatusCode()).getStatusName());	
			i += 1;
		}
		if (Constants.REJECTED.equalsIgnoreCase(managerApproval.getStatus())) {
			employeeResignation.setPreviousStatus(employeeResignation.getStatusCode());
			employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()).getStatusName());
			employeeResignation.setHrRMNo(employeeResignation.getHrBPMail());
			employeeResignation.setStatusCode(new Status(StatusCode.MANAGER_REJECTED));
			//employeeResignation.setPreviousStatus(statusCodeRepository.findOne(managerApproval.getResignationId().getStatusCode().getStatusCode()));
			//employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(managerApproval.getResignationId().getStatusCode().getStatusCode()).getStatusName());	
		}
		if (Constants.REJECTED.equalsIgnoreCase(managerApproval.getFnMgrStatus())) {
			employeeResignation.setPreviousStatus(employeeResignation.getStatusCode());
			employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()).getStatusName());
			employeeResignation.setHrRMNo(employeeResignation.getHrBPMail());
			employeeResignation.setStatusCode(new Status(StatusCode.FN_MANAGER_REJECTED));
		}
		managerApproval.setResignationId(employeeResignation);

		if (managerApproval.getRaId() == null) {
			ManagerApproval holder = managerApprovalRepository
					.findByRnNumRnNum(employeeResignation.getRnNum().getRnNum());
			if (null != holder) {
				managerApproval.setRaId(holder.getRaId());
			}
		}

		List<ManagerApproval> response = (List<ManagerApproval>) managerApprovalRepository
				.save((Iterable<ManagerApproval>) managerApprovals);
		if (i > 0) {
			updateHrStatus(employeeResignation);
		}
		return response;
	}

	private boolean updateHrStatus(EmployeeResignation employeeResignation) {
		
		try {
			HrApproval hrApproval = hrApprovalRepository.findByResignationIdRId(employeeResignation.getrId());
			if(hrApproval !=null){
				hrApproval.setHrRMStatus(Constants.PENDING);
				hrApproval.setResignationId(employeeResignation);
				hrApproval.setRnNum(employeeResignation.getRnNum());
				hrApprovalRepository.save(hrApproval);
			}else{
				HrApproval hrApprovalData = new HrApproval();
				hrApprovalData.setStatus(Constants.PENDING);
				hrApprovalData.setHrRMStatus(Constants.PENDING);
				hrApprovalData.setResignationId(employeeResignation);
				hrApprovalData.setRnNum(employeeResignation.getRnNum());
				hrApprovalRepository.save(hrApprovalData);
			}
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public ManagerApproval findByRnNumber(String rnNumber) {
		return managerApprovalRepository.findByRnNumRnNum(rnNumber);
	}

	@Override
	public List<ManagerApproval> revertRequest(List<ManagerApproval> managerApprovals) {
		List<ManagerApproval> response =new ArrayList<ManagerApproval>();
		ManagerApproval managerApproval = managerApprovals.get(0);
		
		if(Constants.StatusCode.REVERT_MANAGER_APPROVED==managerApproval.getResignationId().getStatusCode().getStatusCode()){
			if(Constants.StatusCode.TO_FN_MANAGER==(managerApproval.getResignationId().getPreviousStatus().getStatusCode())){
				revertApprove(managerApproval);
			}else if(Constants.StatusCode.TO_MANAGER ==(managerApproval.getResignationId().getPreviousStatus().getStatusCode())){
				revertApprove(managerApproval);
			}else if(Constants.StatusCode.TO_HR_BP == (managerApproval.getResignationId().getPreviousStatus().getStatusCode())){
				managerApprovals.get(0).setStatus(Constants.REVERT_APPROVED);
				managerApprovals.get(0).setFnMgrStatus(Constants.REVERT_PENDING);
				managerApprovals.get(0).setFnMgrComments(null);
				EmployeeResignation employeeResignation = employeeResignationRepository.findByRnNumRnNum(managerApprovals.get(0).getRnNum().getRnNum());
				managerApprovals.get(0).getResignationId().setPreviousStatus(employeeResignation.getStatusCode());
				managerApprovals.get(0).getResignationId().setEmpPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()).getStatusName());
				employeeResignation.setPreviousStatus(employeeResignation.getStatusCode());
				employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()).getStatusName());
				employeeResignation.setStatusCode(statusCodeRepository.findOne(Constants.StatusCode.REVERT_MANAGER_APPROVED));
				response = (List<ManagerApproval>) managerApprovalRepository.save
						((Iterable<ManagerApproval>) managerApprovals);
				employeeResignationRepository.save(employeeResignation);
				updateReverteHrApproval(managerApproval);
			}else if(Constants.StatusCode.REVERT_REQUEST == (managerApproval.getResignationId().getPreviousStatus().getStatusCode())){
				managerApprovals.get(0).setFnMgrStatus(Constants.REVERT_APPROVED);
				EmployeeResignation employeeResignation = employeeResignationRepository.findByRnNumRnNum(managerApprovals.get(0).getRnNum().getRnNum());
				employeeResignation.setPreviousStatus(employeeResignation.getStatusCode());
				employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()).getStatusName());
				employeeResignation.setStatusCode(statusCodeRepository.findOne(Constants.StatusCode.REVERT_FUNC_APPROVED));
				response = (List<ManagerApproval>) managerApprovalRepository.save
						((Iterable<ManagerApproval>) managerApprovals);
				employeeResignationRepository.save(employeeResignation);				
				HrApproval hrApproval = hrApprovalRepository.findByResignationIdRId(managerApprovals.get(0).getResignationId().getrId());
				if(hrApproval==null){
					updateReverteHrApproval(managerApproval);
				}
			}
			else{
				managerApprovals.get(0).setFnMgrStatus(Constants.REVERT_APPROVED);
				response = (List<ManagerApproval>) managerApprovalRepository
						.save((Iterable<ManagerApproval>) managerApprovals);
				updateReverteHrApproval(managerApproval);
			}
		}
		if(Constants.StatusCode.REVERT_FUNC_APPROVED==managerApproval.getResignationId().getStatusCode().getStatusCode()){
			if(Constants.StatusCode.REVERT_REQUEST == (managerApproval.getResignationId().getPreviousStatus().getStatusCode())){
				managerApprovals.get(0).setFnMgrStatus(Constants.REVERT_APPROVED);
				EmployeeResignation employeeResignation = employeeResignationRepository.findByRnNumRnNum(managerApprovals.get(0).getRnNum().getRnNum());
				employeeResignation.setPreviousStatus(employeeResignation.getStatusCode());
				employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()).getStatusName());
				employeeResignation.setStatusCode(statusCodeRepository.findOne(Constants.StatusCode.REVERT_FUNC_APPROVED));
				response = (List<ManagerApproval>) managerApprovalRepository.save
						((Iterable<ManagerApproval>) managerApprovals);
				employeeResignationRepository.save(employeeResignation);				
				HrApproval hrApproval = hrApprovalRepository.findByResignationIdRId(managerApprovals.get(0).getResignationId().getrId());
				if(hrApproval==null){
					updateReverteHrApproval(managerApproval);
				}
			}
		}
		if(Constants.StatusCode.REVERT_REQUEST==managerApproval.getResignationId().getStatusCode().getStatusCode()){
			if(Constants.StatusCode.TO_MANAGER==(managerApproval.getResignationId().getPreviousStatus().getStatusCode())){
				revertApprove(managerApproval);
			}else{
				managerApprovals.get(0).setStatus(Constants.REVERT_APPROVED);
				managerApprovals.get(0).setFnMgrStatus(Constants.REVERT_PENDING);
				
				response = (List<ManagerApproval>) managerApprovalRepository
						.save((Iterable<ManagerApproval>) managerApprovals);
			}
		}
		if(Constants.REVERT_REJECTED.equals(managerApproval.getStatus()) || Constants.REVERT_REJECTED.equals(managerApproval.getFnMgrStatus())){
			revertReject(managerApproval);
		}
		
		
		
		return response;
	}
	
	private void updateReverteHrApproval(ManagerApproval managerApproval) {
		HrApproval hrApprovalData = hrApprovalRepository.findByResignationIdRId(managerApproval.getResignationId().getrId());
		if(hrApprovalData !=null){
			hrApprovalData.setStatus(Constants.REVERT_PENDING);
			hrApprovalData.setResignationId(managerApproval.getResignationId());
			hrApprovalData.setRnNum(managerApproval.getResignationId().getRnNum());
			hrApprovalRepository.save(hrApprovalData);
		}
		else{
			HrApproval hrApproval = new HrApproval();
			hrApproval.setStatus(Constants.REVERT_PENDING);
			hrApproval.setResignationId(managerApproval.getResignationId());
			hrApproval.setRnNum(managerApproval.getResignationId().getRnNum());
			hrApprovalRepository.save(hrApproval);
		}
	}
	
	public void revertHrApprove(HrApproval hrApproval){
		EmployeeResignation employeeResignation = employeeResignationRepository.findOne(hrApproval.getResignationId().getrId());
		EmployeeInfo employeeInfo = employeeRepository.findOne(hrApproval.getRnNum().getRnNum());
		employeeInfo.setStatus(Constants.ACTIVE);
		employeeInfo.setExitDate(null);
		employeeInfo.setResignationDate(null);
		hrApprovalRepository.delete(hrApproval.getHraId());
		managerApprovalRepository.delete(hrApproval.getResignationId().getrId());
		employeeResignation.setPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()));
		employeeResignation.setStatusCode(statusCodeRepository.findOne(Constants.StatusCode.REVERTED));
		employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()).getStatusName());
		employeeResignationRepository.save(employeeResignation);
		employeeRepository.save(employeeInfo);
	}

	public void revertApprove(ManagerApproval managerApproval){
		EmployeeResignation employeeResignation = employeeResignationRepository
				.findOne(managerApproval.getResignationId().getrId());
		//EmployeeInfo info=managerApproval.getResignationId().getRnNum();
		EmployeeInfo employeeInfo = employeeRepository.findOne(managerApproval.getRnNum().getRnNum());
		employeeInfo.setStatus(Constants.ACTIVE);
		employeeInfo.setExitDate(null);
		employeeInfo.setResignationDate(null);
		managerApprovalRepository.delete(managerApproval.getRaId());
		employeeResignation.setPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()));
		employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()).getStatusName());
		employeeResignation.setStatusCode(statusCodeRepository.findOne(Constants.StatusCode.REVERTED));		
		employeeResignationRepository.save(employeeResignation);//update
		employeeRepository.save(employeeInfo);
	}
	
	public void revertReject(ManagerApproval managerApproval){
		if(Constants.StatusCode.TO_HR_BP==managerApproval.getResignationId().getPreviousStatus().getStatusCode()){
			managerApproval.setStatus(Constants.APPROVED);
			managerApproval.setFnMgrStatus(Constants.APPROVED);
		}else if(Constants.StatusCode.TO_FN_MANAGER==managerApproval.getResignationId().getPreviousStatus().getStatusCode()){
			managerApproval.setStatus(Constants.APPROVED);
			managerApproval.setFnMgrStatus(Constants.PENDING);
		}else if(Constants.StatusCode.TO_MANAGER==managerApproval.getResignationId().getPreviousStatus().getStatusCode()){
			managerApproval.setStatus(Constants.PENDING);
			managerApproval.setFnMgrStatus(Constants.PENDING);
		}
		managerApprovalRepository.save(managerApproval);
	}

}
