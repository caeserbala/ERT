package com.renaultdigital.client.employee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "esp_employee_change_history")
public class EmployeeChangeHistory implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "s_no")
	private Integer sNo;
	@Column(name = "department_change")
	private String departmentChange;
	@Column(name = "sub_department_change")
	private String subDepartmentChange;
	@Column(name = "designation_change")
	private String designationChange;
	@Column(name = "status_change")
	private String statusChange;
	@Column(name = "last_updated")
	@Temporal(TemporalType.DATE)
	private Date lastUpdated;
	@JoinColumn(name = "rn_num", referencedColumnName = "rn_num")
	@ManyToOne
	private EmployeeInfo rnNum;

	public EmployeeChangeHistory() {
	}

	public EmployeeChangeHistory(Integer sNo) {
		this.sNo = sNo;
	}

	public Integer getSNo() {
		return sNo;
	}

	public void setSNo(Integer sNo) {
		this.sNo = sNo;
	}

	public String getDepartmentChange() {
		return departmentChange;
	}

	public void setDepartmentChange(String departmentChange) {
		this.departmentChange = departmentChange;
	}

	public String getSubDepartmentChange() {
		return subDepartmentChange;
	}

	public void setSubDepartmentChange(String subDepartmentChange) {
		this.subDepartmentChange = subDepartmentChange;
	}

	public String getDesignationChange() {
		return designationChange;
	}

	public void setDesignationChange(String designationChange) {
		this.designationChange = designationChange;
	}

	public String getStatusChange() {
		return statusChange;
	}

	public void setStatusChange(String statusChange) {
		this.statusChange = statusChange;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public EmployeeInfo getRnNum() {
		return rnNum;
	}

	public void setRnNum(EmployeeInfo rnNum) {
		this.rnNum = rnNum;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((departmentChange == null) ? 0 : departmentChange.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeChangeHistory other = (EmployeeChangeHistory) obj;
		if (departmentChange == null) {
			if (other.departmentChange != null)
				return false;
		} else if (!departmentChange.equals(other.departmentChange))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "EmployeeChangeHistory[ sNo=" + sNo + " ]";
	}

}
