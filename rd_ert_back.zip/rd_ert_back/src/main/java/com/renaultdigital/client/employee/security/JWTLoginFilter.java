package com.renaultdigital.client.employee.security;

import java.io.IOException;
import java.util.Base64;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.fasterxml.jackson.core.JsonParser.Feature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.renaultdigital.client.employee.model.User;
import com.renaultdigital.client.employee.repository.IEmployeeRepository;
import com.renaultdigital.client.employee.repository.IEmployeeResignationRepository;
import com.renaultdigital.client.employee.repository.IRolesRepository;

public class JWTLoginFilter extends AbstractAuthenticationProcessingFilter {

	private TokenAuthenticationService tokenAuthenticationService;

	IRolesRepository iRolesRepository;
	IEmployeeResignationRepository resignationRepository;
	IEmployeeRepository employeeRepository;

	public JWTLoginFilter(String url, AuthenticationManager authenticationManager, IRolesRepository iRolesRepository,
			IEmployeeResignationRepository resignationRepository, IEmployeeRepository employeeRepository) {
		super(new AntPathRequestMatcher(url));
		this.iRolesRepository = iRolesRepository;
		this.resignationRepository = resignationRepository;
		this.employeeRepository = employeeRepository;
		setAuthenticationManager(authenticationManager);
		tokenAuthenticationService = new TokenAuthenticationService();
	}

	@Override
	public Authentication attemptAuthentication(HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) throws IOException, ServletException {

		logger.info("Attempting Authentication with LDAP....");

		ServletInputStream res = httpServletRequest.getInputStream();
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(Feature.AUTO_CLOSE_SOURCE, true);
		User credentials = objectMapper.readValue(res, User.class);

		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(credentials.getUserName(),
				new String(Base64.getDecoder().decode(credentials.getPassword())));
		return getAuthenticationManager().authenticate(token);
	}

	@Override
	protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain,
			Authentication authentication) throws IOException, ServletException {
		logger.info(" After Successful Authentication with LDAP....");
		String name = authentication.getName();
		logger.info(" Adding Token in Headers....");
		tokenAuthenticationService.addAuthentication(response, name, iRolesRepository, resignationRepository,
				employeeRepository);
	}
}
