package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.Department;
import com.renaultdigital.client.employee.repository.IDepartmentRepository;

@Service
public class DepartmentService implements IDepartmentService {

	@Autowired
	IDepartmentRepository departmentRepository;

	@Override
	public List<Department> getAllDepartments() {
		return departmentRepository.findAll();
	}

	@Override
	public List<Department> addOrUpdate(List<Department> department) {
		return (List<Department>) departmentRepository.save((Iterable<Department>) department);
	}

	@Override
	public Department getBydeptName(String deptName) {
		return departmentRepository.findByDeptNameEqualsIgnoreCase(deptName);
	}

}
