package com.renaultdigital.client.employee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "esp_training_approval")
public class TrainingApproval implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "ta_id")
	private Integer taId;
	@Column(name = "training_travel_agreeement")
	private String trainingTravelAgreeement;
	@Column(name = "duration")
	private Integer duration;
	@Column(name = "agreement_value")
	private String agreementValue;
	@Column(name = "start_date")
	@Temporal(TemporalType.DATE)
	private Date startDate;
	@Column(name = "end_date")
	@Temporal(TemporalType.DATE)
	private Date endDate;
	@Column(name = "bond_value")
	private Integer bondValue;
	@Column(name = "status")
	private String status;
	@JoinColumn(name = "domain_id", referencedColumnName = "domain_id")
	@ManyToOne
	private Domains domainId;
	@JoinColumn(name = "rn_num", referencedColumnName = "rn_num")
	@ManyToOne
	private EmployeeInfo rnNum;

	@JoinColumn(name = "r_id", referencedColumnName = "r_id")
	@ManyToOne
	private EmployeeResignation resignationId;

	@Column(name = "approved_date")
	@Temporal(TemporalType.DATE)
	private Date approvedDate;

	@Column(name = "comments")
	private String comments;

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public EmployeeResignation getResignationId() {
		return resignationId;
	}

	public void setResignationId(EmployeeResignation resignationId) {
		this.resignationId = resignationId;
	}

	public TrainingApproval() {
	}

	public TrainingApproval(Integer taId) {
		this.taId = taId;
	}

	public Integer getTaId() {
		return taId;
	}

	public void setTaId(Integer taId) {
		this.taId = taId;
	}

	public String getTrainingTravelAgreeement() {
		return trainingTravelAgreeement;
	}

	public void setTrainingTravelAgreeement(String trainingTravelAgreeement) {
		this.trainingTravelAgreeement = trainingTravelAgreeement;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getAgreementValue() {
		return agreementValue;
	}

	public void setAgreementValue(String agreementValue) {
		this.agreementValue = agreementValue;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getBondValue() {
		return bondValue;
	}

	public void setBondValue(Integer bondValue) {
		this.bondValue = bondValue;
	}

	public Domains getDomainId() {
		return domainId;
	}

	public void setDomainId(Domains domainId) {
		this.domainId = domainId;
	}

	public EmployeeInfo getRnNum() {
		return rnNum;
	}

	public void setRnNum(EmployeeInfo rnNum) {
		this.rnNum = rnNum;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((taId == null) ? 0 : taId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TrainingApproval other = (TrainingApproval) obj;
		if (taId == null) {
			if (other.taId != null)
				return false;
		} else if (!taId.equals(other.taId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TrainingApproval[ taId=" + taId + " ]";
	}

}
