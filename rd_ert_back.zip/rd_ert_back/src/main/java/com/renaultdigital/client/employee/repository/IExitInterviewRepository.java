package com.renaultdigital.client.employee.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.entity.ExitInterview;

@Repository
public interface IExitInterviewRepository extends CrudRepository<ExitInterview, Integer> {
	//ExitInterview findByRnNum(String rnNumber);

	ExitInterview findByRnNumRnNum(String employeeInfo);
}
