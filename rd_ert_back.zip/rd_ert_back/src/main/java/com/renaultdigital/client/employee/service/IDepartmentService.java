package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.Department;

public interface IDepartmentService {
	
	public List<Department> getAllDepartments();
	
	public List<Department> addOrUpdate(List<Department> department);

	public Department getBydeptName(String deptName);
	
	
}
