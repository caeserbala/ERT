package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.ItApproval;
import com.renaultdigital.client.employee.service.IItApprovalService;

@CrossOrigin
@RestController
@RequestMapping(path="/rd/ert/rest/v1/itapprovals/")
public class ItApprovalController {
	
	@Autowired
	IItApprovalService itApprovalService;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<ItApproval> getAllItApprovals(){
		return itApprovalService.getAllITApprovals();
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public List<ItApproval> addItApprovals(@RequestBody List<ItApproval> itApprovals){
		return itApprovalService.addOrUpdate(itApprovals);
	}
	
	
	@RequestMapping(path="{rnNum}", method=RequestMethod.GET)
	public ItApproval getById(@PathVariable String rnNum){
		return itApprovalService.findByRnNumber(rnNum);
	}
	
}
