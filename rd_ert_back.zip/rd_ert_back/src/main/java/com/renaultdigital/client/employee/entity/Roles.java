package com.renaultdigital.client.employee.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "esp_roles")
public class Roles implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "role_id")
	private Integer roleId;

	@Basic(optional = false)
	@Column(name = "to_email")
	private String toEmail;
	@Basic(optional = false)
	@Column(name = "cc_email")
	private String ccEmail;

	@JoinColumn(name = "domain_id", referencedColumnName = "domain_id")
	@ManyToOne
	private Domains domainId;
	@JoinColumn(name = "rn_num", referencedColumnName = "rn_num")
	@OneToOne
	private EmployeeInfo rnNum;

	public Roles() {
	}

	public Roles(Integer roleId) {
		this.roleId = roleId;
	}

	public Roles(Integer roleId, String toEmail, String ccEmail) {
		this.roleId = roleId;
		this.toEmail = toEmail;
		this.ccEmail = ccEmail;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getToEmail() {
		return toEmail;
	}

	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}

	public String getCcEmail() {
		return ccEmail;
	}

	public void setCcEmail(String ccEmail) {
		this.ccEmail = ccEmail;
	}

	public Domains getDomainId() {
		return domainId;
	}

	public void setDomainId(Domains domainId) {
		this.domainId = domainId;
	}

	public EmployeeInfo getRnNum() {
		return rnNum;
	}

	public void setRnNum(EmployeeInfo rnNum) {
		this.rnNum = rnNum;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((roleId == null) ? 0 : roleId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Roles other = (Roles) obj;
		if (roleId == null) {
			if (other.roleId != null)
				return false;
		} else if (!roleId.equals(other.roleId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Roles[ roleId=" + roleId + " ]";
	}

}
