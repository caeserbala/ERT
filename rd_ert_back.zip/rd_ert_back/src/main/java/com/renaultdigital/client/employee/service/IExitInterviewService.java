package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.ExitInterview;

public interface IExitInterviewService {

	List<ExitInterview> getExitInterview();

	List<ExitInterview> postExitInterview(List<ExitInterview> exitInterview);
	
	ExitInterview getByRnNumber(String employeeNo);
}
