package com.renaultdigital.client.employee.model;

/**
 * @author z021827
 *
 */
public class ApprovalStatus {

	private String finance;
	private String hr;
	private String it;
	private String manager;
	private String fmanager;
	private String hrRm;
	private String payroll;
	private String recruitment;
	private String security;
	private String travel;
	private String training;

	private String financeApprovalDate;
	private String hrApprovalDate;
	private String itApprovalDate;
	private String managerApprovalDate;
	private String fmanagerApprovalDate;
	private String hrRmApprovalDate;
	private String payrollApprovalDate;
	private String recruitmentApprovalDate;
	private String securityApprovalDate;
	private String travelApprovalDate;
	private String trainingApprovalDate;

	private String mgrComments;
	private String funcMgrComments;
	private String hrbpComments;
	private String hrrmComments;

	private String admin;
	private String adminApprovalDate;

	private String adminComments;
	private String financeComments;
	private String itComments;
	private String payrollComments;
	private String recruitmentComments;
	private String securityComments;
	private String travelComments;
	private String trainingComments;

	/**
	 * @param finance
	 * @param hr
	 * @param it
	 * @param manager
	 * @param fmanager
	 * @param hrRm
	 * @param payroll
	 * @param recruitment
	 * @param security
	 * @param travel
	 * @param training
	 * @param financeApprovalDate
	 * @param hrApprovalDate
	 * @param itApprovalDate
	 * @param managerApprovalDate
	 * @param fmanagerApprovalDate
	 * @param hrRmApprovalDate
	 * @param payrollApprovalDate
	 * @param recruitmentApprovalDate
	 * @param securityApprovalDate
	 * @param travelApprovalDate
	 * @param trainingApprovalDate
	 */
	public ApprovalStatus(String finance, String hr, String it, String manager, String fmanager, String hrRm,
			String payroll, String recruitment, String security, String training, String  travel,
			String financeApprovalDate, String hrApprovalDate, String itApprovalDate, String managerApprovalDate,
			String fmanagerApprovalDate, String hrRmApprovalDate, String payrollApprovalDate,
			String recruitmentApprovalDate, String securityApprovalDate, String travelApprovalDate,
			String trainingApprovalDate, String mgrComments, String funcMgrComments, String hrbpComments,
			String hrrmComments, String admin, String adminApprovalDate, String adminComments, String financeComments,
			String itComments, String payrollComments, String recruitmentComments, String securityComments,
			String travelComments, String trainingComments) {
		super();
		this.finance = finance;
		this.hr = hr;
		this.it = it;
		this.manager = manager;
		this.fmanager = fmanager;
		this.hrRm = hrRm;
		this.payroll = payroll;
		this.recruitment = recruitment;
		this.security = security;
		this.travel = travel;
		this.training = training;

		this.financeApprovalDate = financeApprovalDate;
		this.hrApprovalDate = hrApprovalDate;
		this.itApprovalDate = itApprovalDate;
		this.managerApprovalDate = managerApprovalDate;
		this.fmanagerApprovalDate = fmanagerApprovalDate;
		this.hrRmApprovalDate = hrRmApprovalDate;
		this.payrollApprovalDate = payrollApprovalDate;
		this.recruitmentApprovalDate = recruitmentApprovalDate;
		this.securityApprovalDate = securityApprovalDate;
		this.travelApprovalDate = travelApprovalDate;
		this.trainingApprovalDate = trainingApprovalDate;
		this.mgrComments = mgrComments;
		this.funcMgrComments = funcMgrComments;
		this.hrbpComments = hrbpComments;
		this.hrrmComments = hrrmComments;
		this.admin = admin;
		this.adminApprovalDate = adminApprovalDate;

		this.adminComments = adminComments;
		this.financeComments = financeComments;
		this.itComments = itComments;
		this.payrollComments = payrollComments;
		this.recruitmentComments = recruitmentComments;
		this.securityComments = securityComments;
		this.travelComments = travelComments;
		this.trainingComments = trainingComments;
	}

	public String getFinance() {
		return finance;
	}

	public void setFinance(String finance) {
		this.finance = finance;
	}

	public String getHr() {
		return hr;
	}

	public void setHr(String hr) {
		this.hr = hr;
	}

	public String getIt() {
		return it;
	}

	public void setIt(String it) {
		this.it = it;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getFmanager() {
		return fmanager;
	}

	public void setFmanager(String fmanager) {
		this.fmanager = fmanager;
	}

	public String getHrRm() {
		return hrRm;
	}

	public void setHrRm(String hrRm) {
		this.hrRm = hrRm;
	}

	public String getPayroll() {
		return payroll;
	}

	public void setPayroll(String payroll) {
		this.payroll = payroll;
	}

	public String getRecruitment() {
		return recruitment;
	}

	public void setRecruitment(String recruitment) {
		this.recruitment = recruitment;
	}

	public String getSecurity() {
		return security;
	}

	public void setSecurity(String security) {
		this.security = security;
	}

	public String getTravel() {
		return travel;
	}

	public void setTravel(String travel) {
		this.travel = travel;
	}

	public String getTraining() {
		return training;
	}

	public void setTraining(String training) {
		this.training = training;
	}

	public String getFinanceApprovalDate() {
		return financeApprovalDate;
	}

	public void setFinanceApprovalDate(String financeApprovalDate) {
		this.financeApprovalDate = financeApprovalDate;
	}

	public String getHrApprovalDate() {
		return hrApprovalDate;
	}

	public void setHrApprovalDate(String hrApprovalDate) {
		this.hrApprovalDate = hrApprovalDate;
	}

	public String getItApprovalDate() {
		return itApprovalDate;
	}

	public void setItApprovalDate(String itApprovalDate) {
		this.itApprovalDate = itApprovalDate;
	}

	public String getManagerApprovalDate() {
		return managerApprovalDate;
	}

	public void setManagerApprovalDate(String managerApprovalDate) {
		this.managerApprovalDate = managerApprovalDate;
	}

	public String getFmanagerApprovalDate() {
		return fmanagerApprovalDate;
	}

	public void setFmanagerApprovalDate(String fmanagerApprovalDate) {
		this.fmanagerApprovalDate = fmanagerApprovalDate;
	}

	public String getHrRmApprovalDate() {
		return hrRmApprovalDate;
	}

	public void setHrRmApprovalDate(String hrRmApprovalDate) {
		this.hrRmApprovalDate = hrRmApprovalDate;
	}

	public String getPayrollApprovalDate() {
		return payrollApprovalDate;
	}

	public void setPayrollApprovalDate(String payrollApprovalDate) {
		this.payrollApprovalDate = payrollApprovalDate;
	}

	public String getRecruitmentApprovalDate() {
		return recruitmentApprovalDate;
	}

	public void setRecruitmentApprovalDate(String recruitmentApprovalDate) {
		this.recruitmentApprovalDate = recruitmentApprovalDate;
	}

	public String getSecurityApprovalDate() {
		return securityApprovalDate;
	}

	public void setSecurityApprovalDate(String securityApprovalDate) {
		this.securityApprovalDate = securityApprovalDate;
	}

	public String getTravelApprovalDate() {
		return travelApprovalDate;
	}

	public void setTravelApprovalDate(String travelApprovalDate) {
		this.travelApprovalDate = travelApprovalDate;
	}

	public String getTrainingApprovalDate() {
		return trainingApprovalDate;
	}

	public void setTrainingApprovalDate(String trainingApprovalDate) {
		this.trainingApprovalDate = trainingApprovalDate;
	}

	public String getMgrComments() {
		return mgrComments;
	}

	public void setMgrComments(String mgrComments) {
		this.mgrComments = mgrComments;
	}

	public String getFuncMgrComments() {
		return funcMgrComments;
	}

	public void setFuncMgrComments(String funcMgrComments) {
		this.funcMgrComments = funcMgrComments;
	}

	public String getHrbpComments() {
		return hrbpComments;
	}

	public void setHrbpComments(String hrbpComments) {
		this.hrbpComments = hrbpComments;
	}

	public String getHrrmComments() {
		return hrrmComments;
	}

	public void setHrrmComments(String hrrmComments) {
		this.hrrmComments = hrrmComments;
	}

	public String getAdmin() {
		return admin;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}

	public String getAdminApprovalDate() {
		return adminApprovalDate;
	}

	public void setAdminApprovalDate(String adminApprovalDate) {
		this.adminApprovalDate = adminApprovalDate;
	}

	public String getAdminComments() {
		return adminComments;
	}

	public void setAdminComments(String adminComments) {
		this.adminComments = adminComments;
	}

	public String getFinanceComments() {
		return financeComments;
	}

	public void setFinanceComments(String financeComments) {
		this.financeComments = financeComments;
	}

	public String getItComments() {
		return itComments;
	}

	public void setItComments(String itComments) {
		this.itComments = itComments;
	}

	public String getPayrollComments() {
		return payrollComments;
	}

	public void setPayrollComments(String payrollComments) {
		this.payrollComments = payrollComments;
	}

	public String getRecruitmentComments() {
		return recruitmentComments;
	}

	public void setRecruitmentComments(String recruitmentComments) {
		this.recruitmentComments = recruitmentComments;
	}

	public String getSecurityComments() {
		return securityComments;
	}

	public void setSecurityComments(String securityComments) {
		this.securityComments = securityComments;
	}

	public String getTravelComments() {
		return travelComments;
	}

	public void setTravelComments(String travelComments) {
		this.travelComments = travelComments;
	}

	public String getTrainingComments() {
		return trainingComments;
	}

	public void setTrainingComments(String trainingComments) {
		this.trainingComments = trainingComments;
	}

	@Override
	public String toString() {
		return "ApprovalStatus [finance=" + finance + ", hr=" + hr + ", it=" + it + ", manager=" + manager
				+ ", fmanager=" + fmanager + ", hrRm=" + hrRm + ", payroll=" + payroll + ", recruitment=" + recruitment
				+ ", security=" + security + ", travel=" + travel + ", training=" + training + ", financeApprovalDate="
				+ financeApprovalDate + ", hrApprovalDate=" + hrApprovalDate + ", itApprovalDate=" + itApprovalDate
				+ ", managerApprovalDate=" + managerApprovalDate + ", fmanagerApprovalDate=" + fmanagerApprovalDate
				+ ", hrRmApprovalDate=" + hrRmApprovalDate + ", payrollApprovalDate=" + payrollApprovalDate
				+ ", recruitmentApprovalDate=" + recruitmentApprovalDate + ", securityApprovalDate="
				+ securityApprovalDate + ", travelApprovalDate=" + travelApprovalDate + ", trainingApprovalDate="
				+ trainingApprovalDate + ", mgrComments=" + mgrComments + ", funcMgrComments=" + funcMgrComments
				+ ", hrbpComments=" + hrbpComments + ", hrrmComments=" + hrrmComments + ", admin=" + admin
				+ ", adminApprovalDate=" + adminApprovalDate + ", adminComments=" + adminComments + ", financeComments="
				+ financeComments + ", itComments=" + itComments + ", payrollComments=" + payrollComments
				+ ", recruitmentComments=" + recruitmentComments + ", securityComments=" + securityComments
				+ ", travelComments=" + travelComments + ", trainingComments=" + trainingComments + "]";
	}

	public ApprovalStatus() {
	}

}
