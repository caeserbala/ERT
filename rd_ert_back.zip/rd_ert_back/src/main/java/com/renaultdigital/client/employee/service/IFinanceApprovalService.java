package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.FinanceApproval;

public interface IFinanceApprovalService {
	
	public List<FinanceApproval> getAllFinanceApprovals();
	
	public List<FinanceApproval> addOrUpdate(List<FinanceApproval> financeApprovals);

	public FinanceApproval getByRnNum(String rnNum);

}
