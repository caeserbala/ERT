package com.renaultdigital.client.employee.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.entity.HrApproval;
import com.renaultdigital.client.employee.entity.Status;
import com.renaultdigital.client.employee.repository.IEmployeeRepository;
import com.renaultdigital.client.employee.repository.IEmployeeResignationRepository;
import com.renaultdigital.client.employee.repository.IHrApprovalRepository;
import com.renaultdigital.client.employee.repository.IManagerApprovalRepository;
import com.renaultdigital.client.employee.repository.IStatusRepository;
import com.renaultdigital.client.employee.util.Constants;
import com.renaultdigital.client.employee.util.Constants.StatusCode;

@Service
class HrApprovalService implements IHrApprovalService {

	@Autowired
	IHrApprovalRepository hrApprovalRepository;

	@Autowired
	IEmployeeRepository employeeRepository;

	@Autowired
	IStatusRepository statusCodeRepository;

	@Autowired
	IEmployeeResignationRepository employeeResignationRepository;
	
	@Autowired
	IManagerApprovalRepository managerApprovalRepository;

	@Override
	public List<HrApproval> getAllHrApprovals() {
		return hrApprovalRepository.findAll();
	}

	@Override
	public List<HrApproval> addOrUpdate(List<HrApproval> hrApprovals) {
		HrApproval hrApproval = hrApprovals.get(0);
		EmployeeResignation employeeResignation = employeeResignationRepository
				.findOne(hrApproval.getResignationId().getrId());

		if (Constants.APPROVED.equalsIgnoreCase(hrApproval.getStatus())) {
			employeeResignation.setStatusCode(statusCodeRepository.findOne(StatusCode.TO_HR_RM));
		}
		if (Constants.APPROVED.equalsIgnoreCase(hrApproval.getHrRMStatus())) {
			employeeResignation.setStatusCode(new Status(StatusCode.HR_RM_APPROVED));
			EmployeeInfo empInfo=employeeRepository.findByIpnEqualsIgnoreCaseOrRnNumEqualsIgnoreCase(hrApproval.getRnNum().getRnNum(), hrApproval.getRnNum().getRnNum());
			empInfo.setStatus(Constants.INACTIVE);
			employeeRepository.save(empInfo);
		}
		if (Constants.REJECTED.equalsIgnoreCase(hrApproval.getStatus())) {
			employeeResignation.setStatusCode(new Status(StatusCode.HR_BP_REJECT));
		}
		if (Constants.REJECTED.equalsIgnoreCase(hrApproval.getHrRMStatus())) {
			employeeResignation.setStatusCode(new Status(StatusCode.HR_RM_REJECT));
		}

		hrApproval.setResignationId(employeeResignation);

		if (hrApproval.getHraId() == null) {
			HrApproval holder = hrApprovalRepository.findByRnNumRnNum(employeeResignation.getRnNum().getRnNum());
			if (null != holder) {
				hrApproval.setHraId(holder.getHraId());
			}
		}

		return (List<HrApproval>) hrApprovalRepository.save((Iterable<HrApproval>) hrApprovals);
	}
	
	@Override
	public List<HrApproval> revertRequest(List<HrApproval> hrApprovals) {
		List<HrApproval> response =new ArrayList<HrApproval>();
		HrApproval hrApproval = hrApprovals.get(0);		
		if(Constants.StatusCode.REVERT_HRBP_APPROVED==hrApproval.getResignationId().getStatusCode().getStatusCode()){
			if(Constants.StatusCode.REVERT_FUNC_APPROVED==(hrApproval.getResignationId().getPreviousStatus().getStatusCode())){
				revertApprove(hrApproval);
			}else if(Constants.StatusCode.REVERT_MANAGER_APPROVED ==(hrApproval.getResignationId().getPreviousStatus().getStatusCode())){
				revertApprove(hrApproval);
			}	
		}
		if(Constants.REVERT_REJECTED.equals(hrApproval.getStatus()) || Constants.REVERT_REJECTED.equals(hrApproval.getHrRMStatus())){
			revertHrReject(hrApproval);
		}
		return response;
	}
	

	@Override
	public void revertApprove(HrApproval hrApproval){
		EmployeeResignation employeeResignation = employeeResignationRepository.findOne(hrApproval.getResignationId().getrId());
		EmployeeInfo employeeInfo = employeeRepository.findOne(hrApproval.getRnNum().getRnNum());
		employeeInfo.setStatus(Constants.ACTIVE);
		employeeInfo.setExitDate(null);
		employeeInfo.setResignationDate(null);
		hrApprovalRepository.delete(hrApproval.getHraId());
		managerApprovalRepository.delete(hrApproval.getResignationId().getrId());
		employeeResignation.setPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()));
		employeeResignation.setStatusCode(statusCodeRepository.findOne(Constants.StatusCode.REVERTED));
		employeeResignation.setEmpPreviousStatus(statusCodeRepository.findOne(employeeResignation.getStatusCode().getStatusCode()).getStatusName());
		employeeResignationRepository.save(employeeResignation);
		employeeRepository.save(employeeInfo);
	}	
	
	
	

	@Override
	public HrApproval getByRnNumber(String rnNum) {
		return hrApprovalRepository.findByRnNumRnNum(rnNum);
	}

	
	@Override
	public void revertHrReject(HrApproval hrApproval) {
		// TODO Auto-generated method stub
		if(Constants.StatusCode.REVERT_FUNC_APPROVED==hrApproval.getResignationId().getPreviousStatus().getStatusCode()){
			hrApproval.setStatus(Constants.APPROVED);
			hrApproval.setHrRMStatus(Constants.PENDING);
			hrApproval.setApprovedDate(new Date());
		}else if(Constants.StatusCode.REVERT_HRBP_APPROVED==hrApproval.getResignationId().getPreviousStatus().getStatusCode()){
			hrApproval.setStatus(Constants.APPROVED);
			hrApproval.setHrRMStatus(Constants.APPROVED);
			hrApproval.setApprovedDate(new Date());
		}
		hrApprovalRepository.save(hrApproval);
	}
}
