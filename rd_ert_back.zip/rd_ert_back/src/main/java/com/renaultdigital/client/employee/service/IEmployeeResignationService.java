package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.model.ApprovalStatus;

public interface IEmployeeResignationService {

	public List<EmployeeResignation> getAllEmployeeResignations();

	public List<EmployeeResignation> addOrUpdate(List<EmployeeResignation> employeeResignationInfos);

	public List<EmployeeResignation> getResignationsByManager(String rnNumber);

	public EmployeeResignation getByRnNumber(String rnNumber);

	public ApprovalStatus getApprovalStatusByRnNumber(String rnNumber);

	public Boolean getResignationAvailableForManager(String rnNumber);

	public List<EmployeeResignation> getResignationsByFnManager(String rnNumber);

	public List<EmployeeResignation> getResignationsByHrBP(String rnNumber);

	public List<EmployeeResignation> getResignationsByHrRM(String rnNumber);

	public int removeResignationRecord(String rId);

}
