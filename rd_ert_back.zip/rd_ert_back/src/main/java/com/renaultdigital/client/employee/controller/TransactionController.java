package com.renaultdigital.client.employee.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.TransactionLog;
import com.renaultdigital.client.employee.service.ITransactionService;

@CrossOrigin
@RestController
@RequestMapping(path = "/rd/ert/rest/v1/transaction/")
public class TransactionController {

	@Autowired
	ITransactionService transactionService;

	@RequestMapping(method = RequestMethod.GET)
	public List<TransactionLog> getAllTransactionLogs() {
		return transactionService.getAllTransactionLogs();
	}

	@RequestMapping(method = RequestMethod.POST)
	public List<TransactionLog> addTransactionLogs(@RequestBody List<TransactionLog> transactionLogs) {
		transactionLogs.forEach(item -> item.setLogDate(new Date()));
		return transactionService.addOrUpdate(transactionLogs);
	}

	@RequestMapping(path = "employee/{empRn}", method = RequestMethod.GET)
	public List<TransactionLog> geLogByEmpRn(@PathVariable String empRn) {
		return transactionService.findByEmpRn(empRn);
	}

	@RequestMapping(path = "manager/{mgrRn}", method = RequestMethod.GET)
	public List<TransactionLog> geLogByMgrRn(@PathVariable String mgrRn) {
		return transactionService.findByMgrRn(mgrRn);
	}

	@RequestMapping(path = "empAndmgr/{mgrRn}/employee/{empRn}", method = RequestMethod.GET)
	public List<TransactionLog> geLogByMgrRnAndEmpRn(@PathVariable String mgrRn, @PathVariable String empRn) {
		return transactionService.findByMgrRnAndEmpRn(mgrRn, empRn);
	}

}
