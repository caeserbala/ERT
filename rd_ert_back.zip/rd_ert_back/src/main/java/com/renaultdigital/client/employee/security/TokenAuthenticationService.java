
package com.renaultdigital.client.employee.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;

import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.entity.Roles;
import com.renaultdigital.client.employee.repository.IEmployeeRepository;
import com.renaultdigital.client.employee.repository.IEmployeeResignationRepository;
import com.renaultdigital.client.employee.repository.IRolesRepository;
import com.renaultdigital.client.employee.util.LdapUtil;
import com.renaultdigital.client.employee.util.RenoConstants;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class TokenAuthenticationService {

	public static final Logger LOGGER = LoggerFactory.getLogger(TokenAuthenticationService.class);

	public List<String> getRolesFromDomain(IRolesRepository iRolesRepository, String username) {
		LOGGER.info("Searching Role in Domain Table {}", username);
		List<String> role = new ArrayList<>();
		List<Roles> roles = iRolesRepository.findByRnNumIpnEqualsIgnoreCase(username);
		if (roles != null && (!roles.isEmpty())) {

			for (Roles item : roles) {
				if (item != null && item.getDomainId() != null) {
					role.add(item.getDomainId().getDomainName());
				} else {
					role.add(RenoConstants.EMPLOYEE_ROLE);
				}
			}

		}
		return role;
	}

	public List<String> getRolesFromDatabase(IEmployeeResignationRepository resignationRepository, String rnNum) {
		LOGGER.info("Searching Role in Seperation Table {}", rnNum);
		List<String> role = new ArrayList<>();

		List<EmployeeResignation> fnmgrList = resignationRepository.findByFuncMgrRnnoEqualsIgnoreCase(rnNum);
		if (null != fnmgrList && (!fnmgrList.isEmpty())) {
			role.add("L1MANAGER");
		}
		List<EmployeeResignation> rmgrList = resignationRepository.findByReportingMgrNoEqualsIgnoreCase(rnNum);
		if (null != rmgrList && (!rmgrList.isEmpty())) {
			role.add("MANAGER");
		}
		List<EmployeeResignation> hrbpList = resignationRepository.findByHrBPMailEqualsIgnoreCase(rnNum);
		if (null != hrbpList && (!hrbpList.isEmpty())) {
			role.add("HRBP");
		}
		List<EmployeeResignation> hrRMList = resignationRepository.findByHrRMNoEqualsIgnoreCase(rnNum);
		if (null != hrRMList && (!hrRMList.isEmpty())) {
			role.add("HRRM");
		}

		if (role.isEmpty()) {
			role.add(RenoConstants.EMPLOYEE_ROLE);
		}

		return role;
	}

	public void addAuthentication(HttpServletResponse response, String username, IRolesRepository iRolesRepository,
			IEmployeeResignationRepository resignationRepository, IEmployeeRepository employeeRepository)
			throws IOException {

		Map<String, Object> userDetails = new HashMap<>();
		EmployeeInfo employee = null;
		String rnNum = "";
		JSONObject obj = null;
		List<String> role = new ArrayList<>();

		try {

			userDetails = LdapUtil.authenticate(username);
			userDetails.remove("dn");
			userDetails.remove("photo");

			employee = employeeRepository.findByIpnEqualsIgnoreCase(username);

			if (employee != null) {
				rnNum = employee.getRnNum();
				role = getRolesFromDomain(iRolesRepository, username);
				if (role.isEmpty())
					role = getRolesFromDatabase(resignationRepository, rnNum);
			} else
				role.add(RenoConstants.EMPLOYEE_ROLE);

		} catch (Exception e) {
			role.add(RenoConstants.EMPLOYEE_ROLE);
			LOGGER.error("Error in fetching user details : {}", e.getMessage());
		}
		userDetails.put("role", role);

		String jwt = Jwts.builder().setSubject(username)
				.setExpiration(new Date(System.currentTimeMillis() + RenoConstants.EXPIRATIONTIME))
				.setIssuer(RenoConstants.RD_TEAM).signWith(SignatureAlgorithm.HS256, RenoConstants.SECRET_STRING)
				.compact();

		LOGGER.info("Issued Time : {}", new Date());
		LOGGER.info("Expiration Time : {}", new Date(System.currentTimeMillis() + RenoConstants.EXPIRATIONTIME));
		obj = new JSONObject(userDetails);

		response.setContentType(RenoConstants.CONTENT_TYPE_TEXT_STRING);

		response.addHeader(RenoConstants.ALLOW_HEADERS, RenoConstants.ALLOW_HEADERS_VALUE);
		response.addHeader(RenoConstants.CONTENT_TYPE, RenoConstants.CONTENT_TYPE_JSON_STRING);
		response.addHeader(RenoConstants.HEADER_STRING, RenoConstants.TOKEN_PREFIX_STRING + jwt);
		response.addHeader(RenoConstants.EXPOSE_HEADERS,
				RenoConstants.HEADER_STRING + "," + RenoConstants.CONTENT_TYPE);
		response.getWriter().write(obj.toString());

	}

	public Authentication getAuthentication(HttpServletRequest request) {
		LOGGER.info("verifying token");

		String token = request.getHeader(RenoConstants.HEADER_STRING);

		if (token != null) {
			String username = Jwts.parser().setSigningKey(RenoConstants.SECRET_STRING)
					.parseClaimsJws(token.replace(RenoConstants.TOKEN_PREFIX_STRING, "")).getBody().getSubject();

			return new AuthenticatedUser(username);
		} else
			return new AuthenticatedUser("temp");

	}

}
