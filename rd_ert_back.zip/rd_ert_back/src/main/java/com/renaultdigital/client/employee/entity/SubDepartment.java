package com.renaultdigital.client.employee.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "esp_sub_department")
public class SubDepartment implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "sub_depart_name")
	private String subDepartName;
	@Column(name = "cost_centre_cd")
	private String costCentreCd;
	@Column(name = "cost_centre_desc")
	private String costCentreDesc;
	@JoinColumn(name = "dept_name", referencedColumnName = "dept_name")
	@ManyToOne(optional = false)
	private Department deptName;

	public SubDepartment() {
	}

	public SubDepartment(String subDepartName) {
		this.subDepartName = subDepartName;
	}

	public String getSubDepartName() {
		return subDepartName;
	}

	public void setSubDepartName(String subDepartName) {
		this.subDepartName = subDepartName;
	}

	public String getCostCentreCd() {
		return costCentreCd;
	}

	public void setCostCentreCd(String costCentreCd) {
		this.costCentreCd = costCentreCd;
	}

	public String getCostCentreDesc() {
		return costCentreDesc;
	}

	public void setCostCentreDesc(String costCentreDesc) {
		this.costCentreDesc = costCentreDesc;
	}

	public Department getDeptName() {
		return deptName;
	}

	public void setDeptName(Department deptName) {
		this.deptName = deptName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((subDepartName == null) ? 0 : subDepartName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SubDepartment other = (SubDepartment) obj;
		if (subDepartName == null) {
			if (other.subDepartName != null)
				return false;
		} else if (!subDepartName.equals(other.subDepartName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SubDepartment[ subDepartName=" + subDepartName + " ]";
	}

}
