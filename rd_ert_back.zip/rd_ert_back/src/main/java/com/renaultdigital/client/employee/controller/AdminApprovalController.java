package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.AdminApproval;
import com.renaultdigital.client.employee.service.IAdminApprovalService;

@CrossOrigin
@RestController
@RequestMapping(path="/rd/ert/rest/v1/adminapprovals/")
public class AdminApprovalController {
	
	@Autowired
	IAdminApprovalService adminApprovalService; 
	
	@RequestMapping(method=RequestMethod.GET)
	public List<AdminApproval> getAllAdminApprovals(){
		return adminApprovalService.getAllAdminApprovals();
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public List<AdminApproval> addAdminAprrovals(@RequestBody List<AdminApproval> adminApprovals){
		return adminApprovalService.addOrUpdate(adminApprovals);
	}
	
	
	@RequestMapping(path="{rnNum}", method=RequestMethod.GET)
	public AdminApproval getById(@PathVariable String rnNum){
		return adminApprovalService.findByRnNumber(rnNum);
	}
	
}
