package com.renaultdigital.client.employee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "esp_hr_approval")
public class HrApproval implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "hra_id")
	private Integer hraId;
	@Column(name = "exit_intv_completion")
	private Boolean exitIntvCompletion;
	@Column(name = "medical_insurance_cards")
	private Boolean medicalInsuranceCards;
	@Column(name = "certification_fee")
	private Boolean certificationFee;
	@Column(name = "commitment_per_agreement")
	private Boolean commitmentPerAgreement;
	@Column(name = "library")
	private Boolean library;
	@Column(name = "comments")
	private String comments;
	@Column(name = "initiate_erf")
	private Boolean initiateErf;
	@Column(name = "status")
	private String status;
	@Column(name = "hr_mgr_status")
	private String hrRMStatus;
	@JoinColumn(name = "rn_num", referencedColumnName = "rn_num")
	@ManyToOne
	private EmployeeInfo rnNum;

	@JoinColumn(name = "r_id", referencedColumnName = "r_id")
	@ManyToOne
	private EmployeeResignation resignationId;
	@Column(name = "approved_date")
	@Temporal(TemporalType.DATE)
	private Date approvedDate;
	@Column(name = "hr_mgr_approved_date")
	@Temporal(TemporalType.DATE)
	private Date hrMgrApprovedDate;
	@Column(name = "leave_balance")
	private Integer leaveBalance;
	@Column(name = "notice_period_recovery")
	private Integer noticePeriodRecovery;
	@Column(name = "hr_mgr_comments")
	private String hrMgrComments;

	public EmployeeResignation getResignationId() {
		return resignationId;
	}

	public void setResignationId(EmployeeResignation resignationId) {
		this.resignationId = resignationId;
	}

	public HrApproval() {
	}

	public HrApproval(Integer hraId) {
		this.hraId = hraId;
	}

	public Integer getHraId() {
		return hraId;
	}

	public void setHraId(Integer hraId) {
		this.hraId = hraId;
	}

	public Boolean getExitIntvCompletion() {
		return exitIntvCompletion;
	}

	public void setExitIntvCompletion(Boolean exitIntvCompletion) {
		this.exitIntvCompletion = exitIntvCompletion;
	}

	public Boolean getMedicalInsuranceCards() {
		return medicalInsuranceCards;
	}

	public void setMedicalInsuranceCards(Boolean medicalInsuranceCards) {
		this.medicalInsuranceCards = medicalInsuranceCards;
	}

	public Boolean getCertificationFee() {
		return certificationFee;
	}

	public void setCertificationFee(Boolean certificationFee) {
		this.certificationFee = certificationFee;
	}

	public Boolean getCommitmentPerAgreement() {
		return commitmentPerAgreement;
	}

	public void setCommitmentPerAgreement(Boolean commitmentPerAgreement) {
		this.commitmentPerAgreement = commitmentPerAgreement;
	}

	public Boolean getLibrary() {
		return library;
	}

	public void setLibrary(Boolean library) {
		this.library = library;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Boolean getInitiateErf() {
		return initiateErf;
	}

	public void setInitiateErf(Boolean initiateErf) {
		this.initiateErf = initiateErf;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public EmployeeInfo getRnNum() {
		return rnNum;
	}

	public void setRnNum(EmployeeInfo rnNum) {
		this.rnNum = rnNum;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public Date getHrMgrApprovedDate() {
		return hrMgrApprovedDate;
	}

	public void setHrMgrApprovedDate(Date hrMgrApprovedDate) {
		this.hrMgrApprovedDate = hrMgrApprovedDate;
	}

	public String getHrRMStatus() {
		return hrRMStatus;
	}

	public void setHrRMStatus(String hrRMStatus) {
		this.hrRMStatus = hrRMStatus;
	}

	public Integer getLeaveBalance() {
		return leaveBalance;
	}

	public void setLeaveBalance(Integer leaveBalance) {
		this.leaveBalance = leaveBalance;
	}

	public Integer getNoticePeriodRecovery() {
		return noticePeriodRecovery;
	}

	public void setNoticePeriodRecovery(Integer noticePeriodRecovery) {
		this.noticePeriodRecovery = noticePeriodRecovery;
	}

	public String getHrMgrComments() {
		return hrMgrComments;
	}

	public void setHrMgrComments(String hrMgrComments) {
		this.hrMgrComments = hrMgrComments;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hraId == null) ? 0 : hraId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HrApproval other = (HrApproval) obj;
		if (hraId == null) {
			if (other.hraId != null)
				return false;
		} else if (!hraId.equals(other.hraId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "com.renaultdigital.client.Employee.Entity.HrApproval[ hraId=" + hraId + " ]";
	}

}
