package com.renaultdigital.client.employee.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.renaultdigital.client.employee.model.DataCount;

import edu.emory.mathcs.backport.java.util.Arrays;

/**
 * @author z022191
 *
 */
public class Utils {

	private Utils() {
		// setting up util class
	}

	public static String getString(String data, String key) {
		return data.toUpperCase().startsWith(key) ? data : null;
	}

	public static String getAsString(Object object) {
		return String.valueOf(object);
	}

	public static double getPercerntage(int total, int value) {
		double val = (double) value * 100;
		return (val / total);
	}

	public static JsonArray getReportInPercerntage(List<DataCount> dataCounts, String label) {
		JsonArray reportArray = new JsonArray();
		for (DataCount dc : dataCounts) {
			JsonObject report = new JsonObject();
			report.addProperty(label, dc.getData());
			report.addProperty(Constants.PERCENTAGE_KEY, Utils.getPercerntage(dc.getTotal(), dc.getCount()));
			reportArray.add(report);
		}
		return reportArray;
	}

	public static JsonArray getReportInCount(List<DataCount> dataCounts, String keyLable, String valueLable) {
		JsonArray reportArray = new JsonArray();
		for (DataCount dc : dataCounts) {
			JsonObject report = new JsonObject();
			report.addProperty(keyLable, dc.getData());
			report.addProperty(valueLable, dc.getCount());
			reportArray.add(report);
		}
		return reportArray;
	}

	public static JsonArray getReportInCount(List<DataCount> dataCounts, String keyLable, String addKeyLable,
			String valueLable) {
		JsonArray reportArray = new JsonArray();
		for (DataCount dc : dataCounts) {
			JsonObject report = new JsonObject();
			report.addProperty(keyLable, dc.getData());
			report.addProperty(addKeyLable, dc.getAdditionalData());
			report.addProperty(valueLable, dc.getCount());
			reportArray.add(report);
		}
		return reportArray;
	}

	public static JsonArray getReportInCount1(List<DataCount> dataCounts, String keyLable, String addKeyLable,
			String valueLable) {
		JsonArray reportArray = new JsonArray();
		List<String> monthList = Arrays.asList(
				new String[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" });

		for (DataCount dc : dataCounts) {
			for (String month : monthList) {
				JsonObject report = new JsonObject();
				if (month.equalsIgnoreCase(dc.getAdditionalData())) {
					report.addProperty(keyLable, dc.getData());
					report.addProperty(valueLable, dc.getCount());
					report.addProperty(addKeyLable, dc.getAdditionalData());
					reportArray.add(report);
				} else {
					report.addProperty(keyLable, dc.getData());
					report.addProperty(valueLable, 0);
					report.addProperty(addKeyLable, month);
					reportArray.add(report);
				}
			}

		}

		return reportArray;
	}

	public static Date getDateFromString(String startDate) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.parse(startDate);
	}

	public static JsonArray getReportGroupedByDepartmentAndDesignation(List<DataCount> dataCounts) {
		JsonArray reportArray = new JsonArray();
		for (DataCount dc : dataCounts) {
			JsonObject report = new JsonObject();
			report.addProperty(Constants.DEPARTMENT_KEY, dc.getAdditionalData());
			report.addProperty(Constants.DESIGNATION_KEY, dc.getData());
			report.addProperty(Constants.PERCENTAGE_KEY, dc.getCount());
			reportArray.add(report);
		}
		return reportArray;
	}

}
