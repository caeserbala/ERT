package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.TravelApproval;

public interface ITravelApprovalService {

	List<TravelApproval> getAllTrainingApprovals();

	List<TravelApproval> addOrUpdate(List<TravelApproval> travelApprovals);

	TravelApproval findByRnNumber(String rnNum);
	

}
