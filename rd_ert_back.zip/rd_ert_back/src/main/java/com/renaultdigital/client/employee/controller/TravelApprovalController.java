package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.TravelApproval;
import com.renaultdigital.client.employee.service.ITravelApprovalService;

@CrossOrigin
@RestController
@RequestMapping(path="/rd/ert/rest/v1/travelapprovals/")
public class TravelApprovalController {
	
	@Autowired
	ITravelApprovalService travelApprovalService;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<TravelApproval> getAllTravelApprovals(){
		return travelApprovalService.getAllTrainingApprovals();
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public List<TravelApproval> addTravelAprrovals(@RequestBody List<TravelApproval> travelApprovals){
		return travelApprovalService.addOrUpdate(travelApprovals);
	}
	
	
	@RequestMapping(path="{rnNum}", method=RequestMethod.GET)
	public TravelApproval getById(@PathVariable String rnNum){
		return travelApprovalService.findByRnNumber(rnNum);
	}
	
}
