package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.Domains;

public interface IDomainService {
	
	public List<Domains> getAllDomains();
	
	public List<Domains> addOrUpdate(List<Domains> domains);

	public Domains getById(String domainId);

}
