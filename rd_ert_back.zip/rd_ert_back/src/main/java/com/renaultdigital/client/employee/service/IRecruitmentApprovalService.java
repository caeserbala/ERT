package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.RecruitmentApproval;

public interface IRecruitmentApprovalService {

	List<RecruitmentApproval> getAllRecruitmentApprovals();

	List<RecruitmentApproval> addOrUpdate(List<RecruitmentApproval> recruitmentApprovals);

	RecruitmentApproval findByRnNumber(String rnNum);

}
