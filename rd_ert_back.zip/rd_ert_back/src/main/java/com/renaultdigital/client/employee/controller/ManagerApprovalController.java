package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.ManagerApproval;
import com.renaultdigital.client.employee.service.IManagerApprovalService;

@CrossOrigin
@RestController
@RequestMapping(path="/rd/ert/rest/v1/managerapprovals/")
public class ManagerApprovalController {
	
	@Autowired
	IManagerApprovalService managerApprovalService;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<ManagerApproval> getAllManagerApprovals(){
		return managerApprovalService.getAllManagerApprovals();
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public List<ManagerApproval> addManagerApprovals(@RequestBody List<ManagerApproval> managerApprovals){
		return managerApprovalService.addOrUpdate(managerApprovals);
	}
	
	
	@RequestMapping(path="{rnNum}", method=RequestMethod.GET)
	public ManagerApproval getById(@PathVariable String rnNum){
		return managerApprovalService.findByRnNumber(rnNum);
	}
	
	@RequestMapping(path="revert",method=RequestMethod.POST)
	public List<ManagerApproval> revertRequest(@RequestBody List<ManagerApproval> managerApprovals){
		return managerApprovalService.revertRequest(managerApprovals);
	}
	
}
