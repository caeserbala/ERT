package com.renaultdigital.client.employee.config;

import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.renaultdigital.client.employee.repository.IEmployeeRepository;
import com.renaultdigital.client.employee.repository.IEmployeeResignationRepository;
import com.renaultdigital.client.employee.repository.IRolesRepository;
import com.renaultdigital.client.employee.security.JWTAuthenticationFilter;
import com.renaultdigital.client.employee.security.JWTLoginFilter;
import com.renaultdigital.client.employee.util.RenoConstants;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	public static final Logger LOGGER = LoggerFactory.getLogger(WebSecurityConfig.class);

	@Autowired
	IRolesRepository iRolesRepository;

	@Autowired
	IEmployeeResignationRepository resignationRepository;
	
	@Autowired
	IEmployeeRepository employeeRepository;

	@Override
	@CrossOrigin
	protected void configure(HttpSecurity http) throws Exception {
		// disable caching
		LOGGER.info("Configuring auth filter");
		http.headers().cacheControl();
		http.csrf().disable().authorizeRequests().antMatchers("/").permitAll()
				.antMatchers(HttpMethod.POST, RenoConstants.LOGIN_FILTER_URI_STRING).permitAll().anyRequest()
				.authenticated().and()
				.addFilterBefore(
						new JWTLoginFilter(RenoConstants.LOGIN_FILTER_URI_STRING, authenticationManager(),
								iRolesRepository, resignationRepository, employeeRepository),
						UsernamePasswordAuthenticationFilter.class)
				.addFilterBefore(new JWTAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		LOGGER.info("Establishing the Ldap Connection");
		auth.ldapAuthentication().userSearchFilter(RenoConstants.SEARCH_FILTER_STRING)
				.userSearchBase(RenoConstants.CONTEXT_SEARCH).contextSource().url(RenoConstants.LDAPURI)
				.managerDn(RenoConstants.DN)
				.managerPassword(new String(Base64.getDecoder().decode(RenoConstants.PW_STRING))).and()
				.groupSearchBase(RenoConstants.GROUP_SEARCH_BASE_STRING).rolePrefix(RenoConstants.ROLE_PREFIX_STRING)
				.userSearchFilter(RenoConstants.USERSEARCHFILTER_STRING);
	}

}
