package com.renaultdigital.client.employee.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.entity.ManagerApproval;
import com.renaultdigital.client.employee.model.ApprovalStatus;
import com.renaultdigital.client.employee.repository.IEmployeeRepository;
import com.renaultdigital.client.employee.repository.IEmployeeResignationRepository;
import com.renaultdigital.client.employee.repository.IManagerApprovalRepository;
import com.renaultdigital.client.employee.repository.IStatusRepository;
import com.renaultdigital.client.employee.util.Constants;
import com.renaultdigital.client.employee.util.DBUtils;
import com.renaultdigital.client.employee.util.MailUtils;
import com.renaultdigital.client.employee.util.Utils;

@Service
public class EmployeeResignationService implements IEmployeeResignationService {

	@Autowired
	IEmployeeResignationRepository employeeResignationRepository;

	@Autowired
	IEmployeeRepository employeeRepository;
		
	@Autowired
	IManagerApprovalRepository managerApprovalRepository;
	
	@Autowired
	IStatusRepository statusCodeRepository;
	
	@PersistenceContext
	EntityManager em;

	@Override
	public List<EmployeeResignation> getAllEmployeeResignations() {
		return employeeResignationRepository.findAll();
	}

	@Override
	public List<EmployeeResignation> addOrUpdate(List<EmployeeResignation> employeeResignationInfos) {
		List<EmployeeResignation> employeeResignations = new ArrayList<EmployeeResignation>();
		EmployeeResignation employeeResignation = new EmployeeResignation();
		EmployeeInfo employeeInfo = new EmployeeInfo();
		boolean doStuff = false;
		if (Constants.StatusCode.REVERT_REQUEST==employeeResignationInfos.get(0).getStatusCode().getStatusCode()) {
			//Added by z022483 - Arul for revert by employee still not manager approval
			if(Constants.StatusCode.TO_MANAGER == employeeResignationInfos.get(0).getPreviousStatus().getStatusCode()){
				employeeInfo = employeeRepository.findByIpnEqualsIgnoreCaseOrRnNumEqualsIgnoreCase(null, employeeResignationInfos.get(0).getRnNum().getRnNum());
				employeeInfo.setExitDate(null);
				employeeInfo.setResignationDate(null);
				if(employeeResignationInfos.get(0).getrId() != 0 || employeeResignationInfos.get(0).getrId()!=null){
					employeeResignation = employeeResignationInfos.get(0);
					ManagerApproval managerApproval = managerApprovalRepository.findByRnNumRnNum(employeeResignationInfos.get(0).getRnNum().getRnNum());
					try {
						managerApprovalRepository.delete(managerApproval.getRaId());
						EmployeeResignation resignation = employeeResignationRepository.findByRnNumRnNum(employeeResignationInfos.get(0).getRnNum().getRnNum());
						employeeResignationRepository.delete(resignation);
						employeeRepository.save(employeeInfo);
						triggerMailToManager(employeeResignation, false);
						
					} catch (Exception e) {
						e.printStackTrace();
					}
					
					//	Long test = employeeResignationRepository.deleteByRnNumRnNum(employeeResignation.getRnNum().getRnNum());
					//employeeRepository.save(employeeResignationInfos.get(0));
					/*employeeResignations = (List<EmployeeResignation>) employeeResignationRepository
							.save((Iterable<EmployeeResignation>) employeeResignationInfos);*/
					//triggerMailToManager(employeeResignation, false);
				}
			}else{
				employeeResignations = (List<EmployeeResignation>) employeeResignationRepository
					.save((Iterable<EmployeeResignation>) employeeResignationInfos);			
				updateApprovalsInfo(employeeResignations.get(0));
				employeeResignation=employeeResignations.get(0);
			}
		} 
		else {
			int rId = employeeResignationInfos.get(0).getrId();
			if (rId == 0) {
				doStuff = true;
			}
			for (EmployeeResignation employeeResign : employeeResignationInfos) {
				EmployeeInfo info = employeeRepository.findByEmailEqualsIgnoreCase(employeeResign.getHrBPMail());
				if (info != null && info.getRnNum() != "") {
					employeeResign.setHrBPMail(info.getRnNum());
				}
			}
			employeeResignations = (List<EmployeeResignation>) employeeResignationRepository
					.save((Iterable<EmployeeResignation>) employeeResignationInfos);
			employeeResignation = employeeResignations.get(0);
			employeeResignation.setExitDate(employeeResignationInfos.get(0).getExitDate());
			EmployeeResignation employeeResignationObj = employeeResignationRepository.findByRnNumRnNum(employeeResignationInfos.get(0).getRnNum().getRnNum());
			if(employeeResignationObj != null){
				if(Constants.StatusCode.TO_MANAGER == employeeResignationInfos.get(0).getStatusCode().getStatusCode()){
					employeeResignationInfos.get(0).setrId(employeeResignationObj.getrId());
					employeeResignationInfos.get(0).setPreviousStatus(employeeResignationObj.getStatusCode());
					employeeResignationInfos.get(0).setEmpPreviousStatus(statusCodeRepository.findOne(employeeResignationObj.getStatusCode().getStatusCode()).getStatusName());
				}
			}
			if (doStuff) {
				updateEmployeeInfo(employeeResignation);
				updateApprovalsInfo(employeeResignation);

			}
		}
		triggerMailToManager(employeeResignation, doStuff);
		return employeeResignations;
	}

	private void updateApprovalsInfo(EmployeeResignation employeeResignation) {
		// Manager Approval
		ManagerApproval managerApproval = new ManagerApproval();
		if (employeeResignation.getPreviousStatus() != null) {
			managerApproval=managerApprovalRepository.findByRnNumRnNum(employeeResignation.getRnNum().getRnNum());
			if (Constants.StatusCode.TO_MANAGER == employeeResignation.getPreviousStatus().getStatusCode()) {
				managerApproval.setStatus(Constants.REVERT_PENDING);
			}
			if (Constants.StatusCode.TO_FN_MANAGER == employeeResignation.getPreviousStatus().getStatusCode()) {
				managerApproval.setStatus(Constants.REVERT_PENDING);
				managerApproval.setFnMgrStatus(Constants.REVERT_PENDING);
			}
			if(Constants.StatusCode.TO_HR_BP == employeeResignation.getPreviousStatus().getStatusCode()
					|| Constants.StatusCode.TO_HR_RM == employeeResignation.getPreviousStatus().getStatusCode()){
				managerApproval.setStatus(Constants.REVERT_PENDING);
				managerApproval.setFnMgrStatus(Constants.REVERT_PENDING);
			}
			managerApproval.setResignationId(employeeResignation);
			managerApproval.setRnNum(employeeResignation.getRnNum());
		} else {

			managerApproval.setStatus(Constants.PENDING);
			managerApproval.setFnMgrStatus(Constants.PENDING);
			managerApproval.setResignationId(employeeResignation);
			managerApproval.setRnNum(employeeResignation.getRnNum());

		}
		managerApprovalRepository.save(managerApproval);
	}

	private void updateEmployeeInfo(EmployeeResignation employeeResignation) {
		EmployeeInfo employeeInfo = employeeResignation.getRnNum();
		Date resignationDate = employeeResignation.getDateOfResignation();
		employeeInfo.setResignationDate(resignationDate);
		Calendar c = Calendar.getInstance();
		c.setTime(resignationDate);
		c.add(Calendar.DATE, Constants.NOTICEPERIOD_DAYS);
		Date exitDate = c.getTime();
		employeeInfo.setExitDate(employeeResignation.getExitDate());
		employeeResignation.setRnNum(employeeRepository.save(employeeInfo));
	}

	@Override
	public List<EmployeeResignation> getResignationsByManager(String rnNumber) {
		return employeeResignationRepository.findByReportingMgrNo(rnNumber);
	}

	@Override
	public EmployeeResignation getByRnNumber(String rnNumber) {
		return employeeResignationRepository.findByRnNumRnNum(rnNumber);
	}
	
	@Override
	@Transactional
	public int removeResignationRecord(String rId){
		int deleteRecord = DBUtils.executeUpdateQuery(em, Constants.DELETE_RESIGNATION_QUERY.replace(Constants.ASTERIK, rId));
		return deleteRecord;
	}
	
	@Override
	public ApprovalStatus getApprovalStatusByRnNumber(String rnNumber) {
		Object[] resultSet = DBUtils.executeNativeQueryForApprovalStatus(em,
				Constants.APPROVAL_STATUS_QUERY.replace(Constants.ASTERIK, rnNumber));

		if (null != resultSet && resultSet.length != 0) {
			return new ApprovalStatus(Utils.getAsString(resultSet[0]), Utils.getAsString(resultSet[1]),
					Utils.getAsString(resultSet[2]), Utils.getAsString(resultSet[3]), Utils.getAsString(resultSet[4]),
					Utils.getAsString(resultSet[5]), Utils.getAsString(resultSet[6]), Utils.getAsString(resultSet[7]),
					Utils.getAsString(resultSet[8]), Utils.getAsString(resultSet[9]), Utils.getAsString(resultSet[10]),
					Utils.getAsString(resultSet[11]), Utils.getAsString(resultSet[12]),
					Utils.getAsString(resultSet[13]), Utils.getAsString(resultSet[14]),
					Utils.getAsString(resultSet[15]), Utils.getAsString(resultSet[16]),
					Utils.getAsString(resultSet[17]), Utils.getAsString(resultSet[18]),
					Utils.getAsString(resultSet[19]), Utils.getAsString(resultSet[20]),
					Utils.getAsString(resultSet[21]), Utils.getAsString(resultSet[22]),
					Utils.getAsString(resultSet[23]), Utils.getAsString(resultSet[24]),
					Utils.getAsString(resultSet[25]), Utils.getAsString(resultSet[26]),
					Utils.getAsString(resultSet[27]), Utils.getAsString(resultSet[28]),
					Utils.getAsString(resultSet[29]), Utils.getAsString(resultSet[30]),
					Utils.getAsString(resultSet[31]), Utils.getAsString(resultSet[32]),
					Utils.getAsString(resultSet[33]), Utils.getAsString(resultSet[34]),
					Utils.getAsString(resultSet[35]));

		}
		return null;
	}

	@Override
	public Boolean getResignationAvailableForManager(String rnNumber) {
		Long avail = employeeResignationRepository.countByReportingMgrNo(rnNumber);
		return (avail > 0) ? true : false;

	}

	private void triggerMailToManager(EmployeeResignation employeeResignation, boolean reqFlag) {

		String name = new StringBuilder().append(employeeResignation.getRnNum().getFirstName()).append(Constants.SPACE)
				.append(employeeResignation.getRnNum().getLastName()).toString();
		String rnNum = employeeResignation.getRnNum().getRnNum();

		String subject = null;
		String body = null;
		if( Constants.StatusCode.REVERT_REQUEST==employeeResignation.getStatusCode().getStatusCode()){
			if(employeeResignation.getExitDate() == null){
				subject = MailUtils.getSubjectForESPMailNotification(name,rnNum);
				body = MailUtils.getBodyForESPMailNotification(name,rnNum);
			}else{
			subject = MailUtils.getSubjectForESPMailApproval(name, rnNum);
			body = MailUtils.getBodyForESPMailApproval(name, rnNum);
			}
		}else{
		if (reqFlag) {
			subject = MailUtils.getSubjectForESPMailApproval(name, rnNum);
			body = MailUtils.getBodyForESPMailApproval(name, rnNum);
		} else {
			subject = MailUtils.getSubjectForESPMailRequestClarification(name, rnNum);
			body = MailUtils.getBodyForESPMailRequestClarification(name, rnNum);
		}
		}

		// String mailTo =
		// "Bakiyaraj.Arulsantiagu@rntbci.com,sasikumar.kamaraj@rntbci.com";
		String mailTo = "Bakiyaraj.Arulsantiagu@rntbci.com";
		// employeeRepository.findByIpnEqualsIgnoreCaseOrRnNumEqualsIgnoreCase(
		// mgrRnNum,mgrRnNum) .getEmail();
		String mailCC = "arul.gunasekaran@rntbci.com";
		// employeeResignation.getSubDepartName().getDeptName().getHrSpoc();

		MailUtils.triggerEmail(mailTo, mailCC, subject, body);
	}

	@Override
	public List<EmployeeResignation> getResignationsByFnManager(String rnNumber) {
		return employeeResignationRepository.findByFuncMgrRnnoEqualsIgnoreCase(rnNumber);
	}

	@Override
	public List<EmployeeResignation> getResignationsByHrBP(String rnNumber) {
		return employeeResignationRepository.findByHrBPMailEqualsIgnoreCase(rnNumber);
	}

	@Override
	public List<EmployeeResignation> getResignationsByHrRM(String rnNumber) {
		return employeeResignationRepository.findByHrRMNoEqualsIgnoreCase(rnNumber);
	}

}
