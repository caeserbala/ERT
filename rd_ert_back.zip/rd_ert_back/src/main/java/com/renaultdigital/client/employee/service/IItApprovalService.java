package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.ItApproval;

public interface IItApprovalService {
	
	List<ItApproval> getAllITApprovals();

	List<ItApproval> addOrUpdate(List<ItApproval> itApprovals);

	ItApproval findByRnNumber(String rnNum);
	
}
