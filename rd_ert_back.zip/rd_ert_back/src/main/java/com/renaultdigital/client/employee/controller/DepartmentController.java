package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.Department;
import com.renaultdigital.client.employee.service.IDepartmentService;

@CrossOrigin
@RestController
@RequestMapping(path="/rd/ert/rest/v1/departments/")
public class DepartmentController {
	
	@Autowired
	IDepartmentService departmentService;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Department> getAllDepartments(){
		return departmentService.getAllDepartments();
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public List<Department> addDepartments(@RequestBody List<Department> departments){
		return departmentService.addOrUpdate(departments);
	}
	
	
	@RequestMapping(path="{deptName}", method=RequestMethod.GET)
	public Department getByDeptName(@PathVariable String deptName){
		return departmentService.getBydeptName(deptName);
	}
	
	
}
