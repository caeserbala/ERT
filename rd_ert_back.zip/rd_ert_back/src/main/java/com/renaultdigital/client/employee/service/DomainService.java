package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.Domains;
import com.renaultdigital.client.employee.repository.IDomainRepository;

@Service
public class DomainService implements IDomainService{
	
	@Autowired
	IDomainRepository domainRepository;
	
	@Override
	public List<Domains> getAllDomains() {
		return domainRepository.findAll();
	}

	@Override
	public List<Domains> addOrUpdate(List<Domains> domains) {
		return (List<Domains>) domainRepository.save((Iterable<Domains>) domains);
	}

	@Override
	public Domains getById(String domainId) {
		return domainRepository.findOne(Integer.valueOf(domainId));
	}

}
