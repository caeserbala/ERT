package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.PayrollApproval;

public interface IPayrollApprovalService {

	List<PayrollApproval> getAllPayrollApprovals();

	List<PayrollApproval> addOrUpdate(List<PayrollApproval> payrollApprovals);

	PayrollApproval findByRnNumber(String rnNum);

}
