package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.RecruitmentApproval;
import com.renaultdigital.client.employee.repository.IRecruitmentApprovalRepo;

@Service
public class RecruitmentApprovalService implements IRecruitmentApprovalService {

	@Autowired
	IRecruitmentApprovalRepo approvalRepo;

	@Override
	public List<RecruitmentApproval> getAllRecruitmentApprovals() {
		return approvalRepo.findAll();
	}

	@Override
	public List<RecruitmentApproval> addOrUpdate(List<RecruitmentApproval> recruitmentApprovals) {
		return approvalRepo.save(recruitmentApprovals);
	}

	@Override
	public RecruitmentApproval findByRnNumber(String rnNum) {
		return approvalRepo.findByRnNumRnNum(rnNum);
	}

}
