package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.AdminApproval;

public interface IAdminApprovalService {
	
	List<AdminApproval> getAllAdminApprovals();

	List<AdminApproval> addOrUpdate(List<AdminApproval> adminApprovals);

	AdminApproval findByRnNumber(String rnNum);
	
}
