package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.TrainingApproval;

public interface ITrainingApprovalService {

	List<TrainingApproval> getAllTrainingApprovals();

	List<TrainingApproval> addOrUpdate(List<TrainingApproval> payrollApprovals);

	TrainingApproval findByRnNumber(String rnNum);

}

