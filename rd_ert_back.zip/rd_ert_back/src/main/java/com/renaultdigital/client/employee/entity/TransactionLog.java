package com.renaultdigital.client.employee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "esp_transacton_log")
public class TransactionLog implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "log_id")
	private Integer logId;

	@Column(name = "mgr_rn_no")
	private String mgrNo;

	@Column(name = "emp_rn_no")
	private String empRnNo;

	@Column(name = "action")
	private String action;

	@Column(name = "log_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date logDate;

	public Integer getLogId() {
		return logId;
	}

	public void setLogId(Integer logId) {
		this.logId = logId;
	}

	public String getMgrNo() {
		return mgrNo;
	}

	public void setMgrNo(String mgrNo) {
		this.mgrNo = mgrNo;
	}

	public String getEmpRnNo() {
		return empRnNo;
	}

	public void setEmpRnNo(String empRnNo) {
		this.empRnNo = empRnNo;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Date getLogDate() {
		return logDate;
	}

	public void setLogDate(Date logDate) {
		this.logDate = logDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((logId == null) ? 0 : logId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionLog other = (TransactionLog) obj;
		if (logId == null) {
			if (other.logId != null)
				return false;
		} else if (!logId.equals(other.logId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TransactionLog [logId=" + logId + ", mgrNo=" + mgrNo + ", empRnNo=" + empRnNo + ", action=" + action
				+ ", logDate=" + logDate + "]";
	}

}
