package com.renaultdigital.client.employee.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.TravelApproval;

@Repository
public interface ITravelApprovalRepository extends CrudRepository<TravelApproval, Integer> {
	
	List<TravelApproval> findAll();

	TravelApproval findByRnNumRnNum(String instanceFromRnNumber);
	
}
