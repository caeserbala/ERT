package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.PayrollApproval;
import com.renaultdigital.client.employee.service.IPayrollApprovalService;

@CrossOrigin
@RestController
@RequestMapping(path="/rd/ert/rest/v1/payrollapprovals/")
public class PayrollApprovalController {
	
	@Autowired
	IPayrollApprovalService payrollApprovalService;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<PayrollApproval> getAllPayrollApprovals(){
		return payrollApprovalService.getAllPayrollApprovals();
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public List<PayrollApproval> addPayrollApprovals(@RequestBody List<PayrollApproval> payrollApprovals){
		return payrollApprovalService.addOrUpdate(payrollApprovals);
	}
	
	
	@RequestMapping(path="{rnNum}", method=RequestMethod.GET)
	public PayrollApproval getById(@PathVariable String rnNum){
		return payrollApprovalService.findByRnNumber(rnNum);
	}
	
}
