package com.renaultdigital.client.employee.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.renaultdigital.client.employee.entity.EmployeeInfo;

public interface IEmployeeService {
	public List<EmployeeInfo> getAllEmployeeInfos();

	public List<EmployeeInfo> addOrUpdate(List<EmployeeInfo> employeeInfos);

	public EmployeeInfo getEmployee(String employeeId);

	public List<EmployeeInfo> getEmployeeByName(String name);

	public JsonArray getEmployeeReportByGender();

	public JsonArray getEmployeeReportByDesignation();

	public JsonArray getEmployeeReportByDepartmentWithDate(String startDate, String endDate);

	public JsonArray getEmployeeReportByDepartment();

	public JsonArray getEmployeeReportByDepartmentWithDesignation();

	public JsonArray getEmployeeReportByReason();

	public JsonObject getEmployeeOverAllReport();

	List<EmployeeInfo> getAllEmployeeInfos(Pageable pageable);

	public JsonArray getEmployeeReportByYear();

	public JsonArray getEmployeeReportByYearAndDept(String year, String dept);

	public Map<String, Object> getYears();

}
