package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.SubDepartment;
import com.renaultdigital.client.employee.repository.ISubDepartmentRepository;

@Service
public class SubDepartmentService implements ISubDepartmentService {

	@Autowired
	ISubDepartmentRepository subDepartmentRepository;

	@Override
	public List<SubDepartment> getAllSubDepartments() {
		return subDepartmentRepository.findAll();
	}

	@Override
	public List<SubDepartment> addOrUpdate(List<SubDepartment> subDepartments) {
		return (List<SubDepartment>) subDepartmentRepository.save((Iterable<SubDepartment>) subDepartments);
	}

	@Override
	public SubDepartment getBySubDeptName(String subDeptName) {
		return subDepartmentRepository.findBySubDepartNameEqualsIgnoreCase(subDeptName);
	}

	@Override
	public List<SubDepartment> getSubDeptByDeptName(String deptName) {
		return subDepartmentRepository.findByDeptNameDeptNameEqualsIgnoreCase(deptName);
	}

}
