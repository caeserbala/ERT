package com.renaultdigital.client.employee.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.repository.IEmployeeRepository;
import com.renaultdigital.client.employee.repository.IEmployeeResignationRepository;
import com.renaultdigital.client.employee.util.Constants;
import com.renaultdigital.client.employee.util.Utils;

@Service
public class EmployeeService implements IEmployeeService {

	private final Logger logger = LoggerFactory.getLogger(EmployeeService.class);

	@Autowired
	IEmployeeRepository employeeRepository;

	@Autowired
	IEmployeeResignationRepository employeeResignationRepository;

	@Override
	public List<EmployeeInfo> getAllEmployeeInfos() {
		return employeeRepository.findAll();
	}

	@Override
	public List<EmployeeInfo> getAllEmployeeInfos(Pageable pageable) {
		return employeeRepository.findAll(pageable);
	}

	@Override
	public List<EmployeeInfo> addOrUpdate(List<EmployeeInfo> employeeInfos) {
		return (List<EmployeeInfo>) employeeRepository.save((Iterable<EmployeeInfo>) employeeInfos);
	}

	@Override
	public EmployeeInfo getEmployee(String employeeId) {
		return employeeRepository.findByIpnEqualsIgnoreCaseOrRnNumEqualsIgnoreCase(
				Utils.getString(employeeId, Constants.Z_ID_INTIAL),
				Utils.getString(employeeId, Constants.RN_NUM_INTIAL));
	}

	@Override
	public List<EmployeeInfo> getEmployeeByName(String name) {
		return employeeRepository.findByFirstNameStartsWithIgnoreCaseOrLastNameStartsWithIgnoreCase(name, name);
	}

	@Override
	public JsonArray getEmployeeReportByGender() {
		return Utils.getReportInCount(employeeRepository.findExitReportByGender(Constants.INACTIVE),
				Constants.GENDER_KEY, Constants.PERCENTAGE_KEY);
	}

	@Override
	public JsonArray getEmployeeReportByDesignation() {
		return Utils.getReportInCount(employeeRepository.findExitReportByDesignation(Constants.INACTIVE),
				Constants.DESIGNATION_KEY, Constants.COUNT_KEY);
	}

	@Override
	public JsonArray getEmployeeReportByDepartmentWithDate(String startDate, String endDate) {
		try {
			return Utils.getReportInCount(
					employeeRepository.findExitReportByDepartmentWithDate(Utils.getDateFromString(startDate),
							Utils.getDateFromString(endDate), Constants.INACTIVE),
					Constants.DEPARTMENT_KEY, Constants.COUNT_KEY);

		} catch (ParseException e) {
			logger.info("Exception occurs while Parsing : {} ", e.getMessage());
		}
		return null;

	}

	@Override
	public JsonArray getEmployeeReportByDepartment() {
		return Utils.getReportInCount(employeeRepository.findExitReportByDepartment(Constants.INACTIVE),
				Constants.DEPARTMENT_KEY, Constants.COUNT_KEY);

	}

	@Override
	public JsonArray getEmployeeReportByDepartmentWithDesignation() {
		return Utils.getReportGroupedByDepartmentAndDesignation(
				employeeRepository.findExitReportByDepartmentWithDesignation(Constants.INACTIVE));
	}

	@Override
	public JsonObject getEmployeeOverAllReport() {
		JsonObject overAllReport = new JsonObject();
		overAllReport.add(Constants.GENDER_KEY, getEmployeeReportByGender());
		overAllReport.add(Constants.DEPARTMENT_KEY, getEmployeeReportByDepartment());
		overAllReport.add(Constants.DESIGNATION_KEY, getEmployeeReportByDesignation());
		overAllReport.add(Constants.DEPARTMENT_DESIGNATION_KEY, getEmployeeReportByDepartmentWithDesignation());
		overAllReport.add(Constants.REASON_KEY, getEmployeeReportByReason());
		return overAllReport;
	}

	@Override
	public JsonArray getEmployeeReportByReason() {
		return Utils.getReportInCount(employeeRepository.findExitReportByReason(Constants.INACTIVE),
				Constants.REASON_KEY, Constants.COUNT_KEY);
	}

	@Override
	public JsonArray getEmployeeReportByYear() {
		return Utils.getReportInCount(employeeRepository.findExitReportByYear(Constants.INACTIVE),
				Constants.RESIGNATIONS_KEY, Constants.COUNT_KEY);
	}

	@Override
	public JsonArray getEmployeeReportByYearAndDept(String year, String dept) {
		Date sdate = null;
		Date edate = null;
		try {
			String[] value = year.split("-");
			sdate = Utils.getDateFromString(value[0].trim() + "-04-01");
			edate = Utils.getDateFromString(value[1].trim() + "-03-31");
		} catch (ParseException e) {
			logger.info("ParseException" + e.getMessage());
		}
		if ("all".equalsIgnoreCase(dept)) {
			return Utils.getReportInCount1(
					employeeRepository.findExitReportByYearandDept(Constants.INACTIVE, sdate, edate),
					Constants.DEPARTMENT_KEY, Constants.MONTH_KEY, Constants.COUNT_KEY);
		} else {
			return Utils.getReportInCount1(
					employeeRepository.findExitReportByYearandDept(Constants.INACTIVE, dept, sdate, edate),
					Constants.DEPARTMENT_KEY, Constants.MONTH_KEY, Constants.COUNT_KEY);
		}
	}

	@Override
	public Map<String, Object> getYears() {
		Map<String, Object> resultMap = new HashMap<>();
		List<String> yearList = new ArrayList<>();
		List<Integer> list = employeeRepository.findDistinctYears(Constants.INACTIVE);
		if (null != list && !list.isEmpty()) {
			for (Integer year : list) {
				yearList.add(year + "-" + (year + 1));
			}
			resultMap.put("yearList", yearList);
		}
		String year = Calendar.getInstance().get(Calendar.YEAR) + "-" + (Calendar.getInstance().get(Calendar.YEAR) + 1);
		String array = getEmployeeReportByYearAndDept(year, "all").toString();
		if (null != array)
			resultMap.put("initialReport", array);
		return resultMap;
	}

}
