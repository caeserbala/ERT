package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.Roles;

public interface IRolesService {

	public List<Roles> getAllRoles();

	public List<Roles> addOrUpdate(List<Roles> roles);

	public Roles getByRoleId(String roleId);

	public void deleteRole(int roleId);

}
