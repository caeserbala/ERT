package com.renaultdigital.client.employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.RecruitmentApproval;

@Repository
public interface IRecruitmentApprovalRepo extends JpaRepository<RecruitmentApproval, Integer> {

	RecruitmentApproval findByRnNumRnNum(String rnNum);
}
