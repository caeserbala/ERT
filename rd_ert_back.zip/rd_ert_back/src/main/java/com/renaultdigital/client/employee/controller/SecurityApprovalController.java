package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.SecurityApproval;
import com.renaultdigital.client.employee.service.ISecurityApprovalService;

@CrossOrigin
@RestController
@RequestMapping(path = "/rd/ert/rest/v1/securityapprovals/")
public class SecurityApprovalController {

	@Autowired
	ISecurityApprovalService approvalService;

	@RequestMapping(method = RequestMethod.GET)
	public List<SecurityApproval> getAllPayrollApprovals() {
		return approvalService.getAllSecurityApprovals();
	}

	@RequestMapping(method = RequestMethod.POST)
	public List<SecurityApproval> addPayrollApprovals(@RequestBody List<SecurityApproval> approvals) {
		return approvalService.addOrUpdate(approvals);
	}

	@RequestMapping(path = "{rnNum}", method = RequestMethod.GET)
	public SecurityApproval getById(@PathVariable String rnNum) {
		return approvalService.findByRnNumber(rnNum);
	}

}
