package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.SecurityApproval;
import com.renaultdigital.client.employee.repository.ISecurityApprovalRepo;

@Service
public class SecurtiyApprovalService implements ISecurityApprovalService {

	@Autowired
	ISecurityApprovalRepo approvalRepo;

	@Override
	public List<SecurityApproval> getAllSecurityApprovals() {
		return approvalRepo.findAll();
	}

	@Override
	public List<SecurityApproval> addOrUpdate(List<SecurityApproval> securityApprovals) {
		return approvalRepo.save(securityApprovals);
	}

	@Override
	public SecurityApproval findByRnNumber(String rnNum) {
		return approvalRepo.findByRnNumRnNum(rnNum);
	}

}
