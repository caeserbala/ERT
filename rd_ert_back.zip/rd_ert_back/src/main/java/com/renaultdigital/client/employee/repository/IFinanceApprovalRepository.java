package com.renaultdigital.client.employee.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.FinanceApproval;

@Repository
public interface IFinanceApprovalRepository extends CrudRepository<FinanceApproval, Integer> {

	List<FinanceApproval> findAll();

	FinanceApproval findByRnNumRnNum(String employeeInfo);
	
}
