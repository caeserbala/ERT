package com.renaultdigital.client.employee.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.Status;

@Repository
public interface IStatusRepository extends CrudRepository<Status, Integer> {

}
