package com.renaultdigital.client.employee.model;

public class DataCount {

	private String data;
	private int count;
	private int total;
	private String additionalData;

	public DataCount(String data, long count) {
		super();
		this.data = data;
		this.count = (int) count;
	}

	public DataCount(String data, long count, long total) {
		super();
		this.data = data;
		this.count = (int) count;
		this.setTotal((int) total);
	}

	public DataCount(String additionalData, String data, long count) {
		super();
		this.data = data;
		this.count = (int) count;
		this.additionalData = additionalData;
	}

	public String getData() {
		return data;
	}

	public int getCount() {
		return count;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "DataCount [data=" + data + ", count=" + count + ", total=" + total + "]";
	}

	public String getAdditionalData() {
		return additionalData;
	}

}
