package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.Reason;
import com.renaultdigital.client.employee.repository.IReasonRepository;

@Service
public class ReasonService implements IReasonService {

	@Autowired
	IReasonRepository reasonRepository;

	@Override
	public List<Reason> getAllReasons() {
		return reasonRepository.findAll();
	}

	@Override
	public List<Reason> addOrUpdate(List<Reason> reason) {
		return (List<Reason>) reasonRepository.save((Iterable<Reason>) reason);
	}

	@Override
	public Reason getById(String id) {
		return reasonRepository.findOne(Integer.valueOf(id));
	}

	@Override
	public void deleteReason(Integer id) {
		reasonRepository.delete(id);
	}

}
