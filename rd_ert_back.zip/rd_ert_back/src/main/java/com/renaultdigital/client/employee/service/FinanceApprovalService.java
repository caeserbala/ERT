package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.FinanceApproval;
import com.renaultdigital.client.employee.repository.IFinanceApprovalRepository;

@Service
public class FinanceApprovalService implements IFinanceApprovalService {

	@Autowired
	IFinanceApprovalRepository financeApprovalRepository;
	
	@Override
	public List<FinanceApproval> getAllFinanceApprovals() {
		return financeApprovalRepository.findAll();
	}

	@Override
	public List<FinanceApproval> addOrUpdate(List<FinanceApproval> financeApprovals) {
		return (List<FinanceApproval>) financeApprovalRepository.save((Iterable<FinanceApproval>)financeApprovals);
	}

	@Override
	public FinanceApproval getByRnNum(String rnNum) {
		return financeApprovalRepository.findByRnNumRnNum(rnNum);
	}

}
