package com.renaultdigital.client.employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.SecurityApproval;

@Repository
public interface ISecurityApprovalRepo extends JpaRepository<SecurityApproval, Integer> {

	SecurityApproval findByRnNumRnNum(String rnNum);
}
