package com.renaultdigital.client.employee.util;

public class Constants {
	
	private Constants() {
	}
	
	public static final String RN_NUM_INTIAL = "R";
	public static final String Z_ID_INTIAL = "Z";
	public static final String DATEFORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	public static final String INACTIVE = "InActive";
	public static final String NOTICEPERIOD = "Notice Period";
	public static final String GENDER_KEY = "gender";
	public static final String PERCENTAGE_KEY = "percent";
	public static final String DEPARTMENT_KEY = "department";
	public static final String COUNT_KEY = "count";
	public static final String DESIGNATION_KEY = "designation";
	public static final String DEPARTMENT_DESIGNATION_KEY = "departmentWithDesignation";
	public static final String REPORT_KEY = "report";
	public static final String RNNAME_KEY = "RNNAME";
	public static final String RNNUMBER_KEY = "RNNUMBER";
	public static final String MESSAGE = "message";
	public static final String FAILURE_MESSAGE = "Failure";
	public static final String SUCCESS_MESSAGE = "Success";
	public static final String DESCRIPTION = "description";
	public static final String EMPTY_DESCRIPTION = "No Records Found";
	public static final String LENGTH_DESCRIPTION = "Search String Should be More than 2 Characters";
	public static final String EMPLOYEELIST = "employeeList";
	public static final String ACTIVE ="Active";
	public static final String MAIL_SUBJECT_DATA = "Approval Remainder for RNNAME (RNNUMBER)";
	public static final String NOTIFICATION_SUBJECT_DATA = "Resignation Revert Notification for RNNAME (RNNUMBER)";
	public static final String NOTIFICATION_BODY_DATA = "Dear, \t Notification Mail : \n\t\t Notification about Resignation Revert for  RNNAME (RNNUMBER)  Resignation Process!! "
														+ "\nThanks, \nSeperation-Team";
	public static final String MAIL_BODY_DATA = "Dear, \t Remainder Mail : \n\t\t Please review  RNNAME (RNNUMBER)  Resignation Process and Approve.!! "
												+ "\nThanks, \nSeperation-Team";
	public static final String MAILREQUESTCLARIFICATION_SUBJECT_DATA = " Request for Clarification on Resignation from RNNAME (RNNUMBER)";
	public static final String MAILREQUESTCLARIFICATION_BODY_DATA = "Dear, \n\t Remainder Mail : \n\t\t Clarification Provided from RNNAME (RNNUMBER)";
	public static final String MAILREVERTREQUEST_SUBJECT_DATA = " Request for REVERT on Resignation from RNNAME (RNNUMBER)";
	public static final String MAILREVERTREQUEST_BODY_DATA = "Dear, \n\t Remainder Mail : \n\t\t Please review  RNNAME (RNNUMBER)  Resignation REVERT Process and Approve.!! "
												+ "\nThanks, \nSeperation-Team";
	
	
	public static final String APPROVAL_STATUS_QUERY="select fa.status as fa, hr.status as hra, ia.status as iaa, "
			+ "ma.status as ma, ma.fn_mgr_status as fma, hr.hr_mgr_status as hrma, pa.status as paa, "
			+ "ra.status as raa, sa.status as saa, ta.status as taa, tra.status as traa, "
			+ "fa.approved_date as fd, hr.approved_date as hrd, ia.approved_date as iad, ma.approved_date as md, "
			+ "ma.fm_approved_date as fmd, hr.hr_mgr_approved_date as hrmd, pa.approved_date as pd, ra.approved_date as rd, "
			+ "sa.approved_date as sd, ta.approved_date as td, tra.approved_date as trad, ma.comments as mac, "
			+ "ma.fn_mgr_comments as fnc,hr.comments as hrc,hr.hr_mgr_comments as hrmc, adm.status as adm, adm.approved_date"
			+ ",adm.comments as adc,fa.comments as fac,ia.comments as iac,pa.comments as pac,ra.comments as rac,sa.comments as sac,"
			+ "ta.comments as tac,tra.comments as trac from esp_resignation r "
			+ "left join esp_hr_approval hr on hr.r_id = r.r_id left join esp_finance_approval fa on fa.r_id = r.r_id "
			+ "left join esp_manager_approval ma on ma.r_id = r.r_id left join esp_it_approval ia on ia.r_id = r.r_id "
			+ "left join esp_payroll_approval pa on pa.r_id = r.r_id left join esp_recruitment_approval ra on ra.r_id = r.r_id "
			+ "left join esp_security_approval sa on sa.r_id = r.r_id left join esp_training_approval ta on ta.r_id = r.r_id "
			+ "left join esp_admin_approval adm on adm.r_id = r.r_id "
			+ "left join esp_travel_approval tra on tra.r_id = r.r_id where r.rn_num = '*'";
	
	public static final String DELETE_RESIGNATION_QUERY = "delete from esp_resignation r where r.r_id = '*'";
	
	public static final CharSequence ASTERIK = "*";
	public static final String SPACE = " ";
	public static final String EMPTY = "";
	
	public static final String EMPLOYEE = "EMPLOYEE";
	public static final String L1MANAGER = "L1MANAGER";
	public static final String MANAGER = "MANAGER";
	public static final String HRBP = "HRBP";
	public static final String HRRM = "HRRM";
	
	
	public static final int NOTICEPERIOD_DAYS = 90;
	
	public static final String APPROVED = "Approved";
	public static final String PENDING = "Waiting for approval";
	public static final String REJECTED = "Rejected";
	public static final String REASON_KEY = "reason";
	public static final String RESIGNATIONS_KEY = "resignations";
	public static final String MONTH_KEY = "month"; 
	public static final String REVERT_CODE = "9";
	public static final String REVERT_PENDING = "Revert Pending";
	public static final String REVERT_APPROVED = "Revert Approved";
	public static final String REVERT_REJECTED = "Revert Rejected";
	
	
	public static final class StatusCode{
		
		private StatusCode(){
		}
		
		public static final int TO_MANAGER = 0;
		public static final int TO_FN_MANAGER = 1;
		public static final int TO_HR_BP = 2;
		public static final int TO_HR_RM = 3;
		public static final int MANAGER_REJECTED = 4;
		public static final int FN_MANAGER_REJECTED = 5;
		public static final int HR_BP_REJECT = 6;
		public static final int HR_RM_REJECT = 7;
		public static final int HR_RM_APPROVED = 8;
		public static final int REVERT_REQUEST = 9;
		public static final int REVERT_MANAGER_APPROVED = 10;
		public static final int REVERT_FUNC_APPROVED = 11;
		public static final int REVERT_HRBP_APPROVED = 12;
		public static final int REVERTED = 13;
		public static final int HR_BP_APPROVED = 14;
		public static final int HR_BP_REVERT_REJECT = 15;
		public static final int HR_RM_REVERT_REJECT = 16;

	
	}
	
	
			
}
