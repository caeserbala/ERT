package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.TrainingApproval;
import com.renaultdigital.client.employee.service.ITrainingApprovalService;

@CrossOrigin
@RestController
@RequestMapping(path="/rd/ert/rest/v1/trainingapprovals/")
public class TrainingApprovalController {
	
	@Autowired
	ITrainingApprovalService trainingApprovalService;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<TrainingApproval> getAllTrainingApprovals(){
		return trainingApprovalService.getAllTrainingApprovals();
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public List<TrainingApproval> addTrainingAprrovals(@RequestBody List<TrainingApproval> payrollApprovals){
		return trainingApprovalService.addOrUpdate(payrollApprovals);
	}
	
	
	@RequestMapping(path="{rnNum}", method=RequestMethod.GET)
	public TrainingApproval getById(@PathVariable String rnNum){
		return trainingApprovalService.findByRnNumber(rnNum);
	}
	
}
