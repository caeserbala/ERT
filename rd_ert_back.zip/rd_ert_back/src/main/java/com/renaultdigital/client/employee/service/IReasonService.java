package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.Reason;

public interface IReasonService {

	public List<Reason> getAllReasons();

	public List<Reason> addOrUpdate(List<Reason> reason);

	public Reason getById(String id);

	public void deleteReason(Integer id);

}
