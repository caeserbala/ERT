package com.renaultdigital.client.employee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "esp_employee_info")
public class EmployeeInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Basic(optional = false)
	@Column(name = "rn_num")
	private String rnNum;
	@Basic(optional = false)
	@Column(name = "first_name")
	private String firstName;
	@Basic(optional = false)
	@Column(name = "last_name")
	private String lastName;
	@Basic(optional = false)
	@Column(name = "gender")
	private String gender;
	@Basic(optional = false)
	@Column(name = "doj")
	@Temporal(TemporalType.DATE)
	private Date doj;
	@Basic(optional = false)
	@Column(name = "designation")
	private String designation;
	@Basic(optional = false)
	@Column(name = "grade")
	private String grade;
	@Basic(optional = false)
	@Column(name = "ipn")
	private String ipn;
	@Column(name = "email")
	private String email;
	@Column(name = "reporting_mgr_no")
	private String reportingMgrNo;
	@Column(name = "reporting_mgr_name")
	private String reportingMgrName;
	@Column(name = "employment_status")
	private String employmentStatus;
	@Column(name = "status")
	private String status;
	@Column(name = "confirmation_date")
	@Temporal(TemporalType.DATE)
	private Date confirmationDate;
	@Column(name = "resignation_date")
	@Temporal(TemporalType.DATE)
	private Date resignationDate;
	@Column(name = "exit_date")
	@Temporal(TemporalType.DATE)
	private Date exitDate;
	@JoinColumn(name = "sub_depart_name", referencedColumnName = "sub_depart_name")
	@ManyToOne(optional = false)
	private SubDepartment subDepartName;

	public EmployeeInfo() {
	}

	public EmployeeInfo(String rnNum) {
		this.rnNum = rnNum;
	}

	public String getRnNum() {
		return rnNum;
	}

	public void setRnNum(String rnNum) {
		this.rnNum = rnNum;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getIpn() {
		return ipn;
	}

	public void setIpn(String ipn) {
		this.ipn = ipn;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getReportingMgrNo() {
		return reportingMgrNo;
	}

	public void setReportingMgrNo(String reportingMgrNo) {
		this.reportingMgrNo = reportingMgrNo;
	}

	public String getReportingMgrName() {
		return reportingMgrName;
	}

	public void setReportingMgrName(String reportingMgrName) {
		this.reportingMgrName = reportingMgrName;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getConfirmationDate() {
		return confirmationDate;
	}

	public void setConfirmationDate(Date confirmationDate) {
		this.confirmationDate = confirmationDate;
	}

	public Date getResignationDate() {
		return resignationDate;
	}

	public void setResignationDate(Date resignationDate) {
		this.resignationDate = resignationDate;
	}

	public Date getExitDate() {
		return exitDate;
	}

	public void setExitDate(Date exitDate) {
		this.exitDate = exitDate;
	}

	public SubDepartment getSubDepartName() {
		return subDepartName;
	}

	public void setSubDepartName(SubDepartment subDepartName) {
		this.subDepartName = subDepartName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rnNum == null) ? 0 : rnNum.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeInfo other = (EmployeeInfo) obj;
		if (rnNum == null) {
			if (other.rnNum != null)
				return false;
		} else if (!rnNum.equals(other.rnNum))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "EmployeeInfo[ rnNum=" + rnNum + " ]";
	}

	public static EmployeeInfo getInstanceFromRnNumber(String rnNum) {
		return new EmployeeInfo(rnNum);
	}

}
