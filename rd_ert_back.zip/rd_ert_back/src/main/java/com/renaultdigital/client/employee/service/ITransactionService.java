package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.TransactionLog;

public interface ITransactionService {

	List<TransactionLog> getAllTransactionLogs();

	List<TransactionLog> addOrUpdate(List<TransactionLog> transactionLogs);

	List<TransactionLog> findByEmpRn(String empRn);

	List<TransactionLog> findByMgrRn(String mgrRn);

	List<TransactionLog> findByMgrRnAndEmpRn(String mgrRn, String empRn);

}
