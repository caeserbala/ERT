package com.renaultdigital.client.employee.util;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import 	org.springframework.transaction.annotation.Transactional;

/**
 * @author z022191
 *
 */
public class DBUtils {
	
	private DBUtils(){
	}
	

	/**
	 * @param em
	 * @param query
	 * @return Object[]
	 */
	public static Object[] executeNativeQueryForApprovalStatus(EntityManager em, String query){
		List<Object[]> resultSetArray = executeNativeQuery(em, query);
		return resultSetArray == null? null : resultSetArray.get(0);
	}
	
	/**
	 * @param em
	 * @param query
	 * @return List<Object[]>
	 */
	public static List<Object[]> executeNativeQuery(EntityManager em, String query){
		Query q = em.createNativeQuery(query);
		return q.getResultList();
	}
	
	@Transactional
	public static int executeUpdateQuery(EntityManager em, String query){
		Query q = em.createNativeQuery(query);
		int result = q.executeUpdate();
		return result;
	}	
	

}
