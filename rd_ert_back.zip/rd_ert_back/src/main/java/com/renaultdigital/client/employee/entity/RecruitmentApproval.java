package com.renaultdigital.client.employee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "esp_recruitment_approval")
public class RecruitmentApproval implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "ra_id")
	private Integer raId;
	@Column(name = "prev_company_buyout")
	private Integer prevCompanyBuyout;
	@Column(name = "ohter_payment")
	private Integer otherPayment;
	@Column(name = "relocation_expense")
	private Integer relocationExpense;
	@JoinColumn(name = "domain_id", referencedColumnName = "domain_id")
	@ManyToOne
	private Domains domainId;
	@Column(name = "status")
	private String status;
	@JoinColumn(name = "rn_num", referencedColumnName = "rn_num")
	@ManyToOne
	private EmployeeInfo rnNum;

	@JoinColumn(name = "r_id", referencedColumnName = "r_id")
	@ManyToOne
	private EmployeeResignation resignationId;

	@Column(name = "approved_date")
	@Temporal(TemporalType.DATE)
	private Date approvedDate;

	@Column(name = "comments")
	private String comments;

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public EmployeeResignation getResignationId() {
		return resignationId;
	}

	public void setResignationId(EmployeeResignation resignationId) {
		this.resignationId = resignationId;
	}

	public RecruitmentApproval() {
	}

	public RecruitmentApproval(Integer raId) {
		this.raId = raId;
	}

	public Integer getRaId() {
		return raId;
	}

	public void setRaId(Integer raId) {
		this.raId = raId;
	}

	public Integer getPrevCompanyBuyout() {
		return prevCompanyBuyout;
	}

	public void setPrevCompanyBuyout(Integer prevCompanyBuyout) {
		this.prevCompanyBuyout = prevCompanyBuyout;
	}

	public Integer getOtherPayment() {
		return otherPayment;
	}

	public void setOtherPayment(Integer ohterPayment) {
		this.otherPayment = ohterPayment;
	}

	public Integer getRelocationExpense() {
		return relocationExpense;
	}

	public void setRelocationExpense(Integer relocationExpense) {
		this.relocationExpense = relocationExpense;
	}

	public Domains getDomainId() {
		return domainId;
	}

	public void setDomainId(Domains domainId) {
		this.domainId = domainId;
	}

	public EmployeeInfo getRnNum() {
		return rnNum;
	}

	public void setRnNum(EmployeeInfo rnNum) {
		this.rnNum = rnNum;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((raId == null) ? 0 : raId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RecruitmentApproval other = (RecruitmentApproval) obj;
		if (raId == null) {
			if (other.raId != null)
				return false;
		} else if (!raId.equals(other.raId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "com.renaultdigital.client.Employee.Entity.RecruitmentApproval[ raId=" + raId + " ]";
	}

}
