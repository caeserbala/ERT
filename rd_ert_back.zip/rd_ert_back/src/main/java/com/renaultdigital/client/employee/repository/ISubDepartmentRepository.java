package com.renaultdigital.client.employee.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.SubDepartment;

@Repository
public interface ISubDepartmentRepository extends CrudRepository<SubDepartment, String> {

	List<SubDepartment> findAll();

	SubDepartment findBySubDepartNameEqualsIgnoreCase(String subDeptName);

	List<SubDepartment> findByDeptNameDeptNameEqualsIgnoreCase(String deptName);

}
