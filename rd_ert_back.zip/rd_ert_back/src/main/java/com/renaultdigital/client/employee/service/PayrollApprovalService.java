package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.PayrollApproval;
import com.renaultdigital.client.employee.repository.IPayrollApprovalRepository;

@Service
public class PayrollApprovalService implements IPayrollApprovalService {

	@Autowired 
	IPayrollApprovalRepository payrollApprovalRepository;
	
	@Override
	public List<PayrollApproval> getAllPayrollApprovals() {
		return payrollApprovalRepository.findAll();
	}

	@Override
	public List<PayrollApproval> addOrUpdate(List<PayrollApproval> payrollApprovals) {
		return (List<PayrollApproval>) payrollApprovalRepository.save((Iterable<PayrollApproval>) payrollApprovals);
	}

	@Override
	public PayrollApproval findByRnNumber(String rnNum) {
		return payrollApprovalRepository.findByRnNumRnNum(rnNum);
	}

}
