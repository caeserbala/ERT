package com.renaultdigital.client.employee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "esp_travel_approval")
public class TravelApproval implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "sa_id")
	private Integer trvId;
	@Column(name = "work_permit_visa_cancellation")
	private Boolean workPermitVisaCancellation;
	@Column(name = "status")
	private String status;
	@JoinColumn(name = "rn_num", referencedColumnName = "rn_num")
	@ManyToOne
	private EmployeeInfo rnNum;

	@JoinColumn(name = "r_id", referencedColumnName = "r_id")
	@ManyToOne
	private EmployeeResignation resignationId;

	@Column(name = "approved_date")
	@Temporal(TemporalType.DATE)
	private Date approvedDate;

	@Column(name = "comments")
	private String comments;

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public EmployeeResignation getResignationId() {
		return resignationId;
	}

	public void setResignationId(EmployeeResignation resignationId) {
		this.resignationId = resignationId;
	}

	public TravelApproval() {
	}

	public TravelApproval(Integer saId) {
		this.trvId = saId;
	}

	public Integer getTrvId() {
		return trvId;
	}

	public void setTrvId(Integer saId) {
		this.trvId = saId;
	}

	public Boolean getWorkPermitVisaCancellation() {
		return workPermitVisaCancellation;
	}

	public void setWorkPermitVisaCancellation(Boolean workPermitVisaCancellation) {
		this.workPermitVisaCancellation = workPermitVisaCancellation;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public EmployeeInfo getRnNum() {
		return rnNum;
	}

	public void setRnNum(EmployeeInfo rnNum) {
		this.rnNum = rnNum;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((trvId == null) ? 0 : trvId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TravelApproval other = (TravelApproval) obj;
		if (trvId == null) {
			if (other.trvId != null)
				return false;
		} else if (!trvId.equals(other.trvId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "com.renaultdigital.client.Employee.Entity.TravelApproval[ trvId=" + trvId + " ]";
	}

}
