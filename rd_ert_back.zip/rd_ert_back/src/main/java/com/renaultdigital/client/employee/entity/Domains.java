package com.renaultdigital.client.employee.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "esp_domains")
public class Domains implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "domain_id")
	private Integer domainId;
	@Basic(optional = false)
	@Column(name = "domain_name")
	private String domainName;
	@JoinColumn(name = "status_code", referencedColumnName = "status_code")
	@ManyToOne
	private Status statusCode;

	public Domains() {
	}

	public Domains(Integer domainId) {
		this.domainId = domainId;
	}

	public Domains(Integer domainId, String domainName) {
		this.domainId = domainId;
		this.domainName = domainName;
	}

	public Integer getDomainId() {
		return domainId;
	}

	public void setDomainId(Integer domainId) {
		this.domainId = domainId;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public Status getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Status statusCode) {
		this.statusCode = statusCode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((domainId == null) ? 0 : domainId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Domains other = (Domains) obj;
		if (domainId == null) {
			if (other.domainId != null)
				return false;
		} else if (!domainId.equals(other.domainId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "com.mycompany.mavenproject1.Domains[ domainId=" + domainId + " ]";
	}

}
