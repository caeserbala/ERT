package com.renaultdigital.client.employee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "esp_payroll_approval")
public class PayrollApproval implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "pra_id")
	private Integer praId;
	@Column(name = "staff_advance")
	private Boolean staffAdvance;
	@Column(name = "medical")
	private Boolean medical;
	@Column(name = "ltc")
	private Boolean ltc;
	@Column(name = "fbp_claims")
	private Boolean fbpClaims;
	@Column(name = "recovery_notice_buyout")
	private Boolean recoveryNoticeBuyout;
	@Column(name = "address")
	private String address;
	@Column(name = "tele_number")
	private Integer teleNumber;
	@Column(name = "personal_email")
	private String personalEmail;
	@Column(name = "status")
	private String status;
	@JoinColumn(name = "rn_num", referencedColumnName = "rn_num")
	@ManyToOne
	private EmployeeInfo rnNum;

	@JoinColumn(name = "r_id", referencedColumnName = "r_id")
	@ManyToOne
	private EmployeeResignation resignationId;
	@Column(name = "approved_date")
	@Temporal(TemporalType.DATE)
	private Date approvedDate;

	@Column(name = "comments")
	private String comments;

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public EmployeeResignation getResignationId() {
		return resignationId;
	}

	public void setResignationId(EmployeeResignation resignationId) {
		this.resignationId = resignationId;
	}

	public PayrollApproval() {
	}

	public PayrollApproval(Integer praId) {
		this.praId = praId;
	}

	public Integer getPraId() {
		return praId;
	}

	public void setPraId(Integer praId) {
		this.praId = praId;
	}

	public Boolean getStaffAdvance() {
		return staffAdvance;
	}

	public void setStaffAdvance(Boolean staffAdvance) {
		this.staffAdvance = staffAdvance;
	}

	public Boolean getMedical() {
		return medical;
	}

	public void setMedical(Boolean medical) {
		this.medical = medical;
	}

	public Boolean getLtc() {
		return ltc;
	}

	public void setLtc(Boolean ltc) {
		this.ltc = ltc;
	}

	public Boolean getFbpClaims() {
		return fbpClaims;
	}

	public void setFbpClaims(Boolean fbpClaims) {
		this.fbpClaims = fbpClaims;
	}

	public Boolean getRecoveryNoticeBuyout() {
		return recoveryNoticeBuyout;
	}

	public void setRecoveryNoticeBuyout(Boolean recoveryNoticeBuyout) {
		this.recoveryNoticeBuyout = recoveryNoticeBuyout;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getTeleNumber() {
		return teleNumber;
	}

	public void setTeleNumber(Integer teleNumber) {
		this.teleNumber = teleNumber;
	}

	public String getPersonalEmail() {
		return personalEmail;
	}

	public void setPersonalEmail(String personalEmail) {
		this.personalEmail = personalEmail;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public EmployeeInfo getRnNum() {
		return rnNum;
	}

	public void setRnNum(EmployeeInfo rnNum) {
		this.rnNum = rnNum;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((praId == null) ? 0 : praId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PayrollApproval other = (PayrollApproval) obj;
		if (praId == null) {
			if (other.praId != null)
				return false;
		} else if (!praId.equals(other.praId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "com.renaultdigital.client.Employee.Entity.PayrollApproval[ praId=" + praId + " ]";
	}

}
