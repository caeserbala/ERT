package com.renaultdigital.client.employee.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.ItApproval;

@Repository
public interface IItApprovalRepository extends CrudRepository<ItApproval, Integer> {
	
	List<ItApproval> findAll();
	
	ItApproval findByRnNumRnNum(String rnNum);
	
}
