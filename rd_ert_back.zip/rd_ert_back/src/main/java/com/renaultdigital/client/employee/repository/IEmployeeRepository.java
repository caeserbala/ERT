package com.renaultdigital.client.employee.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.model.DataCount;

@Repository
public interface IEmployeeRepository extends CrudRepository<EmployeeInfo, String> {

	List<EmployeeInfo> findAll();

	List<EmployeeInfo> findAll(Pageable pageable);

	EmployeeInfo findByIpnEqualsIgnoreCaseOrRnNumEqualsIgnoreCase(String ipn, String rnNum);

	List<EmployeeInfo> findByFirstNameContainsIgnoreCaseOrLastNameContainsIgnoreCase(String firstName, String lastName);

	List<EmployeeInfo> findByFirstNameStartsWithIgnoreCaseOrLastNameStartsWithIgnoreCase(String firstName,
			String lastName);

	EmployeeInfo findByIpnEqualsIgnoreCase(@Param("ipn") String ipn);

	EmployeeInfo findByEmailEqualsIgnoreCase(@Param("email") String email);

	@Query("SELECT new com.renaultdigital.client.employee.model.DataCount(e.gender, COUNT(e), (SELECT COUNT(*) FROM EmployeeInfo esub WHERE esub.status = :status) ) FROM EmployeeInfo e  WHERE e.status = :status GROUP BY e.gender")
	List<DataCount> findExitReportByGender(@Param("status") String status);

	@Query("SELECT new com.renaultdigital.client.employee.model.DataCount(e.designation, COUNT(e), (SELECT COUNT(*) FROM EmployeeInfo esub WHERE esub.status = :status) ) FROM EmployeeInfo e  WHERE e.status = :status GROUP BY e.designation")
	List<DataCount> findExitReportByDesignation(@Param("status") String status);

	@Query("SELECT new com.renaultdigital.client.employee.model.DataCount(ed.deptName.deptName, count(e)) FROM EmployeeInfo e, SubDepartment ed WHERE e.exitDate BETWEEN :startDate AND :endDate AND e.status= :status	AND e.subDepartName=ed.subDepartName GROUP	BY ed.deptName")
	List<DataCount> findExitReportByDepartmentWithDate(@Param("startDate") Date startDate,
			@Param("endDate") Date endDate, @Param("status") String status);

	@Query("SELECT new com.renaultdigital.client.employee.model.DataCount(d.deptName.deptName, COUNT(e)) FROM EmployeeInfo e, SubDepartment d  WHERE e.status = :status AND e.subDepartName = d.subDepartName GROUP BY d.deptName")
	List<DataCount> findExitReportByDepartment(@Param("status") String status);

	@Query("SELECT new com.renaultdigital.client.employee.model.DataCount(d.deptName.deptName, e.designation, count(e)) FROM EmployeeInfo e, SubDepartment d WHERE e.status = :status AND e.subDepartName = d.subDepartName GROUP BY d.deptName, e.designation")
	List<DataCount> findExitReportByDepartmentWithDesignation(@Param("status") String status);

	@Query("SELECT new com.renaultdigital.client.employee.model.DataCount(r.reason,COUNT(e)) FROM EmployeeResignation r, EmployeeInfo e where e.status = :status and e.rnNum = r.rnNum GROUP BY r.reason")
	List<DataCount> findExitReportByReason(@Param("status") String status);

	@Query("SELECT new com.renaultdigital.client.employee.model.DataCount(CAST(EXTRACT(YEAR FROM EXIT_DATE) as text),COUNT(*)) FROM EmployeeInfo e WHERE e.status=:status AND EXTRACT(YEAR FROM EXIT_DATE) IS NOT NULL GROUP BY 1")
	List<DataCount> findExitReportByYear(@Param("status") String status);

	@Query("SELECT new com.renaultdigital.client.employee.model.DataCount(to_char(emp.exitDate,'Mon'),CAST(dept.deptName as text),COUNT(emp))"
			+ "  FROM Department dept,SubDepartment sdept,EmployeeInfo emp WHERE sdept.deptName = dept.deptName"
			+ "  AND emp.subDepartName = sdept.subDepartName AND emp.status = :status and dept.deptName=:dept "
			+ "and emp.exitDate between :start_date and :end_date group by to_char(emp.exitDate,'Mon'),"
			+ "dept.deptName")
	List<DataCount> findExitReportByYearandDept(@Param("status") String status, @Param("dept") String dept,
			@Param("start_date") Date startDate, @Param("end_date") Date endDate);

	@Query("SELECT new com.renaultdigital.client.employee.model.DataCount(to_char(emp.exitDate,'Mon')"
			+ ",CAST(dept.deptName as text),COUNT(emp)) FROM Department dept,SubDepartment sdept,"
			+ "EmployeeInfo emp WHERE " + "sdept.deptName = dept.deptName  AND emp.subDepartName = sdept.subDepartName "
			+ "AND emp.status = :status and emp.exitDate between :start_date and :end_date"
			+ " group by dept.deptName,to_char(emp.exitDate,'Mon')")
	List<DataCount> findExitReportByYearandDept(@Param("status") String status, @Param("start_date") Date startDate,
			@Param("end_date") Date endDate);

	@Query("SELECT DISTINCT EXTRACT(YEAR FROM emp.exitDate) AS YEAR FROM EmployeeInfo emp "
			+ "WHERE emp.exitDate IS NOT NULL  AND emp.status =:status")
	List<Integer> findDistinctYears(@Param("status") String status);

	void save(EmployeeResignation employeeResignation);

}
