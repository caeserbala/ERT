package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.AdminApproval;
import com.renaultdigital.client.employee.repository.IAdminRepository;

@Service
public class AdminApprovalService implements IAdminApprovalService {
	
	@Autowired
	IAdminRepository adminApprovalRepository;
	

	@Override
	public List<AdminApproval> getAllAdminApprovals() {
		return adminApprovalRepository.findAll();
	}

	@Override
	public List<AdminApproval> addOrUpdate(List<AdminApproval> adminApprovals) {
		return (List<AdminApproval>) adminApprovalRepository.save(adminApprovals);
	}

	@Override
	public AdminApproval findByRnNumber(String rnNum) {
		return adminApprovalRepository.findByRnNumRnNum(rnNum);
	}

}
