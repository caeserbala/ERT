package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.TravelApproval;
import com.renaultdigital.client.employee.repository.ITravelApprovalRepository;

@Service
public class TravelApprovalService implements ITravelApprovalService {

	@Autowired
	ITravelApprovalRepository travelApprovalRepository;
	
	@Override
	public List<TravelApproval> getAllTrainingApprovals() {
		return travelApprovalRepository.findAll();
	}

	@Override
	public List<TravelApproval> addOrUpdate(List<TravelApproval> travelApprovals) {
		return (List<TravelApproval>) travelApprovalRepository.save((Iterable<TravelApproval>) travelApprovals);
	}

	@Override
	public TravelApproval findByRnNumber(String rnNum) {
		return travelApprovalRepository.findByRnNumRnNum(rnNum);
	}

}
