package com.renaultdigital.client.employee.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.TransactionLog;

@Repository
public interface ITransactionRepository extends JpaRepository<TransactionLog, Integer> {

	List<TransactionLog> findByEmpRnNoEqualsIgnoreCase(String empRn);

	List<TransactionLog> findByMgrNoEqualsIgnoreCase(String mgrRn);

	List<TransactionLog> findByMgrNoEqualsIgnoreCaseAndEmpRnNoEqualsIgnoreCase(String mgrRn, String empRn);

}
