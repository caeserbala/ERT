package com.renaultdigital.client.employee.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.PayrollApproval;

@Repository
public interface IPayrollApprovalRepository extends CrudRepository<PayrollApproval, Integer> {
		
	List<PayrollApproval> findAll();

	PayrollApproval findByRnNumRnNum(String rnNum);
	
}
