package com.renaultdigital.client.employee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "esp_admin_approval")
public class AdminApproval implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "ada_id")
	private Integer adaId;
	@Column(name = "bus_pass_submitted")
	private Boolean busPassSubmitted;
	@Column(name = "wks_key_submitted")
	private Boolean wksKeySubmitted;
	@Column(name = "status")
	private String status;
	@JoinColumn(name = "rn_num", referencedColumnName = "rn_num")
	@OneToOne
	private EmployeeInfo rnNum;
	@JoinColumn(name = "r_id", referencedColumnName = "r_id")
	@ManyToOne
	private EmployeeResignation resignationId;

	@Column(name = "approved_date")
	@Temporal(TemporalType.DATE)
	private Date approvedDate;

	@Column(name = "comments")
	private String comments;

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public EmployeeResignation getResignationId() {
		return resignationId;
	}

	public void setResignationId(EmployeeResignation resignationId) {
		this.resignationId = resignationId;
	}

	public AdminApproval() {
	}

	public AdminApproval(Integer adaId) {
		this.adaId = adaId;
	}

	public Integer getAdaId() {
		return adaId;
	}

	public void setAdaId(Integer adaId) {
		this.adaId = adaId;
	}

	public Boolean getBusPassSubmitted() {
		return busPassSubmitted;
	}

	public void setBusPassSubmitted(Boolean busPassSubmitted) {
		this.busPassSubmitted = busPassSubmitted;
	}

	public Boolean getWksKeySubmitted() {
		return wksKeySubmitted;
	}

	public void setWksKeySubmitted(Boolean wksKeySubmitted) {
		this.wksKeySubmitted = wksKeySubmitted;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public EmployeeInfo getRnNum() {
		return rnNum;
	}

	public void setRnNum(EmployeeInfo rnNum) {
		this.rnNum = rnNum;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adaId == null) ? 0 : adaId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AdminApproval other = (AdminApproval) obj;
		if (adaId == null) {
			if (other.adaId != null)
				return false;
		} else if (!adaId.equals(other.adaId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "com.mycompany.mavenproject1.EspAdminApproval[ adaId=" + adaId + " ]";
	}

}
