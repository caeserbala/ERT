package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.model.ApprovalStatus;
import com.renaultdigital.client.employee.service.IEmployeeResignationService;

@CrossOrigin
@RestController
@RequestMapping(path = "/rd/ert/rest/v1/employeeresignations/")
public class EmployeeResignationController {

	@Autowired
	IEmployeeResignationService employeeResignationService;

	@RequestMapping(method = RequestMethod.GET)
	public List<EmployeeResignation> getAllResignations() {
		return employeeResignationService.getAllEmployeeResignations();
	}

	@RequestMapping(method = RequestMethod.POST)
	public List<EmployeeResignation> addResignations(@RequestBody List<EmployeeResignation> employeeResignations) {
		return employeeResignationService.addOrUpdate(employeeResignations);
	}

	@RequestMapping(path = "manager/{rnNumber}", method = RequestMethod.GET)
	public List<EmployeeResignation> getResignationsForManager(@PathVariable String rnNumber) {
		return employeeResignationService.getResignationsByManager(rnNumber);
	}

	@RequestMapping(path = "fnmanager/{rnNumber}", method = RequestMethod.GET)
	public List<EmployeeResignation> getResignationsForFnManager(@PathVariable String rnNumber) {
		return employeeResignationService.getResignationsByFnManager(rnNumber);
	}
	
	@RequestMapping(path = "manager/{rnNumber}/avail", method = RequestMethod.GET)
	public Boolean getResignationAvailableForManager(@PathVariable String rnNumber) {
		return employeeResignationService.getResignationAvailableForManager(rnNumber);
	}

	@RequestMapping(path = "{rnNumber}", method = RequestMethod.GET)
	public EmployeeResignation getByRnNumber(@PathVariable String rnNumber) {
		return employeeResignationService.getByRnNumber(rnNumber);
	}

	@RequestMapping(path = "status/{rnNumber}", method = RequestMethod.GET)
	public ApprovalStatus getStatusByRnNumber(@PathVariable String rnNumber) {
		return employeeResignationService.getApprovalStatusByRnNumber(rnNumber);
	}
	
	@RequestMapping(path = "hrbp/{rnNumber}", method = RequestMethod.GET)
	public List<EmployeeResignation> getResignationsForHrBp(@PathVariable String rnNumber) {
		return employeeResignationService.getResignationsByHrBP(rnNumber);
	}
	
	@RequestMapping(path = "hrrm/{rnNumber}", method = RequestMethod.GET)
	public List<EmployeeResignation> getResignationsForHrRM(@PathVariable String rnNumber) {
		return employeeResignationService.getResignationsByHrRM(rnNumber);
	}
	
}
