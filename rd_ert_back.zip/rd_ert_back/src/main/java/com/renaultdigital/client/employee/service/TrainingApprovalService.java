package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.TrainingApproval;
import com.renaultdigital.client.employee.repository.ITrainingApprovalRepository;

@Service
public class TrainingApprovalService implements ITrainingApprovalService {

	
	@Autowired
	ITrainingApprovalRepository trainingApprovalRepository;
	
	@Override
	public List<TrainingApproval> getAllTrainingApprovals() {
		return trainingApprovalRepository.findAll();
	}

	@Override
	public List<TrainingApproval> addOrUpdate(List<TrainingApproval> trainingApprovals) {
		return (List<TrainingApproval>) trainingApprovalRepository.save((Iterable<TrainingApproval>) trainingApprovals);
	}

	@Override
	public TrainingApproval findByRnNumber(String rnNum) {
		return trainingApprovalRepository.findByRnNumRnNum(rnNum);
	}

}
