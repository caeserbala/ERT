package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.TransactionLog;
import com.renaultdigital.client.employee.repository.ITransactionRepository;

@Service
public class TransactionService implements ITransactionService {

	@Autowired
	ITransactionRepository transactionRepository;

	@Override
	public List<TransactionLog> getAllTransactionLogs() {
		return transactionRepository.findAll();
	}

	@Override
	public List<TransactionLog> addOrUpdate(List<TransactionLog> transactionLogs) {
		return transactionRepository.save(transactionLogs);
	}

	@Override
	public List<TransactionLog> findByEmpRn(String empRn) {
		return transactionRepository.findByEmpRnNoEqualsIgnoreCase(empRn);
	}

	@Override
	public List<TransactionLog> findByMgrRn(String mgrRn) {
		return transactionRepository.findByMgrNoEqualsIgnoreCase(mgrRn);
	}

	@Override
	public List<TransactionLog> findByMgrRnAndEmpRn(String mgrRn, String empRn) {
		return transactionRepository.findByMgrNoEqualsIgnoreCaseAndEmpRnNoEqualsIgnoreCase(mgrRn, empRn);
	}

}
