package com.renaultdigital.client.employee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "esp_it_approval")
public class ItApproval implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "ia_id")
	private Integer iaId;
	@Column(name = "domain_login")
	private String domainLogin;
	@Column(name = "wks_location")
	private String wksLocation;
	@Column(name = "drives_submitted")
	private Boolean drivesSubmitted;
	@Column(name = "disk_clearance")
	private Boolean diskClearance;
	@Column(name = "lan_id_disabled")
	private Boolean lanIdDisabled;
	@Column(name = "laptop_returned")
	private Boolean laptopReturned;
	@Column(name = "data_card_returned")
	private Boolean dataCardReturned;
	@Column(name = "asserts_returned")
	private Boolean assertsReturned;
	@Column(name = "email_removed")
	private Boolean emailRemoved;
	@Column(name = "desktop_released")
	private Boolean desktopReleased;
	@Column(name = "status")
	private String status;
	@JoinColumn(name = "rn_num", referencedColumnName = "rn_num")
	@ManyToOne
	private EmployeeInfo rnNum;

	@JoinColumn(name = "r_id", referencedColumnName = "r_id")
	@ManyToOne
	private EmployeeResignation resignationId;
	@Column(name = "approved_date")
	@Temporal(TemporalType.DATE)
	private Date approvedDate;

	@Column(name = "comments")
	private String comments;

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public EmployeeResignation getResignationId() {
		return resignationId;
	}

	public void setResignationId(EmployeeResignation resignationId) {
		this.resignationId = resignationId;
	}

	public ItApproval() {
	}

	public ItApproval(Integer iaId) {
		this.iaId = iaId;
	}

	public Integer getIaId() {
		return iaId;
	}

	public void setIaId(Integer iaId) {
		this.iaId = iaId;
	}

	public String getDomainLogin() {
		return domainLogin;
	}

	public void setDomainLogin(String domainLogin) {
		this.domainLogin = domainLogin;
	}

	public String getWksLocation() {
		return wksLocation;
	}

	public void setWksLocation(String wksLocation) {
		this.wksLocation = wksLocation;
	}

	public Boolean getDrivesSubmitted() {
		return drivesSubmitted;
	}

	public void setDrivesSubmitted(Boolean drivesSubmitted) {
		this.drivesSubmitted = drivesSubmitted;
	}

	public Boolean getDiskClearance() {
		return diskClearance;
	}

	public void setDiskClearance(Boolean diskClearance) {
		this.diskClearance = diskClearance;
	}

	public Boolean getLanIdDisabled() {
		return lanIdDisabled;
	}

	public void setLanIdDisabled(Boolean lanIdDisabled) {
		this.lanIdDisabled = lanIdDisabled;
	}

	public Boolean getLaptopReturned() {
		return laptopReturned;
	}

	public void setLaptopReturned(Boolean laptopReturned) {
		this.laptopReturned = laptopReturned;
	}

	public Boolean getDataCardReturned() {
		return dataCardReturned;
	}

	public void setDataCardReturned(Boolean dataCardReturned) {
		this.dataCardReturned = dataCardReturned;
	}

	public Boolean getAssertsReturned() {
		return assertsReturned;
	}

	public void setAssertsReturned(Boolean assertsReturned) {
		this.assertsReturned = assertsReturned;
	}

	public Boolean getEmailRemoved() {
		return emailRemoved;
	}

	public void setEmailRemoved(Boolean emailRemoved) {
		this.emailRemoved = emailRemoved;
	}

	public Boolean getDesktopReleased() {
		return desktopReleased;
	}

	public void setDesktopReleased(Boolean desktopReleased) {
		this.desktopReleased = desktopReleased;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public EmployeeInfo getRnNum() {
		return rnNum;
	}

	public void setRnNum(EmployeeInfo rnNum) {
		this.rnNum = rnNum;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((iaId == null) ? 0 : iaId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItApproval other = (ItApproval) obj;
		if (iaId == null) {
			if (other.iaId != null)
				return false;
		} else if (!iaId.equals(other.iaId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "com.renaultdigital.client.Employee.Entity.ItApproval[ iaId=" + iaId + " ]";
	}

}
