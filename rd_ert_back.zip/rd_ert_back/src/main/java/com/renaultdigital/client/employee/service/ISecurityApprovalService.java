package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.SecurityApproval;

public interface ISecurityApprovalService {

	List<SecurityApproval> getAllSecurityApprovals();

	List<SecurityApproval> addOrUpdate(List<SecurityApproval> securityApprovals);

	SecurityApproval findByRnNumber(String rnNum);

}
