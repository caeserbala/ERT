package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.Reason;
import com.renaultdigital.client.employee.service.IReasonService;
import com.renaultdigital.client.employee.util.RenoConstants;

@CrossOrigin
@RestController
@RequestMapping(path = "/rd/ert/rest/v1/reasons/")
public class ReasonsController {

	@Autowired
	IReasonService reasonService;

	@RequestMapping(method = RequestMethod.GET)
	public List<Reason> getAllReasons() {
		return reasonService.getAllReasons();
	}

	@RequestMapping(method = RequestMethod.POST)
	public List<Reason> addReasons(@RequestBody List<Reason> reasons) {
		return reasonService.addOrUpdate(reasons);
	}

	@RequestMapping(path = "{id}", method = RequestMethod.GET)
	public Reason getById(@PathVariable String id) {
		return reasonService.getById(id);
	}

	@RequestMapping(path = "delete/{id}", method = RequestMethod.POST)
	public String deleteById(@PathVariable String id) {
		reasonService.deleteReason(Integer.parseInt(id));
		return RenoConstants.MAIL_SUCCESS;
	}

}
