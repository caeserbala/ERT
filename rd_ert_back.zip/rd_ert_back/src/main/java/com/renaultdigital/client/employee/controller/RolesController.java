package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.Roles;
import com.renaultdigital.client.employee.service.IRolesService;
import com.renaultdigital.client.employee.util.RenoConstants;

@CrossOrigin
@RestController
@RequestMapping(path = "/rd/ert/rest/v1/roles/")
public class RolesController {

	@Autowired
	IRolesService rolesService;

	@RequestMapping(method = RequestMethod.GET)
	public List<Roles> getAllDepartments() {
		return rolesService.getAllRoles();
	}

	@RequestMapping(method = RequestMethod.POST)
	public List<Roles> addRoles(@RequestBody List<Roles> roles) {
		return rolesService.addOrUpdate(roles);
	}

	@RequestMapping(path = "{roleId}", method = RequestMethod.GET)
	public Roles getRole(@PathVariable String roleId) {
		return rolesService.getByRoleId(roleId);
	}
	
	@RequestMapping(path="delete/{roleId}", method = RequestMethod.POST)
	public String deleteRole(@PathVariable String roleId){
		rolesService.deleteRole(Integer.parseInt(roleId));
		return RenoConstants.MAIL_SUCCESS;
	}

}
