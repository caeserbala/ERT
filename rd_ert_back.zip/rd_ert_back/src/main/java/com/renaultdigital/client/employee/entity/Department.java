package com.renaultdigital.client.employee.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "esp_department")
public class Department implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Basic(optional = false)
	@Column(name = "dept_name")
	private String deptName;
	@Basic(optional = false)
	@Column(name = "func_mgr_rnno")
	private String funcMgrRnno;
	@Column(name = "hr_spoc")
	private String hrSpoc;
	@Column(name = "hr_rm")
	private String hrRm;
	@Column(name = "vp")
	private String vp;
	@Column(name = "gm")
	private String gm;
	

	public Department() {
	}

	public Department(String deptName) {
		this.deptName = deptName;
	}

	public Department(String deptName, String funcMgrRnno) {

		this.deptName = deptName;
		this.funcMgrRnno = funcMgrRnno;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getFuncMgrRnno() {
		return funcMgrRnno;
	}

	public void setFuncMgrRnno(String funcMgrRnno) {
		this.funcMgrRnno = funcMgrRnno;
	}

	public String getHrSpoc() {
		return hrSpoc;
	}

	public void setHrSpoc(String hrSpoc) {
		this.hrSpoc = hrSpoc;
	}

	public String getHrRm() {
		return hrRm;
	}

	public void setHrRm(String hrRm) {
		this.hrRm = hrRm;
	}

	public String getVp() {
		return vp;
	}

	public void setVp(String vp) {
		this.vp = vp;
	}

	public String getGm() {
		return gm;
	}

	public void setGm(String gm) {
		this.gm = gm;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((deptName == null) ? 0 : deptName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Department other = (Department) obj;
		if (deptName == null) {
			if (other.deptName != null)
				return false;
		} else if (!deptName.equals(other.deptName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Department[ deptName=" + deptName + " ]";
	}



}
