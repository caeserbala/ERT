package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.SubDepartment;
import com.renaultdigital.client.employee.service.ISubDepartmentService;

@CrossOrigin
@RestController
@RequestMapping(path = "/rd/ert/rest/v1/sub-departments/")
public class SubDepartmentController {

	@Autowired
	ISubDepartmentService subDepartmentService;

	@RequestMapping(method = RequestMethod.GET)
	public List<SubDepartment> getAllSubDepartment() {
		return subDepartmentService.getAllSubDepartments();
	}

	@RequestMapping(method = RequestMethod.POST)
	public List<SubDepartment> addSubDepartment(@RequestBody List<SubDepartment> subDepartments) {
		return subDepartmentService.addOrUpdate(subDepartments);
	}

	@RequestMapping(path = "{subDeptName}", method = RequestMethod.GET)
	public SubDepartment deleteSubDepartment(@PathVariable("subDeptName") String subDeptName) {
		return subDepartmentService.getBySubDeptName(subDeptName);
	}

	@RequestMapping(path = "dept/{deptName}", method = RequestMethod.GET)
	public List<SubDepartment> getSubDeptByDept(@PathVariable("deptName") String deptName) {
		return subDepartmentService.getSubDeptByDeptName(deptName);
	}

}
