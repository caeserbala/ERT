package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.SubDepartment;

public interface ISubDepartmentService {

	public List<SubDepartment> getAllSubDepartments();

	public List<SubDepartment> addOrUpdate(List<SubDepartment> subDepartments);

	public SubDepartment getBySubDeptName(String subDeptName);

	public List<SubDepartment> getSubDeptByDeptName(String deptName);

}
