package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.Roles;
import com.renaultdigital.client.employee.repository.IRolesRepository;

@Service
public class RolesService implements IRolesService {

	@Autowired
	IRolesRepository rolesRepository;

	@Override
	public List<Roles> getAllRoles() {
		return rolesRepository.findAll();
	}

	@Override
	public List<Roles> addOrUpdate(List<Roles> roles) {
		return (List<Roles>) rolesRepository.save((Iterable<Roles>) roles);
	}

	@Override
	public Roles getByRoleId(String roleId) {
		return rolesRepository.findOne(Integer.valueOf(roleId));
	}

	@Override
	public void deleteRole(int roleId) {		
		rolesRepository.delete(roleId);
	}

}
