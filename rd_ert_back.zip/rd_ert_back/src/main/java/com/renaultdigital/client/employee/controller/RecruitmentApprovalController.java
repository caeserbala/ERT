package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.RecruitmentApproval;
import com.renaultdigital.client.employee.service.IRecruitmentApprovalService;

@CrossOrigin
@RestController
@RequestMapping(path = "/rd/ert/rest/v1/recruitmentapprovals/")
public class RecruitmentApprovalController {

	@Autowired
	IRecruitmentApprovalService approvalService;

	@RequestMapping(method = RequestMethod.GET)
	public List<RecruitmentApproval> getAllRecruitmentApprovals() {
		return approvalService.getAllRecruitmentApprovals();
	}

	@RequestMapping(method = RequestMethod.POST)
	public List<RecruitmentApproval> addRecruitmentApprovals(@RequestBody List<RecruitmentApproval> approvals) {
		return approvalService.addOrUpdate(approvals);
	}

	@RequestMapping(path = "{rnNum}", method = RequestMethod.GET)
	public RecruitmentApproval getById(@PathVariable String rnNum) {
		return approvalService.findByRnNumber(rnNum);
	}

}
