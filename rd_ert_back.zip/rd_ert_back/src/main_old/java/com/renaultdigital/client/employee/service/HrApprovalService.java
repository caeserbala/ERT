package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.entity.HrApproval;
import com.renaultdigital.client.employee.entity.Status;
import com.renaultdigital.client.employee.repository.IEmployeeRepository;
import com.renaultdigital.client.employee.repository.IEmployeeResignationRepository;
import com.renaultdigital.client.employee.repository.IHrApprovalRepository;
import com.renaultdigital.client.employee.repository.IStatusRepository;
import com.renaultdigital.client.employee.util.Constants;
import com.renaultdigital.client.employee.util.Constants.StatusCode;

@Service
class HrApprovalService implements IHrApprovalService {

	@Autowired
	IHrApprovalRepository hrApprovalRepository;

	@Autowired
	IEmployeeRepository employeeRepository;

	@Autowired
	IStatusRepository statusCodeRepository;

	@Autowired
	IEmployeeResignationRepository employeeResignationRepository;

	@Override
	public List<HrApproval> getAllHrApprovals() {
		return hrApprovalRepository.findAll();
	}

	@Override
	public List<HrApproval> addOrUpdate(List<HrApproval> hrApprovals) {
		HrApproval hrApproval = hrApprovals.get(0);
		EmployeeResignation employeeResignation = employeeResignationRepository
				.findOne(hrApproval.getResignationId().getrId());

		if (Constants.APPROVED.equalsIgnoreCase(hrApproval.getStatus())) {
			employeeResignation.setStatusCode(statusCodeRepository.findOne(StatusCode.TO_HR_RM));
		}
		if (Constants.APPROVED.equalsIgnoreCase(hrApproval.getHrRMStatus())) {
			employeeResignation.setStatusCode(new Status(StatusCode.HR_RM_APPROVED));
			EmployeeInfo empInfo=employeeRepository.findByIpnEqualsIgnoreCaseOrRnNumEqualsIgnoreCase(hrApproval.getRnNum().getRnNum(), hrApproval.getRnNum().getRnNum());
			empInfo.setStatus(Constants.INACTIVE);
			employeeRepository.save(empInfo);
		}
		if (Constants.REJECTED.equalsIgnoreCase(hrApproval.getStatus())) {
			employeeResignation.setStatusCode(new Status(StatusCode.HR_BP_REJECT));
		}
		if (Constants.REJECTED.equalsIgnoreCase(hrApproval.getHrRMStatus())) {
			employeeResignation.setStatusCode(new Status(StatusCode.HR_RM_REJECT));
		}

		hrApproval.setResignationId(employeeResignation);

		if (hrApproval.getHraId() == null) {
			HrApproval holder = hrApprovalRepository.findByRnNumRnNum(employeeResignation.getRnNum().getRnNum());
			if (null != holder) {
				hrApproval.setHraId(holder.getHraId());
			}
		}

		return (List<HrApproval>) hrApprovalRepository.save((Iterable<HrApproval>) hrApprovals);
	}

	@Override
	public HrApproval getByRnNumber(String rnNum) {
		return hrApprovalRepository.findByRnNumRnNum(rnNum);
	}

}
