package com.renaultdigital.client.employee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "esp_manager_approval")
public class ManagerApproval implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "ra_id")
	private Integer raId;
	@Column(name = "rehire")
	private Boolean rehire;
	@Column(name = "comments")
	private String comments;
	@Column(name = "notice_period_recovery")
	private Integer noticePeriodRecovery;
	@Column(name = "leave_balance")
	private Integer leaveBalance;
	@Column(name = "status")
	private String status;

	@Column(name = "fn_mgr_status")
	private String fnMgrStatus;
	@Column(name = "fn_mgr_comments")
	private String fnMgrComments;

	@JoinColumn(name = "rn_num", referencedColumnName = "rn_num")
	@ManyToOne
	private EmployeeInfo rnNum;

	@JoinColumn(name = "r_id", referencedColumnName = "r_id")
	@ManyToOne
	private EmployeeResignation resignationId;

	@Column(name = "approved_date")
	@Temporal(TemporalType.DATE)
	private Date approvedDate;

	@Column(name = "fm_approved_date")
	@Temporal(TemporalType.DATE)
	private Date fmApprovedDate;

	public EmployeeResignation getResignationId() {
		return resignationId;
	}

	public void setResignationId(EmployeeResignation resignationId) {
		this.resignationId = resignationId;
	}

	public String getFnMgrStatus() {
		return fnMgrStatus;
	}

	public void setFnMgrStatus(String fnMgrStatus) {
		this.fnMgrStatus = fnMgrStatus;
	}

	public String getFnMgrComments() {
		return fnMgrComments;
	}

	public void setFnMgrComments(String fnMgrComments) {
		this.fnMgrComments = fnMgrComments;
	}

	public ManagerApproval() {
	}

	public ManagerApproval(Integer raId) {
		this.raId = raId;
	}

	public Integer getRaId() {
		return raId;
	}

	public void setRaId(Integer raId) {
		this.raId = raId;
	}

	public Boolean getRehire() {
		return rehire;
	}

	public void setRehire(Boolean rehire) {
		this.rehire = rehire;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Integer getNoticePeriodRecovery() {
		return noticePeriodRecovery;
	}

	public void setNoticePeriodRecovery(Integer noticePeriodRecovery) {
		this.noticePeriodRecovery = noticePeriodRecovery;
	}

	public Integer getLeaveBalance() {
		return leaveBalance;
	}

	public void setLeaveBalance(Integer leaveBalance) {
		this.leaveBalance = leaveBalance;
	}

	public EmployeeInfo getRnNum() {
		return rnNum;
	}

	public void setRnNum(EmployeeInfo rnNum) {
		this.rnNum = rnNum;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public Date getFmApprovedDate() {
		return fmApprovedDate;
	}

	public void setFmApprovedDate(Date fmApprovedDate) {
		this.fmApprovedDate = fmApprovedDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((raId == null) ? 0 : raId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ManagerApproval other = (ManagerApproval) obj;
		if (raId == null) {
			if (other.raId != null)
				return false;
		} else if (!raId.equals(other.raId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "com.renaultdigital.client.Employee.Entity.ManagerApproval[ raId=" + raId + " ]";
	}

}
