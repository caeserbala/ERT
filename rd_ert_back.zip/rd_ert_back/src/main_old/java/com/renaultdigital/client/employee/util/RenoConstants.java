package com.renaultdigital.client.employee.util;

public final class RenoConstants {

	private RenoConstants() {
		// Avoid creating instance
	}

	//Production Arca
	//public static final String LDAPURI = "ldap://annope01.mc2.renault.fr:389";
	//DEV Arca
	public static final String LDAPURI = "ldap://anndev.mc2.renault.fr:389";
	public static final String CONTEXT_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
	public static final String SECURITY_AUTHENTICATION = "simple";
	public static final String CONTEXT_SEARCH = "ou=People,o=renault";
	public static final long EXPIRATIONTIME = 1000L * 60 * 60 * 24 * 31 * 12;
	public static final String SECRET_STRING = "Um50QmNpU2VjcmV0S2V5VmFsVG9FbmNyeXB0RGF0YQ==";
	public static final String TOKEN_PREFIX_STRING = "Bearer ";
	public static final String HEADER_STRING = "Authorization";
	public static final String CONTENT_TYPE_JSON_STRING = "application/json";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String CONTENT_TYPE_TEXT_STRING = "application/text";
	public static final String DN = "uid=z015481,ou=rntbci,ou=People,o=renault";
	public static final String PW_STRING = "ejAxNTQ4MQ==";
	public static final String SEARCH_FILTER_STRING = "(&(sAMAccountName={0}))";
	public static final String GROUP_SEARCH_BASE_STRING = "ou=rights,o=renault";
	public static final String ROLE_PREFIX_STRING = "cn";
	public static final String USERSEARCHFILTER_STRING = "(uid={0})";
	public static final String LOGIN_FILTER_URI_STRING = "/login";
	public static final String ALLOW_ORIGIN = "Access-Control-Allow-Origin";
	public static final String ALLOW_METHODS = "Access-Control-Allow-Methods";
	public static final String ALLOW_METHODS_VALUE = "POST, PUT, GET, OPTIONS, DELETE";
	public static final String ALLOW_HEADERS = "Access-Control-Allow-Headers";
	public static final String ALLOW_HEADERS_VALUE = "x-requested-with";
	public static final String ALLOW_MAX_AGE = "Access-Control-Max-Age";
	public static final String EXPOSE_HEADERS = "Access-Control-Expose-Headers";
	public static final String EXPOSE_HEADERS_VALUE = "Authorization,Access-Control-Allow-Origin,Content-Type, Accept, X-Requested-With";
	public static final String RD_DEVELOPERS = "Reno-Developers";
	public static final String RD_TEAM = "RD-Team";
	public static final String MAIL_SUCCESS = "{\"message\": \"Success\"}";
	public static final String MAIL_FAILURE = "{\"message\": \"Error\"}";
	public static final String EMPLOYEE_ROLE = "EMPLOYEE";

}
