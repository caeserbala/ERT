package com.renaultdigital.client.employee.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.EmployeeResignation;

@Repository
public interface IEmployeeResignationRepository extends JpaRepository<EmployeeResignation, Integer> {

	List<EmployeeResignation> findAll();

	List<EmployeeResignation> findByReportingMgrNo(String rnNum);

	Long countByReportingMgrNo(String rnNum);

	EmployeeResignation findByRnNumRnNum(String employeeInfo);

	List<EmployeeResignation> findByFuncMgrRnnoEqualsIgnoreCaseOrReportingMgrNoEqualsIgnoreCase(String fnmgrRnNum,
			String repmgrRnNum);

	List<EmployeeResignation> findByFuncMgrRnnoEqualsIgnoreCase(String fnmgrRnNum);

	List<EmployeeResignation> findByReportingMgrNoEqualsIgnoreCase(String repmgrRnNum);

	List<EmployeeResignation> findByHrBPMailEqualsIgnoreCase(String hrNum);

	List<EmployeeResignation> findByHrRMNoEqualsIgnoreCase(String hrNum);

}
