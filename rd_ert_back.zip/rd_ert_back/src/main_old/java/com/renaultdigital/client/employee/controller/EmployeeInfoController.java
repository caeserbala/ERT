package com.renaultdigital.client.employee.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.service.IEmployeeService;
import com.renaultdigital.client.employee.util.Constants;
import com.renaultdigital.client.employee.util.LdapUtil;

@CrossOrigin
@RestController
@RequestMapping(path = "/rd/ert/rest/v1/employees/")
public class EmployeeInfoController {

	@Autowired
	IEmployeeService employeeService;

	@RequestMapping(method = RequestMethod.GET)
	public List<EmployeeInfo> getAllEmployees() {
		List<EmployeeInfo> info = employeeService.getAllEmployeeInfos();
		List<EmployeeInfo> responseList = new ArrayList<>();
		if (info != null && (!info.isEmpty())) {
			responseList = info.stream().limit(200).collect(Collectors.toList());
		
					Integer sample = new Integer((int) info.stream().limit(890).count());
		}
		return responseList;
	}

	@RequestMapping(method = RequestMethod.POST)
	public List<EmployeeInfo> addEmployee(@RequestBody List<EmployeeInfo> employees) {
		return employeeService.addOrUpdate(employees);
	}

	@RequestMapping(path = "{employeeId}", method = RequestMethod.GET)
	public EmployeeInfo addEmployee(@PathVariable String employeeId) {
		return employeeService.getEmployee(employeeId);
	}

	@RequestMapping(path = "/name/{name}", method = RequestMethod.GET)
	public ResponseEntity<Map<String, Object>> getEmployeeByName(@PathVariable String name) {
		Map<String, Object> response = new HashMap<>();
		HttpStatus httpStatus = HttpStatus.NOT_FOUND;
		response.put(Constants.MESSAGE, Constants.FAILURE_MESSAGE);
		response.put(Constants.DESCRIPTION, Constants.EMPTY_DESCRIPTION);
		List<EmployeeInfo> list = new ArrayList<>();
		response.put(Constants.EMPLOYEELIST, list);

		if (name.isEmpty() || name.length() < 3)
			response.put(Constants.DESCRIPTION, Constants.LENGTH_DESCRIPTION);
		else {
			list = employeeService.getEmployeeByName(name);
			if (list != null && !list.isEmpty()) {
				response.put(Constants.DESCRIPTION, Constants.SUCCESS_MESSAGE);
				response.put(Constants.MESSAGE, Constants.SUCCESS_MESSAGE);
				response.put(Constants.EMPLOYEELIST, list);
				httpStatus = HttpStatus.OK;
			}
		}
		return new ResponseEntity<>(response, httpStatus);
	}

	@RequestMapping(path = "report/gender", method = RequestMethod.GET)
	public String getEmployeeReportByGender() {
		return employeeService.getEmployeeReportByGender().toString();
	}

	@RequestMapping(path = "report/designation", method = RequestMethod.GET)
	public String getEmployeeReportByDesgination() {
		return employeeService.getEmployeeReportByDesignation().toString();
	}

	@RequestMapping(path = "report/department/{startDate}/{endDate}", method = RequestMethod.GET)
	public String getEmployeeReportByDepartment(@PathVariable String startDate, @PathVariable String endDate) {
		return employeeService.getEmployeeReportByDepartmentWithDate(startDate, endDate).toString();
	}

	@RequestMapping(path = "report/department/", method = RequestMethod.GET)
	public String getEmployeeReportByDepartment() {
		return employeeService.getEmployeeReportByDepartment().toString();
	}

	@RequestMapping(path = "report/department-designation/", method = RequestMethod.GET)
	public String getEmployeeReportByDepartmentWithDesignation() {
		return employeeService.getEmployeeReportByDepartmentWithDesignation().toString();
	}

	@RequestMapping(path = "report/reason/", method = RequestMethod.GET)
	public String getEmployeeReportByReason() {
		return employeeService.getEmployeeReportByReason().toString();
	}

	@RequestMapping(path = "report/", method = RequestMethod.GET)
	public String getEmployeeExitReport() {
		return employeeService.getEmployeeOverAllReport().toString();
	}

	@RequestMapping(path = "report/year", method = RequestMethod.GET)
	public String getEmployeeReportByYear() {
		return employeeService.getEmployeeReportByYear().toString();
	}

	@RequestMapping(path = "report/yearDept/{year}/{dept}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getEmployeeReportByYearandDept(@PathVariable(required = false, name = "year") String year,
			@PathVariable(name = "dept", required = false) String dept) {
		return employeeService.getEmployeeReportByYearAndDept(year, dept).toString();
	}

	@RequestMapping(path = "report/yearDept", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, Object> getEmployeeInitialReport() {
		return employeeService.getYears();
	}

	@RequestMapping(path = "image/{zid}", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public byte[] getEmployeeImage(@PathVariable String zid) throws NamingException, IOException {
		Map<String, Object> response = null;
		byte[] image = null;
		response = LdapUtil.authenticate(zid);
		if (null != response && null != response.get("photo")) {
			image = (byte[]) response.get("photo");
		}

		return image;
	}

	@RequestMapping(method = RequestMethod.GET, path = "page")
	public List<EmployeeInfo> getEmployeesPage(@RequestParam("page") int page, @RequestParam("size") int size) {
		Pageable pageable = new PageRequest(page, size);
		return employeeService.getAllEmployeeInfos(pageable);
	}

}
