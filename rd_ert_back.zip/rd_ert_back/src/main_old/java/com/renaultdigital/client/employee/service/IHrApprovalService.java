package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.HrApproval;

public interface IHrApprovalService {
	
	public List<HrApproval> getAllHrApprovals();
	
	public List<HrApproval> addOrUpdate(List<HrApproval> hrApprovals);
	
	public HrApproval getByRnNumber(String rnNum);

}
