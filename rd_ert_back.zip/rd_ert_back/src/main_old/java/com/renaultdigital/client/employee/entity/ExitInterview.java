package com.renaultdigital.client.employee.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="esp_exit_interview")
public class ExitInterview implements Serializable{

	private static final long serialVersionUID = 8611733136404699250L;
	@Id
	@Column(name="ei_id")
	int ei_id;
	
	@JoinColumn(name = "r_id", referencedColumnName = "r_id")
	@ManyToOne
	private EmployeeResignation resignationId;
	
	@JoinColumn(name = "rn_num", referencedColumnName = "rn_num")
	@ManyToOne
	private EmployeeInfo rnNum;
	
	@Column(name="company_joining")
	private String companyJoining;
	
	@Column(name="university_course")
	private String universityCourse;
	
	@Column(name="sup_sugg_made")
	private String supSuggestionMade;
	
	@Column(name="sup_recog_work")
	private String supRecognitionWork;
	
	@Column(name="sup_collab_workteam")
	private String supCollabWorkTeam;
	
	@Column(name="sup_helped_prob")
	private String supHelpedProblem;
	
	@Column(name="exp_work_env")
	private String expWorkEnvironment;
	
	@Column(name="exp_multiculture_env")
	private String expMulticultureEnv;
	
	@Column(name="exp_solved_timeline")
	private String expSolvedTimeline;
	
	@Column(name="exp_hr_help")
	private String expHrHelp;
	
	@Column(name="exp_organization")
	private String expOrganization;
	
	@Column(name="comments_suggestion")
	private String commentsSuggestion;

	public int getEi_id() {
		return ei_id;
	}

	public void setEi_id(int ei_id) {
		this.ei_id = ei_id;
	}

	public EmployeeResignation getResignationId() {
		return resignationId;
	}

	public void setResignationId(EmployeeResignation resignationId) {
		this.resignationId = resignationId;
	}

	public EmployeeInfo getRnNum() {
		return rnNum;
	}

	public void setRnNum(EmployeeInfo rnNum) {
		this.rnNum = rnNum;
	}

	public String getCompanyJoining() {
		return companyJoining;
	}

	public void setCompanyJoining(String companyJoining) {
		this.companyJoining = companyJoining;
	}

	public String getUniversityCourse() {
		return universityCourse;
	}

	public void setUniversityCourse(String universityCourse) {
		this.universityCourse = universityCourse;
	}

	public String getSupSuggestionMade() {
		return supSuggestionMade;
	}

	public void setSupSuggestionMade(String supSuggestionMade) {
		this.supSuggestionMade = supSuggestionMade;
	}

	public String getSupRecognitionWork() {
		return supRecognitionWork;
	}

	public void setSupRecognitionWork(String supRecognitionWork) {
		this.supRecognitionWork = supRecognitionWork;
	}

	public String getSupCollabWorkTeam() {
		return supCollabWorkTeam;
	}

	public void setSupCollabWorkTeam(String supCollabWorkTeam) {
		this.supCollabWorkTeam = supCollabWorkTeam;
	}

	public String getSupHelpedProblem() {
		return supHelpedProblem;
	}

	public void setSupHelpedProblem(String supHelpedProblem) {
		this.supHelpedProblem = supHelpedProblem;
	}

	public String getExpWorkEnvironment() {
		return expWorkEnvironment;
	}

	public void setExpWorkEnvironment(String expWorkEnvironment) {
		this.expWorkEnvironment = expWorkEnvironment;
	}

	public String getExpMulticultureEnv() {
		return expMulticultureEnv;
	}

	public void setExpMulticultureEnv(String expMulticultureEnv) {
		this.expMulticultureEnv = expMulticultureEnv;
	}

	public String getExpSolvedTimeline() {
		return expSolvedTimeline;
	}

	public void setExpSolvedTimeline(String expSolvedTimeline) {
		this.expSolvedTimeline = expSolvedTimeline;
	}

	public String getExpHrHelp() {
		return expHrHelp;
	}

	public void setExpHrHelp(String expHrHelp) {
		this.expHrHelp = expHrHelp;
	}

	public String getExpOrganization() {
		return expOrganization;
	}

	public void setExpOrganization(String expOrganization) {
		this.expOrganization = expOrganization;
	}

	public String getCommentsSuggestion() {
		return commentsSuggestion;
	}

	public void setCommentsSuggestion(String commentsSuggestion) {
		this.commentsSuggestion = commentsSuggestion;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ei_id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExitInterview other = (ExitInterview) obj;
		if (ei_id != other.ei_id)
			return false;
		return true;
	}

}
