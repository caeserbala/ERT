package com.renaultdigital.client.employee.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.entity.ManagerApproval;
import com.renaultdigital.client.employee.model.ApprovalStatus;
import com.renaultdigital.client.employee.repository.IEmployeeRepository;
import com.renaultdigital.client.employee.repository.IEmployeeResignationRepository;
import com.renaultdigital.client.employee.repository.IManagerApprovalRepository;
import com.renaultdigital.client.employee.util.Constants;
import com.renaultdigital.client.employee.util.DBUtils;
import com.renaultdigital.client.employee.util.MailUtils;
import com.renaultdigital.client.employee.util.Utils;

@Service
public class EmployeeResignationService implements IEmployeeResignationService {

	@Autowired
	IEmployeeResignationRepository employeeResignationRepository;

	@Autowired
	IEmployeeRepository employeeRepository;

	@Autowired
	IManagerApprovalRepository managerApprovalRepository;

	@PersistenceContext
	EntityManager em;

	@Override
	public List<EmployeeResignation> getAllEmployeeResignations() {
		return employeeResignationRepository.findAll();
	}

	@Override
	public List<EmployeeResignation> addOrUpdate(List<EmployeeResignation> employeeResignationInfos) {
		boolean doStuff = false;
		int rId = employeeResignationInfos.get(0).getrId();
		if (rId == 0) {
			doStuff = true;
		}
		for (EmployeeResignation employeeResignation : employeeResignationInfos) {
			EmployeeInfo info = employeeRepository.findByEmailEqualsIgnoreCase(employeeResignation.getHrBPMail());
			if (info != null && info.getRnNum() != "") {
				employeeResignation.setHrBPMail(info.getRnNum());
			}
		}
		List<EmployeeResignation> employeeResignations = (List<EmployeeResignation>) employeeResignationRepository
				.save((Iterable<EmployeeResignation>) employeeResignationInfos);
		EmployeeResignation employeeResignation = employeeResignations.get(0);
		employeeResignation.setExitDate(employeeResignationInfos.get(0).getExitDate());
		if (doStuff) {
			updateEmployeeInfo(employeeResignation);
			updateApprovalsInfo(employeeResignation);
			
		}
		triggerMailToManager(employeeResignation,doStuff);
		return employeeResignations;
	}

	private void updateApprovalsInfo(EmployeeResignation employeeResignation) {
		// Manager Approval
		ManagerApproval managerApproval = new ManagerApproval();
		managerApproval.setStatus(Constants.PENDING);
		managerApproval.setFnMgrStatus(Constants.PENDING);
		managerApproval.setResignationId(employeeResignation);
		managerApproval.setRnNum(employeeResignation.getRnNum());
		managerApprovalRepository.save(managerApproval);

	}

	private void updateEmployeeInfo(EmployeeResignation employeeResignation) {
		EmployeeInfo employeeInfo = employeeResignation.getRnNum();
		Date resignationDate = employeeResignation.getDateOfResignation();
		employeeInfo.setResignationDate(resignationDate);
		Calendar c = Calendar.getInstance();
		c.setTime(resignationDate);
		c.add(Calendar.DATE, Constants.NOTICEPERIOD_DAYS);
		Date exitDate = c.getTime();
		employeeInfo.setExitDate(employeeResignation.getExitDate());
		employeeResignation.setRnNum(employeeRepository.save(employeeInfo));
	}

	@Override
	public List<EmployeeResignation> getResignationsByManager(String rnNumber) {
		return employeeResignationRepository.findByReportingMgrNo(rnNumber);
	}

	@Override
	public EmployeeResignation getByRnNumber(String rnNumber) {
		return employeeResignationRepository.findByRnNumRnNum(rnNumber);
	}

	@Override
	public ApprovalStatus getApprovalStatusByRnNumber(String rnNumber) {
		Object[] resultSet = DBUtils.executeNativeQueryForApprovalStatus(em,
				Constants.APPROVAL_STATUS_QUERY.replace(Constants.ASTERIK, rnNumber));

		if (null != resultSet && resultSet.length!=0) {
			return new ApprovalStatus(Utils.getAsString(resultSet[0]), Utils.getAsString(resultSet[1]),
					Utils.getAsString(resultSet[2]), Utils.getAsString(resultSet[3]), Utils.getAsString(resultSet[4]),
					Utils.getAsString(resultSet[5]), Utils.getAsString(resultSet[6]), Utils.getAsString(resultSet[7]),
					Utils.getAsString(resultSet[8]), Utils.getAsString(resultSet[9]), Utils.getAsString(resultSet[10]),
					Utils.getAsString(resultSet[11]), Utils.getAsString(resultSet[12]),
					Utils.getAsString(resultSet[13]), Utils.getAsString(resultSet[14]),
					Utils.getAsString(resultSet[15]), Utils.getAsString(resultSet[16]),
					Utils.getAsString(resultSet[17]), Utils.getAsString(resultSet[18]),
					Utils.getAsString(resultSet[19]), Utils.getAsString(resultSet[20]),
					Utils.getAsString(resultSet[21]), Utils.getAsString(resultSet[22]),
					Utils.getAsString(resultSet[23]), Utils.getAsString(resultSet[24]),
					Utils.getAsString(resultSet[25]), Utils.getAsString(resultSet[26]),
					Utils.getAsString(resultSet[27]), Utils.getAsString(resultSet[28]),
					Utils.getAsString(resultSet[29]), Utils.getAsString(resultSet[30]),
					Utils.getAsString(resultSet[31]), Utils.getAsString(resultSet[32]),
					Utils.getAsString(resultSet[33]), Utils.getAsString(resultSet[34]),
					Utils.getAsString(resultSet[35]));

		}
		return null;
	}

	@Override
	public Boolean getResignationAvailableForManager(String rnNumber) {
		Long avail = employeeResignationRepository.countByReportingMgrNo(rnNumber);
		return (avail > 0) ? true : false;

	}

	private void triggerMailToManager(EmployeeResignation employeeResignation, boolean reqFlag) {

		String name = new StringBuilder().append(employeeResignation.getRnNum().getFirstName()).append(Constants.SPACE)
				.append(employeeResignation.getRnNum().getLastName()).toString();
		String rnNum = employeeResignation.getRnNum().getRnNum();

		String subject;
		String body;
		
		if(reqFlag){
			subject = MailUtils.getSubjectForESPMailApproval(name, rnNum);
			body = MailUtils.getBodyForESPMailApproval(name, rnNum);
		}else{
			subject = MailUtils.getSubjectForESPMailRequestClarification(name, rnNum);
			body = MailUtils.getBodyForESPMailRequestClarification(name, rnNum);
		}

		//String mailTo = "Bakiyaraj.Arulsantiagu@rntbci.com,sasikumar.kamaraj@rntbci.com";
		String mailTo = "Lalitha-Prabha.Subramanian@rntbci.com";
		// employeeRepository.findByIpnEqualsIgnoreCaseOrRnNumEqualsIgnoreCase(
		// mgrRnNum,mgrRnNum) .getEmail();
		String mailCC = "Bakiyaraj.Arulsantiagu@rntbci.com,rajesh.sridharan@rntbci.com";
		// employeeResignation.getSubDepartName().getDeptName().getHrSpoc();

		MailUtils.triggerEmail(mailTo, mailCC, subject, body);
	}

	@Override
	public List<EmployeeResignation> getResignationsByFnManager(String rnNumber) {
		return employeeResignationRepository.findByFuncMgrRnnoEqualsIgnoreCase(rnNumber);
	}

	@Override
	public List<EmployeeResignation> getResignationsByHrBP(String rnNumber) {
		return employeeResignationRepository.findByHrBPMailEqualsIgnoreCase(rnNumber);
	}

	@Override
	public List<EmployeeResignation> getResignationsByHrRM(String rnNumber) {
		return employeeResignationRepository.findByHrRMNoEqualsIgnoreCase(rnNumber);
	}

}
