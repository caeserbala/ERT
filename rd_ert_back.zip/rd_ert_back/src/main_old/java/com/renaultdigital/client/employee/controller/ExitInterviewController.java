package com.renaultdigital.client.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.renaultdigital.client.employee.entity.ExitInterview;
import com.renaultdigital.client.employee.service.IExitInterviewService;

@CrossOrigin
@RestController
@RequestMapping(path="/rd/ert/rest/v1/exitinterview/")
public class ExitInterviewController {
	
	@Autowired
	IExitInterviewService exitInterviewService;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<ExitInterview> getExitInterview(){
		return exitInterviewService.getExitInterview();
	}

	@RequestMapping(method=RequestMethod.POST)
	public List<ExitInterview> postExitInterview(@RequestBody List<ExitInterview> exitInterview){
		return exitInterviewService.postExitInterview(exitInterview);
	}
}
