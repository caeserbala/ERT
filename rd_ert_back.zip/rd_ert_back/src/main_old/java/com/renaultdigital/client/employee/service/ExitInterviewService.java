package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.ExitInterview;
import com.renaultdigital.client.employee.repository.IExitInterviewRepository;

@Service
public class ExitInterviewService implements IExitInterviewService{
	
	@Autowired
	IExitInterviewRepository exitInterviewRepo;

	@Override
	public List<ExitInterview> getExitInterview() {
		return (List<ExitInterview>) exitInterviewRepo.findAll();
	}

	@Override
	public List<ExitInterview> postExitInterview(List<ExitInterview> exitInterview) {
		return (List<ExitInterview>) exitInterviewRepo.save((Iterable<ExitInterview>)exitInterview);
	}

}
