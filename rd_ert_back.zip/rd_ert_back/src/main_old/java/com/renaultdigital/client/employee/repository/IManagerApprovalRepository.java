package com.renaultdigital.client.employee.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.ManagerApproval;

@Repository
public interface IManagerApprovalRepository extends CrudRepository<ManagerApproval, Integer> {
	
	List<ManagerApproval> findAll();

	ManagerApproval findByRnNumRnNum(String employeeInfo);
	
}
