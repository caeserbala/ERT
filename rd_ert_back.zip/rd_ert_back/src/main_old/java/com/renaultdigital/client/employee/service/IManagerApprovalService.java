package com.renaultdigital.client.employee.service;

import java.util.List;

import com.renaultdigital.client.employee.entity.ManagerApproval;

public interface IManagerApprovalService {
	
	public List<ManagerApproval> getAllManagerApprovals();
	
	public List<ManagerApproval> addOrUpdate(List<ManagerApproval> managerApprovals);

	public ManagerApproval findByRnNumber(String rnNumber);
	
}
