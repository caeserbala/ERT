package com.renaultdigital.client.employee.util;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;

public class MailUtils {

	private MailUtils() {
		// setting up mail
	}

	public static String triggerEmail(String mailTo, String mailCC, String subject, String body) {
		JavaMailSender mailSender = mailSender();
		String[] toMail = mailTo.split(",");
		String[] ccMail = mailCC.split(",");
		MimeMessagePreparator mailMessage = mimeMessage -> {
			mimeMessage.addHeader("X-Priority", "1");
			MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true, "UTF-8");
			message.setFrom("ISIT-ESP-Portal@rntbci.com", "Employee-Seperation-Portal Application");
			message.setText(body);
			message.setTo(toMail);
			message.setCc(ccMail);
			message.setSubject(subject);
		};
		try {
			mailSender.send(mailMessage);
			return "success";
		} catch (Exception e) {
			return "failure";
		}
	}

	public static JavaMailSender mailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost("wsmtp.mc2.renault.fr");
		mailSender.setPort(25);
		return mailSender;
	}

	public static String getSubjectForESPMailApproval(String employeeName, String employeeRnNum) {
		return Constants.MAIL_SUBJECT_DATA.replace(Constants.RNNUMBER_KEY, employeeRnNum).replace(Constants.RNNAME_KEY,
				employeeName);
	}

	public static String getBodyForESPMailApproval(String employeeName, String employeeRnNum) {
		return Constants.MAIL_BODY_DATA.replace(Constants.RNNUMBER_KEY, employeeRnNum).replace(Constants.RNNAME_KEY,
				employeeName);
	}
	
	public static String getSubjectForESPMailRequestClarification(String employeeName, String employeeRnNum) {
		return Constants.MAILREQUESTCLARIFICATION_SUBJECT_DATA.replace(Constants.RNNUMBER_KEY, employeeRnNum).replace(Constants.RNNAME_KEY,
				employeeName);
	}
	
	public static String getBodyForESPMailRequestClarification(String employeeName, String employeeRnNum) {
		return Constants.MAILREQUESTCLARIFICATION_BODY_DATA.replace(Constants.RNNUMBER_KEY, employeeRnNum).replace(Constants.RNNAME_KEY,
				employeeName);
	}
}
