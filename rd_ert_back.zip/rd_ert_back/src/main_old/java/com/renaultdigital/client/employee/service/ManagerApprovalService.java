package com.renaultdigital.client.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.entity.HrApproval;
import com.renaultdigital.client.employee.entity.ManagerApproval;
import com.renaultdigital.client.employee.entity.Status;
import com.renaultdigital.client.employee.repository.IEmployeeRepository;
import com.renaultdigital.client.employee.repository.IEmployeeResignationRepository;
import com.renaultdigital.client.employee.repository.IHrApprovalRepository;
import com.renaultdigital.client.employee.repository.IManagerApprovalRepository;
import com.renaultdigital.client.employee.repository.IStatusRepository;
import com.renaultdigital.client.employee.util.Constants;
import com.renaultdigital.client.employee.util.Constants.StatusCode;

@Service
public class ManagerApprovalService implements IManagerApprovalService {

	@Autowired
	IManagerApprovalRepository managerApprovalRepository;

	@Autowired
	IEmployeeRepository employeeRepository;

	@Autowired
	IStatusRepository statusCodeRepository;

	@Autowired
	IEmployeeResignationRepository employeeResignationRepository;

	@Autowired
	IHrApprovalRepository hrApprovalRepository;

	@Override
	public List<ManagerApproval> getAllManagerApprovals() {
		return managerApprovalRepository.findAll();
	}

	@Override
	public List<ManagerApproval> addOrUpdate(List<ManagerApproval> managerApprovals) {
		ManagerApproval managerApproval = managerApprovals.get(0);
		EmployeeResignation employeeResignation = employeeResignationRepository
				.findOne(managerApproval.getResignationId().getrId());
		int i = 0;

		if (Constants.APPROVED.equalsIgnoreCase(managerApproval.getStatus())) {
			employeeResignation.setStatusCode(statusCodeRepository.findOne(StatusCode.TO_FN_MANAGER));
			EmployeeInfo employeeInfo = employeeRepository.findOne(managerApproval.getRnNum().getRnNum());
			employeeInfo.setStatus(Constants.NOTICEPERIOD);
			managerApproval.setRnNum(employeeInfo);
			i += 1;
		}
		if (Constants.APPROVED.equalsIgnoreCase(managerApproval.getFnMgrStatus())) {
			employeeResignation.setStatusCode(new Status(StatusCode.TO_HR_BP));
			i += 1;
		}
		if (Constants.REJECTED.equalsIgnoreCase(managerApproval.getStatus())) {
			employeeResignation.setStatusCode(new Status(StatusCode.MANAGER_REJECTED));
		}
		if (Constants.REJECTED.equalsIgnoreCase(managerApproval.getFnMgrStatus())) {
			employeeResignation.setStatusCode(new Status(StatusCode.FN_MANAGER_REJECTED));
		}
		managerApproval.setResignationId(employeeResignation);

		if (managerApproval.getRaId() == null) {
			ManagerApproval holder = managerApprovalRepository
					.findByRnNumRnNum(employeeResignation.getRnNum().getRnNum());
			if (null != holder) {
				managerApproval.setRaId(holder.getRaId());
			}
		}

		List<ManagerApproval> response = (List<ManagerApproval>) managerApprovalRepository
				.save((Iterable<ManagerApproval>) managerApprovals);
		if (i > 0) {
			updateHrStatus(employeeResignation);
		}
		return response;
	}

	private boolean updateHrStatus(EmployeeResignation employeeResignation) {
		try {
			HrApproval hrApproval = new HrApproval();
			hrApproval.setStatus(Constants.PENDING);
			hrApproval.setHrRMStatus(Constants.PENDING);
			hrApproval.setResignationId(employeeResignation);
			hrApproval.setRnNum(employeeResignation.getRnNum());
			hrApprovalRepository.save(hrApproval);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public ManagerApproval findByRnNumber(String rnNumber) {
		return managerApprovalRepository.findByRnNumRnNum(rnNumber);
	}

}
