package com.renaultdigital.client.employee.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.renaultdigital.client.employee.entity.HrApproval;

@Repository
public interface IHrApprovalRepository extends CrudRepository<HrApproval, Integer> {
	
	List<HrApproval> findAll();
	
	HrApproval findByRnNumRnNum(String rnNum);

}
