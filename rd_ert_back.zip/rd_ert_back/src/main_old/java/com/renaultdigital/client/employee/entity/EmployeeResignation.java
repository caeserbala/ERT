package com.renaultdigital.client.employee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "esp_resignation")
public class EmployeeResignation implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "r_id")
	private Integer rId;
	@Column(name = "reporting_mgr_no")
	private String reportingMgrNo;
	@Column(name = "fn_mgr_no")
	private String funcMgrRnno;
	@Column(name = "hr_bp_no")
	private String hrBPMail;
	@Basic(optional = false)
	@Column(name = "reason")
	private String reason;
	@Column(name = "comments")
	private String comments;
	@Column(name = "date_of_resignation")
	@Temporal(TemporalType.DATE)
	private Date dateOfResignation;
	@JoinColumn(name = "sub_depart_name", referencedColumnName = "sub_depart_name")
	@ManyToOne
	private SubDepartment subDepartName;
	@JoinColumn(name = "rn_num", referencedColumnName = "rn_num")
	@ManyToOne
	private EmployeeInfo rnNum;
	@JoinColumn(name = "status_code", referencedColumnName = "status_code")
	@ManyToOne
	private Status statusCode;
	@Column(name = "hr_rm_no")
	private String hrRMNo;
	@Transient
	private Date exitDate;

	public String getHrBPMail() {
		return hrBPMail;
	}

	public void setHrBPMail(String hrBPMail) {
		this.hrBPMail = hrBPMail;
	}

	public String getFuncMgrRnno() {
		return funcMgrRnno;
	}

	public void setFuncMgrRnno(String funcMgrRnno) {
		this.funcMgrRnno = funcMgrRnno;
	}

	public EmployeeResignation() {
	}

	public EmployeeResignation(Integer rId) {
		this.rId = rId;
	}

	public EmployeeResignation(Integer rId, String reason) {
		this.rId = rId;
		this.reason = reason;
	}

	public Integer getrId() {
		return rId;
	}

	public void setrId(Integer rId) {
		this.rId = rId;
	}

	public String getReportingMgrNo() {
		return reportingMgrNo;
	}

	public void setReportingMgrNo(String reportingMgrNo) {
		this.reportingMgrNo = reportingMgrNo;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getDateOfResignation() {
		return dateOfResignation;
	}

	public void setDateOfResignation(Date dateOfResignation) {
		this.dateOfResignation = dateOfResignation;
	}

	public SubDepartment getSubDepartName() {
		return subDepartName;
	}

	public void setSubDepartName(SubDepartment subDepartName) {
		this.subDepartName = subDepartName;
	}

	public EmployeeInfo getRnNum() {
		return rnNum;
	}

	public void setRnNum(EmployeeInfo rnNum) {
		this.rnNum = rnNum;
	}

	public Status getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Status statusCode) {
		this.statusCode = statusCode;
	}

	public String getHrRMNo() {
		return hrRMNo;
	}

	public void setHrRMNo(String hrRMNo) {
		this.hrRMNo = hrRMNo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rId == null) ? 0 : rId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeResignation other = (EmployeeResignation) obj;
		if (rId == null) {
			if (other.rId != null)
				return false;
		} else if (!rId.equals(other.rId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "EmployeeResignation[ rId=" + rId + " ]";
	}

	public Date getExitDate() {
		return exitDate;
	}

	public void setExitDate(Date exitDate) {
		this.exitDate = exitDate;
	}

}
