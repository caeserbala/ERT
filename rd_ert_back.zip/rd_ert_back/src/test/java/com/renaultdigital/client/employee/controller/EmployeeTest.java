package com.renaultdigital.client.employee.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.renaultdigital.client.employee.BaseTest;
import com.renaultdigital.client.employee.entity.Department;
import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.entity.SubDepartment;
import com.renaultdigital.client.employee.util.Constants;

public class EmployeeTest extends BaseTest {

	@Test
	public void testGetEmployees() throws Exception {
		mockMvc.perform(get("/rd/ert/rest/v1/employees/").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andDo(print());
	}

	@Test
	public void testGetEmployeesPage() throws Exception {
		mockMvc.perform(get("/rd/ert/rest/v1/employees/page").param("page", "0").param("size", "10").headers(headers)
				.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$", hasSize(1))).andExpect(status().isOk())
				.andDo(print());
	}

	@Test
	public void testPostEmployees() {
		Department department = new Department();
		department.setFuncMgrRnno("Sample-test");
		department.setDeptName("Sample-Test");
		department.setGm("Sample-test");
		department.setHrSpoc("Sample-test");
		department.setHrRm("Sample-test");
		List<Department> deptList = new ArrayList<>();
		deptList.add(department);

		departmentRepository.save(deptList);

		SubDepartment subDepartment = new SubDepartment();
		subDepartment.setCostCentreCd("test");
		subDepartment.setCostCentreDesc("test");
		subDepartment.setDeptName(department);
		subDepartment.setSubDepartName("test");
		List<SubDepartment> list = new ArrayList<>();
		list.add(subDepartment);
		subDepartmentRepository.save(list);

		EmployeeInfo info = new EmployeeInfo();
		info.setRnNum("Rsample-test");
		info.setDesignation("sample-test");
		info.setFirstName("sample-test");
		info.setLastName("sample-test");
		info.setGender("sample-test");
		info.setGrade("sample-test");
		info.setIpn("sample-test");
		info.setDoj(new Date());
		info.setSubDepartName(subDepartment);
		List<EmployeeInfo> employeeInfos = new ArrayList<>();
		employeeInfos.add(info);

		try {
			ObjectMapper mapper = new ObjectMapper();
			String content = mapper.writeValueAsString(employeeInfos);

			mockMvc.perform(post("/rd/ert/rest/v1/employees/").contentType(MediaType.APPLICATION_JSON_VALUE)
					.content(content).headers(headers)).andExpect(status().isOk()).andDo(print())
					.andExpect(jsonPath("$", hasSize(1))).andExpect(jsonPath("$[0].rnNum", is("Rsample-test")))
					.andReturn();

			mockMvc.perform(get("/rd/ert/rest/v1/employees/Rsample-test").headers(headers)).andExpect(status().isOk())
					.andDo(print()).andExpect(jsonPath("$.rnNum", is("Rsample-test"))).andReturn();

			employeeRepository.delete(info);
			subDepartmentRepository.delete(subDepartment);
			departmentRepository.delete(department);

		} catch (Exception e) {
			employeeRepository.delete(info);
			subDepartmentRepository.delete(subDepartment);
			departmentRepository.delete(department);
		}

	}

	@Test
	public void testGetEmployeeByName() throws Exception {
		mockMvc.perform(get("/rd/ert/rest/v1/employees/name/sas").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$.description", is("Success")))
				.andReturn();

		mockMvc.perform(get("/rd/ert/rest/v1/employees/name/s").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(404)).andExpect(jsonPath("$.description", is(Constants.LENGTH_DESCRIPTION)))
				.andReturn();
	}

	@Test
	public void testGetReport() throws Exception {
		mockMvc.perform(
				get("/rd/ert/rest/v1/employees/report/gender").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$", is(not(nullValue())))).andReturn();

		mockMvc.perform(
				get("/rd/ert/rest/v1/employees/report/designation").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$", is(not(nullValue())))).andReturn();

		mockMvc.perform(get("/rd/ert/rest/v1/employees/report/department/2017-01-01/2018-01-31").headers(headers)
				.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print())
				.andExpect(jsonPath("$", is(not(nullValue())))).andReturn();

	}

	@Test
	public void testGetReportByYear() throws Exception {

		mockMvc.perform(
				get("/rd/ert/rest/v1/employees/report/year").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$", is(not(nullValue())))).andReturn();

	}

	@Test
	public void testGetReport1() throws Exception {
		mockMvc.perform(
				get("/rd/ert/rest/v1/employees/report/department/").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$", is(not(nullValue())))).andReturn();

		mockMvc.perform(get("/rd/ert/rest/v1/employees/report/department-designation/").headers(headers)
				.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print())
				.andExpect(jsonPath("$", is(not(nullValue())))).andReturn();

		mockMvc.perform(get("/rd/ert/rest/v1/employees/report/").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$", is(not(nullValue())))).andReturn();
	}

	@Test
	public void testGetImage() throws Exception {
		mockMvc.perform(
				get("/rd/ert/rest/v1/employees/image/z015481").headers(headers).accept(MediaType.IMAGE_JPEG_VALUE))
				.andExpect(status().isOk());

		mockMvc.perform(
				get("/rd/ert/rest/v1/employees/image/z99999").headers(headers).accept(MediaType.IMAGE_JPEG_VALUE))
				.andExpect(status().isOk());
	}

}
