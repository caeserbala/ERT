package com.renaultdigital.client.employee.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.renaultdigital.client.employee.BaseTest;
import com.renaultdigital.client.employee.entity.Reason;

public class ReasonsControllerTest extends BaseTest {

	@Test
	public void testGetAllFinance() throws Exception {
		mockMvc.perform(get("/rd/ert/rest/v1/reasons/").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andDo(print());
	}
	
	@Test
	public void testAddReasonApprovals() throws Exception {
		Reason reason=new Reason();
		reason.setReasonName("Rsample-test");
		List<Reason> reasonList = new ArrayList<>();
		reasonList.add(reason);
		Integer id = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			String content = mapper.writeValueAsString(reasonList);

			MvcResult result = mockMvc
					.perform(post("/rd/ert/rest/v1/reasons/").contentType(MediaType.APPLICATION_JSON_VALUE)
							.content(content).accept(MediaType.APPLICATION_JSON_VALUE).headers(headers))
					.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$", is(not(nullValue()))))
					.andReturn();

			String jsonValue = result.getResponse().getContentAsString();
			id = JsonPath.read(jsonValue, "$[0].id");

			mockMvc.perform(get("/rd/ert/rest/v1/reasons/"+id).headers(headers))
					.andExpect(status().isOk()).andExpect(jsonPath("$", is(not(nullValue())))).andDo(print())
					.andReturn();

			reasonRepository.delete(id);
			

		} catch (Exception e) {
			logger.info("Error occured in testAddDomains " + e.getMessage());
		}
	}
	
	
	@Test
	public void testAddReasonDelete() throws Exception {
		Reason reason=new Reason();
		reason.setReasonName("Rsample-test");
		List<Reason> financeList = new ArrayList<>();
		financeList.add(reason);
		Integer id = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			String content = mapper.writeValueAsString(financeList);

			MvcResult result = mockMvc
					.perform(post("/rd/ert/rest/v1/reasons/").contentType(MediaType.APPLICATION_JSON_VALUE)
							.content(content).accept(MediaType.APPLICATION_JSON_VALUE).headers(headers))
					.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$", is(not(nullValue()))))
					.andReturn();

			String jsonValue = result.getResponse().getContentAsString();
			id = JsonPath.read(jsonValue, "$[0].id");
			String content1 = mapper.writeValueAsString(id);
			mockMvc.perform(get("/rd/ert/rest/v1/reasons/{id}",id).headers(headers).accept(MediaType.APPLICATION_JSON))
			.andExpect(status().isOk());
			 mockMvc
				.perform(post("/rd/ert/rest/v1/reasons/delete/{id}",id).contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(content1).accept(MediaType.APPLICATION_JSON_VALUE).headers(headers))
				.andExpect(status().isOk())
				.andReturn();
			

		} catch (Exception e) {
			logger.info("Error occured in testAddDomains " + e.getMessage());
		}
	}

}
