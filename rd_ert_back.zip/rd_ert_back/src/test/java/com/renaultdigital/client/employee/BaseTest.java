package com.renaultdigital.client.employee;

import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.renaultdigital.client.employee.repository.IAdminRepository;
import com.renaultdigital.client.employee.repository.IDepartmentRepository;
import com.renaultdigital.client.employee.repository.IDomainRepository;
import com.renaultdigital.client.employee.repository.IEmployeeRepository;
import com.renaultdigital.client.employee.repository.IEmployeeResignationRepository;
import com.renaultdigital.client.employee.repository.IFinanceApprovalRepository;
import com.renaultdigital.client.employee.repository.IHrApprovalRepository;
import com.renaultdigital.client.employee.repository.IItApprovalRepository;
import com.renaultdigital.client.employee.repository.IManagerApprovalRepository;
import com.renaultdigital.client.employee.repository.IPayrollApprovalRepository;
import com.renaultdigital.client.employee.repository.IReasonRepository;
import com.renaultdigital.client.employee.repository.IRecruitmentApprovalRepo;
import com.renaultdigital.client.employee.repository.IRolesRepository;
import com.renaultdigital.client.employee.repository.ISecurityApprovalRepo;
import com.renaultdigital.client.employee.repository.IStatusRepository;
import com.renaultdigital.client.employee.repository.ISubDepartmentRepository;
import com.renaultdigital.client.employee.repository.ITransactionRepository;
import com.renaultdigital.client.employee.security.TokenAuthenticationService;
import com.renaultdigital.client.employee.util.RenoConstants;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BaseTest {

	public final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	protected WebApplicationContext context;

	protected MockMvc mockMvc;

	protected String token = null;

	@Autowired
	protected IRolesRepository iRolesRepository;

	@Autowired
	protected IFinanceApprovalRepository financeApprovalRepo;
	
	@Autowired
	protected IHrApprovalRepository hrApprovalRepo;
	
	@Autowired
	protected IItApprovalRepository itApprovalRepository;
	
	@Autowired
	protected IManagerApprovalRepository managerApprovalRepository;
	
	@Autowired 
	protected IPayrollApprovalRepository payrollApprovalRepository;
	
	@Autowired
	protected IReasonRepository reasonRepository;
	
	@Autowired
	protected IRolesRepository rolesRepository;
	
	@Autowired
	protected ISecurityApprovalRepo securityApprovalRepo;
	
	@Autowired
	protected IRecruitmentApprovalRepo RecruitmentApprovalRepo;

	@Autowired
	protected IEmployeeResignationRepository resignationRepository;

	@Autowired
	protected IEmployeeRepository employeeRepository;

	@Autowired
	protected ISubDepartmentRepository subDepartmentRepository;

	@Autowired
	protected IDepartmentRepository departmentRepository;

	@Autowired
	protected IStatusRepository statusRepo;

	@Autowired
	protected IManagerApprovalRepository managerApprovalRepo;

	@Autowired
	protected ITransactionRepository transactionRepository;

	@Autowired
	protected IAdminRepository adminRepository;

	@Autowired
	protected IDomainRepository domainRepository;

	protected MockHttpServletResponse response = null;

	protected HttpHeaders headers = null;

	@Before
	public void setUp() throws Exception {

		headers = new HttpHeaders();
		response = new MockHttpServletResponse();

		mockMvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();

		TokenAuthenticationService authenticationService = new TokenAuthenticationService();
		authenticationService.addAuthentication(response, "z015481", iRolesRepository, resignationRepository,
				employeeRepository);
		token = response.getHeader(RenoConstants.HEADER_STRING.toLowerCase());
		headers.add(RenoConstants.HEADER_STRING, token);

	}

	@Test
	public void fooTest() {

	}
}
