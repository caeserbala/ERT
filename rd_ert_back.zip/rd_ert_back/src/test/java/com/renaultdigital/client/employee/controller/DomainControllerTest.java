package com.renaultdigital.client.employee.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.renaultdigital.client.employee.BaseTest;
import com.renaultdigital.client.employee.entity.Domains;
import com.renaultdigital.client.employee.entity.Status;

public class DomainControllerTest extends BaseTest {

	@Test
	public void testGetAllDomains() throws Exception {
		mockMvc.perform(get("/rd/ert/rest/v1/domains/").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andDo(print());
	}

	@Test
	public void testAddDomains() throws Exception {

		Status status = new Status();
		status.setStatusCode(999);
		status.setStatusName("test-status");

		statusRepo.save(status);

		Domains domain = new Domains();
		domain.setDomainName("Test-Domain");
		domain.setStatusCode(status);
		List<Domains> domainList = new ArrayList<>();
		domainList.add(domain);
		try {
			ObjectMapper mapper = new ObjectMapper();
			String content = mapper.writeValueAsString(domainList);

			MvcResult result = mockMvc
					.perform(post("/rd/ert/rest/v1/domains/").contentType(MediaType.APPLICATION_JSON_VALUE)
							.content(content).accept(MediaType.APPLICATION_JSON_VALUE).headers(headers))
					.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$", is(not(nullValue()))))
					.andReturn();

			String jsonValue = result.getResponse().getContentAsString();
			Integer domainId = JsonPath.read(jsonValue, "$[0].domainId");

			mockMvc.perform(get("/rd/ert/rest/v1/domains/" + domainId + "").headers(headers)).andExpect(status().isOk())
					.andExpect(jsonPath("$", is(not(nullValue())))).andDo(print()).andReturn();

			domainRepository.delete(domainId);
			statusRepo.delete(status);
			

		} catch (Exception e) {
			logger.info("Error occured in testAddDomains " + e.getMessage());
		}

	}

}
