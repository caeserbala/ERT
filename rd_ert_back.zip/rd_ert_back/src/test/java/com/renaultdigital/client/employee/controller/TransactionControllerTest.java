package com.renaultdigital.client.employee.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.renaultdigital.client.employee.BaseTest;
import com.renaultdigital.client.employee.entity.TransactionLog;
import com.renaultdigital.client.employee.model.User;
import com.renaultdigital.client.employee.util.RenoConstants;

public class TransactionControllerTest extends BaseTest {

	TransactionLog log = new TransactionLog();

	@Test
	public void testGetAllTransactionLogs() throws Exception {
		mockMvc.perform(get("/rd/ert/rest/v1/transaction/").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$", is(not(nullValue())))).andDo(print());
	}

	@Test
	public void testPostEmployeeResignation() {
		log.setAction("sample-test");
		log.setEmpRnNo("sample-test");
		log.setMgrNo("test");
		List<TransactionLog> list = new ArrayList<>();
		list.add(log);

		try {
			ObjectMapper mapper = new ObjectMapper();
			String content = mapper.writeValueAsString(list);

			mockMvc.perform(post("/rd/ert/rest/v1/transaction/").contentType(MediaType.APPLICATION_JSON_VALUE)
					.content(content).accept(MediaType.APPLICATION_JSON_VALUE).headers(headers))
					.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$[0].empRnNo", is("sample-test")))
					.andReturn();

			mockMvc.perform(get("/rd/ert/rest/v1/transaction/employee/sample-test").headers(headers))
					.andExpect(status().isOk()).andExpect(jsonPath("$", is(not(nullValue())))).andDo(print())
					.andReturn();

			mockMvc.perform(
					get("/rd/ert/rest/v1/transaction/manager/test").headers(headers).accept(MediaType.APPLICATION_JSON))
					.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$", is(not(nullValue()))))
					.andReturn();

			mockMvc.perform(get("/rd/ert/rest/v1/transaction/empAndmgr/test/employee/sample-test").headers(headers)
					.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print()).andReturn();

			Integer id = transactionRepository.findByEmpRnNoEqualsIgnoreCase("sample-test").get(0).getLogId();
			transactionRepository.delete(id);

		} catch (Exception e) {
			logger.info("Exception while Test Execution : {}", e.getMessage());
		}

	}

	@Test
	public void testGetLogin() throws Exception {
		User user = new User();
		user.setUserName("z015481");
		user.setPassword(RenoConstants.PW_STRING);
		ObjectMapper mapper = new ObjectMapper();
		String content = mapper.writeValueAsString(user);

		MvcResult result = mockMvc
				.perform(post("/login").with(csrf()).content(content).contentType(MediaType.APPLICATION_JSON_VALUE)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$", is(not(nullValue())))).andDo(print()).andReturn();

		result.getResponse().getHeader("token");
	}

}
