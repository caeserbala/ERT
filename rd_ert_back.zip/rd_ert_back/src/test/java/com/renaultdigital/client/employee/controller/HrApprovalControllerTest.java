package com.renaultdigital.client.employee.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.renaultdigital.client.employee.BaseTest;
import com.renaultdigital.client.employee.entity.Department;
import com.renaultdigital.client.employee.entity.Domains;
import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.entity.HrApproval;
import com.renaultdigital.client.employee.entity.Status;
import com.renaultdigital.client.employee.entity.SubDepartment;

public class HrApprovalControllerTest extends BaseTest {

	@Test
	public void testGetAllHrApprovals() throws Exception {
		mockMvc.perform(get("/rd/ert/rest/v1/hrapprovals/").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andDo(print());
	}

	@Test
	public void testAddHrApprovals() throws Exception {

		Department department = new Department();
		SubDepartment subDepartment = new SubDepartment();
		EmployeeInfo info = new EmployeeInfo();
		Status status = new Status();
		EmployeeResignation resignation = new EmployeeResignation();
		HrApproval hrApproval=new HrApproval();

		department.setFuncMgrRnno("Sample-test");
		department.setDeptName("Sample-Test");
		department.setGm("Sample-test");
		department.setHrSpoc("Sample-test");
		department.setHrRm("Sample-test");
		List<Department> deptList = new ArrayList<>();
		deptList.add(department);

		departmentRepository.save(deptList);

		subDepartment.setCostCentreCd("test");
		subDepartment.setCostCentreDesc("test");
		subDepartment.setDeptName(department);
		subDepartment.setSubDepartName("test");
		List<SubDepartment> list = new ArrayList<>();
		list.add(subDepartment);
		subDepartmentRepository.save(list);

		info.setRnNum("Rsample-test");
		info.setDesignation("sample-test");
		info.setFirstName("sample-test");
		info.setLastName("sample-test");
		info.setGender("sample-test");
		info.setGrade("sample-test");
		info.setIpn("sample-test");
		info.setDoj(new Date());
		info.setSubDepartName(subDepartment);
		List<EmployeeInfo> employeeInfos = new ArrayList<>();
		employeeInfos.add(info);
		employeeRepository.save(employeeInfos);

		status.setStatusCode(999);
		status.setStatusName("test-status");
		statusRepo.save(status);

		Domains domain = new Domains();
		domain.setDomainName("Test-Domain");
		domain.setStatusCode(status);
		List<Domains> domainList = new ArrayList<>();
		domainList.add(domain);
		List<Domains> savedDomains = (List<Domains>) domainRepository.save(domainList);

		resignation.setRnNum(info);
		resignation.setrId(0);
		resignation.setComments("test-comments");
		resignation.setDateOfResignation(new Date());
		resignation.setFuncMgrRnno("RN09184");
		resignation.setHrBPMail("sasikumar.kamaraj@rntbci.com");
		resignation.setHrRMNo("RN09184");
		resignation.setReason("test-reason");
		resignation.setReportingMgrNo("RN09184");
		resignation.setStatusCode(status);
		resignation.setSubDepartName(subDepartment);
		List<EmployeeResignation> resignationsList = new ArrayList<>();
		resignationsList.add(resignation);
		List<EmployeeResignation> savedList = resignationRepository.save(resignationsList);

		//hrApproval.setHraId(0);
		hrApproval.setExitIntvCompletion(true);
		hrApproval.setMedicalInsuranceCards(true);
		hrApproval.setCertificationFee(true);
		hrApproval.setCommitmentPerAgreement(true);
		hrApproval.setLibrary(true);
		hrApproval.setComments("Sample-comments");
		hrApproval.setInitiateErf(true);
		hrApproval.setStatus("Approved");
		hrApproval.setHrRMStatus("Approved");
		hrApproval.setRnNum(info);
		hrApproval.setResignationId(savedList.get(0));
		hrApproval.setApprovedDate(new Date());
		hrApproval.setHrMgrApprovedDate(new Date());
		hrApproval.setLeaveBalance(0);
		hrApproval.setNoticePeriodRecovery(0);
		hrApproval.setHrMgrComments("sample-hrmgrcomments");
		List<HrApproval> hrApprovalList = new ArrayList<>();
		hrApprovalList.add(hrApproval);
		
		Integer hraId = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			String content = mapper.writeValueAsString(hrApprovalList);

			MvcResult result = mockMvc
					.perform(post("/rd/ert/rest/v1/hrapprovals/").contentType(MediaType.APPLICATION_JSON_VALUE)
							.content(content).accept(MediaType.APPLICATION_JSON_VALUE).headers(headers))
					.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$", is(not(nullValue()))))
					.andReturn();

			String jsonValue = result.getResponse().getContentAsString();
			hraId = JsonPath.read(jsonValue, "$[0].hraId");

			mockMvc.perform(get("/rd/ert/rest/v1/hrapprovals/Rsample-test").headers(headers))
					.andExpect(status().isOk()).andExpect(jsonPath("$", is(not(nullValue())))).andDo(print())
					.andReturn();

			hrApprovalRepo.delete(hraId);
			resignationRepository.delete(savedList.get(0).getrId());
			employeeRepository.delete(info);
			subDepartmentRepository.delete(subDepartment);
			departmentRepository.delete(department);
			domainRepository.delete(savedDomains.get(0));
			statusRepo.delete(status);

		} catch (Exception e) {
			logger.info("Error occured in testAddDomains " + e.getMessage());
		}

	}
	//for 
	@Test
	public void testAddHrApprovalsRejected() throws Exception {

		Department department = new Department();
		SubDepartment subDepartment = new SubDepartment();
		EmployeeInfo info = new EmployeeInfo();
		Status status = new Status();
		EmployeeResignation resignation = new EmployeeResignation();
		HrApproval hrApproval=new HrApproval();

		department.setFuncMgrRnno("Sample-test");
		department.setDeptName("Sample-Test");
		department.setGm("Sample-test");
		department.setHrSpoc("Sample-test");
		department.setHrRm("Sample-test");
		List<Department> deptList = new ArrayList<>();
		deptList.add(department);

		departmentRepository.save(deptList);

		subDepartment.setCostCentreCd("test");
		subDepartment.setCostCentreDesc("test");
		subDepartment.setDeptName(department);
		subDepartment.setSubDepartName("test");
		List<SubDepartment> list = new ArrayList<>();
		list.add(subDepartment);
		subDepartmentRepository.save(list);

		info.setRnNum("Rsample-test");
		info.setDesignation("sample-test");
		info.setFirstName("sample-test");
		info.setLastName("sample-test");
		info.setGender("sample-test");
		info.setGrade("sample-test");
		info.setIpn("sample-test");
		info.setDoj(new Date());
		info.setSubDepartName(subDepartment);
		List<EmployeeInfo> employeeInfos = new ArrayList<>();
		employeeInfos.add(info);
		employeeRepository.save(employeeInfos);

		status.setStatusCode(999);
		status.setStatusName("test-status");
		statusRepo.save(status);

		Domains domain = new Domains();
		domain.setDomainName("Test-Domain");
		domain.setStatusCode(status);
		List<Domains> domainList = new ArrayList<>();
		domainList.add(domain);
		List<Domains> savedDomains = (List<Domains>) domainRepository.save(domainList);

		resignation.setRnNum(info);
		resignation.setrId(0);
		resignation.setComments("test-comments");
		resignation.setDateOfResignation(new Date());
		resignation.setFuncMgrRnno("RN09184");
		resignation.setHrBPMail("sasikumar.kamaraj@rntbci.com");
		resignation.setHrRMNo("RN09184");
		resignation.setReason("test-reason");
		resignation.setReportingMgrNo("RN09184");
		resignation.setStatusCode(status);
		resignation.setSubDepartName(subDepartment);
		List<EmployeeResignation> resignationsList = new ArrayList<>();
		resignationsList.add(resignation);
		List<EmployeeResignation> savedList = resignationRepository.save(resignationsList);

		hrApproval.setExitIntvCompletion(true);
		hrApproval.setMedicalInsuranceCards(true);
		hrApproval.setCertificationFee(true);
		hrApproval.setCommitmentPerAgreement(true);
		hrApproval.setLibrary(true);
		hrApproval.setComments("Sample-comments");
		hrApproval.setInitiateErf(true);
		hrApproval.setStatus("Rejected");
		hrApproval.setHrRMStatus("Rejected");
		hrApproval.setRnNum(info);
		hrApproval.setResignationId(savedList.get(0));
		hrApproval.setApprovedDate(new Date());
		hrApproval.setHrMgrApprovedDate(new Date());
		hrApproval.setLeaveBalance(0);
		hrApproval.setNoticePeriodRecovery(0);
		hrApproval.setHrMgrComments("sample-hrmgrcomments");
		List<HrApproval> hrApprovalList = new ArrayList<>();
		hrApprovalList.add(hrApproval);
		
		Integer hraId = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			String content = mapper.writeValueAsString(hrApprovalList);

			MvcResult result = mockMvc
					.perform(post("/rd/ert/rest/v1/hrapprovals/").contentType(MediaType.APPLICATION_JSON_VALUE)
							.content(content).accept(MediaType.APPLICATION_JSON_VALUE).headers(headers))
					.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$", is(not(nullValue()))))
					.andReturn();

			String jsonValue = result.getResponse().getContentAsString();
			hraId = JsonPath.read(jsonValue, "$[0].hraId");

			mockMvc.perform(get("/rd/ert/rest/v1/hrapprovals/Rsample-test").headers(headers))
					.andExpect(status().isOk()).andExpect(jsonPath("$", is(not(nullValue())))).andDo(print())
					.andReturn();

			hrApprovalRepo.delete(hraId);
			resignationRepository.delete(savedList.get(0).getrId());
			employeeRepository.delete(info);
			subDepartmentRepository.delete(subDepartment);
			departmentRepository.delete(department);
			domainRepository.delete(savedDomains.get(0));
			statusRepo.delete(status);

		} catch (Exception e) {
			logger.info("Error occured in testAddDomains " + e.getMessage());
		}

	}

}

