package com.renaultdigital.client.employee.util;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.ldap.support.LdapUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.renaultdigital.client.employee.BaseTest;
import com.renaultdigital.client.employee.model.DataCount;
import com.renaultdigital.client.employee.model.User;
import com.renaultdigital.client.employee.util.Constants.StatusCode;

public class LoginTest extends BaseTest {

	@Test
	public void testGetLogin() throws Exception {
		User user = new User();
		user.setUserName("z015481");
		user.setPassword(RenoConstants.PW_STRING);
		ObjectMapper mapper = new ObjectMapper();
		String content = mapper.writeValueAsString(user);

		mockMvc.perform(post("/login").with(csrf()).content(content).contentType(MediaType.APPLICATION_JSON_VALUE)
				.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("$", is(not(nullValue())))).andDo(print());

	}

	@Test
	public void testGetLoginFail() throws Exception {
		User user = new User();
		user.setUserName("z021737");
		user.setPassword("sampleTest");
		ObjectMapper mapper = new ObjectMapper();
		String content = mapper.writeValueAsString(user);

		mockMvc.perform(post("/login").with(csrf()).content(content).contentType(MediaType.APPLICATION_JSON_VALUE)
				.accept(MediaType.APPLICATION_JSON)).andExpect(status().is(401)).andDo(print());

	}

	@Test
	public void testRenoConstantsIsPrivate() throws Exception {
		Constructor<RenoConstants> constructor = RenoConstants.class.getDeclaredConstructor();
		assertTrue(Modifier.isPrivate(constructor.getModifiers()));
		constructor.setAccessible(true);
		constructor.newInstance();
	}

	@Test
	public void testUtilsIsPrivate() throws Exception {
		Constructor<Utils> constructor = Utils.class.getDeclaredConstructor();
		assertTrue(Modifier.isPrivate(constructor.getModifiers()));
		constructor.setAccessible(true);
		constructor.newInstance();
	}

	@Test
	public void testmailUtilsIsPrivate() throws Exception {
		Constructor<MailUtils> constructor = MailUtils.class.getDeclaredConstructor();
		assertTrue(Modifier.isPrivate(constructor.getModifiers()));
		constructor.setAccessible(true);
		constructor.newInstance();
	}

	@Test
	public void testDBUtilsIsPrivate() throws Exception {
		Constructor<DBUtils> constructor = DBUtils.class.getDeclaredConstructor();
		assertTrue(Modifier.isPrivate(constructor.getModifiers()));
		constructor.setAccessible(true);
		constructor.newInstance();
	}

	@Test
	public void testLDAPUtilsIsPrivate() throws Exception {
		Constructor<LdapUtils> constructor = LdapUtils.class.getDeclaredConstructor();
		assertTrue(Modifier.isPrivate(constructor.getModifiers()));
		constructor.setAccessible(true);
		constructor.newInstance();
	}

	@Test
	public void testConstantsIsPrivate() throws Exception {
		Constructor<Constants> constructor = Constants.class.getDeclaredConstructor();
		assertTrue(Modifier.isPrivate(constructor.getModifiers()));
		constructor.setAccessible(true);
		constructor.newInstance();
	}

	@Test
	public void testConstantStatusIsPrivate() throws Exception {
		Constructor<StatusCode> constructor = Constants.StatusCode.class.getDeclaredConstructor();
		assertTrue(Modifier.isPrivate(constructor.getModifiers()));
		constructor.setAccessible(true);
		constructor.newInstance();
	}

	@Test
	public void testgetReportInPercerntage() throws Exception {
		DataCount count = new DataCount("data", 1, 1);
		logger.info("Count is : {} ", count);
		List<DataCount> list = new ArrayList<>();
		list.add(count);
		JsonArray array = Utils.getReportInPercerntage(list, "test");
		assertNotNull(array);
	}

	@Test
	public void testSendMailException() throws Exception {
		String result = MailUtils.triggerEmail(",", ",", ",", ",");
		assertEquals("failure", result);
	}

}
