package com.renaultdigital.client.employee.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.InputStream;

import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.renaultdigital.client.employee.BaseTest;
import com.renaultdigital.client.employee.entity.MailDetail;

public class MailTest extends BaseTest {
	@Test
	public void testSendMail() throws Exception {
		MailDetail mail = new MailDetail();
		mail.setBody("Testng-Unit Teting mail");
		mail.setMailCC("sasikumar.kamaraj@rntbci.com");
		mail.setMailTo("sasikumar.kamaraj@rntbci.com");
		mail.setSubject("Testng-Unit Teting mail");

		ObjectMapper mapper = new ObjectMapper();
		String content = mapper.writeValueAsString(mail);

		mockMvc.perform(post("/rd/ert/rest/v1/mail/sendMail").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(content).headers(headers).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("$.message", is("Success"))).andDo(print());
	}

	@Test
	public void testSendMailAttachments() throws Exception {

		InputStream stream = this.getClass().getResourceAsStream("/banner.txt");
		MockMultipartFile fstmp = new MockMultipartFile("fileUpload", "banner.txt", "multipart/form-data", stream);

		mockMvc.perform(MockMvcRequestBuilders.fileUpload("/rd/ert/rest/v1/mail/sendMailAttachment").file(fstmp)
				.param("mailTo", "sasikumar.kamaraj@rntbci.com").param("mailCC", "sasikumar.kamaraj@rntbci.com")
				.param("subject", "Testng-Unit Teting mail").param("body", "Testng-Unit Teting mail"))
				.andExpect(jsonPath("$.message", is("Success"))).andExpect(status().isOk());
	}

}
