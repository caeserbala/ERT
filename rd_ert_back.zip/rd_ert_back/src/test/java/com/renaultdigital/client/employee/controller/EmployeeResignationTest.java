package com.renaultdigital.client.employee.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.renaultdigital.client.employee.BaseTest;
import com.renaultdigital.client.employee.entity.Department;
import com.renaultdigital.client.employee.entity.EmployeeInfo;
import com.renaultdigital.client.employee.entity.EmployeeResignation;
import com.renaultdigital.client.employee.entity.ManagerApproval;
import com.renaultdigital.client.employee.entity.Status;
import com.renaultdigital.client.employee.entity.SubDepartment;

public class EmployeeResignationTest extends BaseTest {

	Department department = new Department();
	SubDepartment subDepartment = new SubDepartment();
	EmployeeInfo info = new EmployeeInfo();
	Status status = new Status();
	EmployeeResignation resignation = new EmployeeResignation();
	ManagerApproval approval = new ManagerApproval();

	@Test
	public void testGetEmployeeresignations() throws Exception {
		mockMvc.perform(
				get("/rd/ert/rest/v1/employeeresignations/").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andDo(print());
	}

	@Test
	public void testPostEmployeeResignation() {
		department.setFuncMgrRnno("Sample-test");
		department.setDeptName("Sample-Test");
		department.setGm("Sample-test");
		department.setHrSpoc("Sample-test");
		department.setHrRm("Sample-test");
		List<Department> deptList = new ArrayList<>();
		deptList.add(department);

		departmentRepository.save(deptList);

		subDepartment.setCostCentreCd("test");
		subDepartment.setCostCentreDesc("test");
		subDepartment.setDeptName(department);
		subDepartment.setSubDepartName("test");
		List<SubDepartment> list = new ArrayList<>();
		list.add(subDepartment);
		subDepartmentRepository.save(list);

		info.setRnNum("Rsample-test");
		info.setDesignation("sample-test");
		info.setFirstName("sample-test");
		info.setLastName("sample-test");
		info.setGender("sample-test");
		info.setGrade("sample-test");
		info.setIpn("sample-test");
		info.setDoj(new Date());
		info.setSubDepartName(subDepartment);
		List<EmployeeInfo> employeeInfos = new ArrayList<>();
		employeeInfos.add(info);
		employeeRepository.save(employeeInfos);

		status.setStatusCode(999);
		status.setStatusName("test-status");
		statusRepo.save(status);

		resignation.setRnNum(info);
		resignation.setrId(0);
		resignation.setComments("test-comments");
		resignation.setDateOfResignation(new Date());
		resignation.setFuncMgrRnno("RN09184");
		resignation.setHrBPMail("sasikumar.kamaraj@rntbci.com");
		resignation.setHrRMNo("RN09184");
		resignation.setReason("test-reason");
		resignation.setReportingMgrNo("RN09184");
		resignation.setStatusCode(status);
		resignation.setSubDepartName(subDepartment);
		List<EmployeeResignation> resignationsList = new ArrayList<>();
		resignationsList.add(resignation);

		try {
			ObjectMapper mapper = new ObjectMapper();
			String content = mapper.writeValueAsString(resignationsList);

			mockMvc.perform(post("/rd/ert/rest/v1/employeeresignations/").contentType(MediaType.APPLICATION_JSON_VALUE)
					.content(content).accept(MediaType.APPLICATION_JSON_VALUE).headers(headers))
					.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$", is(not(nullValue()))))
					.andReturn();

			mockMvc.perform(get("/rd/ert/rest/v1/employeeresignations/Rsample-test").headers(headers))
					.andExpect(status().isOk()).andExpect(jsonPath("$", is(not(nullValue())))).andDo(print())
					.andReturn();

			mockMvc.perform(get("/rd/ert/rest/v1/employeeresignations/manager/RN09184").headers(headers)
					.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print())
					.andExpect(jsonPath("$", is(not(nullValue())))).andReturn();

			mockMvc.perform(get("/rd/ert/rest/v1/employeeresignations/fnmanager/RN09184").headers(headers)
					.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print()).andReturn();

			mockMvc.perform(get("/rd/ert/rest/v1/employeeresignations/manager/RN09184/avail").headers(headers)
					.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print())
					.andExpect(jsonPath("$", is(not(nullValue())))).andReturn();

			mockMvc.perform(get("/rd/ert/rest/v1/employeeresignations/status/Rsample-test").headers(headers)
					.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print())
					.andExpect(jsonPath("$", is(not(nullValue())))).andReturn();

			mockMvc.perform(get("/rd/ert/rest/v1/employeeresignations/hrbp/RN09184").headers(headers)
					.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print())
					.andExpect(jsonPath("$", is(not(nullValue())))).andReturn();

			mockMvc.perform(get("/rd/ert/rest/v1/employeeresignations/hrrm/RN09184").headers(headers)
					.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print())
					.andExpect(jsonPath("$", is(not(nullValue())))).andReturn();

			approval = managerApprovalRepo.findByRnNumRnNum(info.getRnNum());

			managerApprovalRepo.delete(approval);
			EmployeeResignation resignation = resignationRepository.findByRnNumRnNum(info.getRnNum());
			resignationRepository.delete(resignation);
			employeeRepository.delete(info);
			subDepartmentRepository.delete(subDepartment);
			departmentRepository.delete(department);
			statusRepo.delete(status);

		} catch (Exception e) {
		}

	}

}
