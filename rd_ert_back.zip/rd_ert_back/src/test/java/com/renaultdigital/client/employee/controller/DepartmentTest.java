package com.renaultdigital.client.employee.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.renaultdigital.client.employee.BaseTest;
import com.renaultdigital.client.employee.entity.Department;

public class DepartmentTest extends BaseTest {

	@Test
	public void testGetDepartment() throws Exception {
		mockMvc.perform(get("/rd/ert/rest/v1/departments/").headers(headers).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andDo(print());
	}

	@Test
	public void testPostDepartment() throws Exception {
		Department department = new Department();
		department.setFuncMgrRnno("Sample-test");
		department.setDeptName("Sample-Test");
		department.setGm("Sample-test");
		department.setHrSpoc("Sample-test");
		department.setHrRm("Sample-test");
		List<Department> deptList = new ArrayList<>();
		deptList.add(department);
		ObjectMapper mapper = new ObjectMapper();
		String content = mapper.writeValueAsString(deptList);

		mockMvc.perform(post("/rd/ert/rest/v1/departments/").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(content).headers(headers)).andExpect(status().isOk()).andDo(print())
				.andExpect(jsonPath("$", hasSize(1))).andExpect(jsonPath("$[0].deptName", is("Sample-Test")))
				.andReturn();

		mockMvc.perform(get("/rd/ert/rest/v1/departments/Sample-Test").headers(headers)).andExpect(status().isOk())
				.andDo(print()).andExpect(jsonPath("$.deptName", is("Sample-Test"))).andReturn();

		departmentRepository.delete(department);

	}

}
